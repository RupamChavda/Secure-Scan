#!/usr/bin/env bash
# Run ON the Wazuh manager VM as root.
# Usage: sudo bash setup_wazuh_manager.sh <secure-scan-cidr>
set -euo pipefail
CIDR="${1:-192.168.56.0/24}"
CONF=/var/ossec/etc/ossec.conf
RULES=/var/ossec/etc/rules/local_rules.xml
DECODERS=/var/ossec/etc/decoders/securescan_decoders.xml
BASE_DIR="$(cd "$(dirname "$0")" && pwd)"

cp "$CONF" "$CONF.bak.$(date +%s)"

python3 - "$CONF" "$CIDR" <<'PY'
import sys
from pathlib import Path
conf, cidr = sys.argv[1:]
s = Path(conf).read_text()
if '<connection>syslog</connection>' not in s:
    block=f'''\n  <remote>\n    <connection>syslog</connection>\n    <port>514</port>\n    <protocol>tcp</protocol>\n    <allowed-ips>{cidr}</allowed-ips>\n  </remote>\n'''
    s=s.replace('</ossec_config>', block+'\n</ossec_config>')
if '<vulnerability-detection>' not in s and '<vulnerability-detector>' not in s:
    block='''\n  <vulnerability-detection>\n    <enabled>yes</enabled>\n    <index-status>yes</index-status>\n    <feed-update-interval>60m</feed-update-interval>\n  </vulnerability-detection>\n'''
    s=s.replace('</ossec_config>', block+'\n</ossec_config>')
Path(conf).write_text(s)
PY

mkdir -p /var/ossec/etc/decoders
cp "$BASE_DIR/securescan_decoders.xml" "$DECODERS"
# Replace the SecureScan group in local rules so repeated runs stay idempotent.
tmp=$(mktemp)
if grep -q 'name="local,securescan,vulnerability,"' "$RULES" 2>/dev/null; then
  python3 - "$RULES" "$BASE_DIR/local_rules.xml" "$tmp" <<'PY'
import re,sys
from pathlib import Path
rules, new, out=sys.argv[1:]
s=Path(rules).read_text()
block=Path(new).read_text()
s=re.sub(r'<group name="local,securescan,vulnerability,">.*?</group>', block.strip(), s, flags=re.S)
Path(out).write_text(s)
PY
  cp "$tmp" "$RULES"
else
  cat "$BASE_DIR/local_rules.xml" >> "$RULES"
fi
rm -f "$tmp"


/var/ossec/bin/wazuh-logtest -V >/dev/null 2>&1 || true
systemctl restart wazuh-manager
command -v ufw >/dev/null && ufw allow 514/tcp || true

echo "[+] Wazuh configured for SecureScan TCP syslog and native vulnerability detection."
echo "[+] Verify: ss -tlnp | grep 514"
echo "[+] Verify: grep -A4 '<vulnerability-detection>' $CONF"
echo "[+] Verify index: wazuh-states-vulnerabilities-*"
