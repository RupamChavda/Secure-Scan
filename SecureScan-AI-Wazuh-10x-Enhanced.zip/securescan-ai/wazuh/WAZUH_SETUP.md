# Wazuh Integration Guide

## Do I need to start Wazuh in VirtualBox?
**Yes - if you keep the default setup.** SecureScan AI only *sends* events; the Wazuh Manager is a separate server.
Start the Wazuh VM (OVA) in VirtualBox **before** scanning. If it is off, the top bar shows *Unreachable*
and events are retried, then counted under "Failed".

Alternatives with no VM: Wazuh Docker single-node, or a cloud server. Just set `WAZUH_HOST`.

## One-time setup
1. VirtualBox -> VM Settings -> Network: Adapter 1 = NAT, **Adapter 2 = Host-only** (vboxnet0). Boot the VM.
2. In the VM: `ip a` and note the host-only IP (usually `192.168.56.10`). From your PC: `ping 192.168.56.10`.
3. Copy the `wazuh/` folder to the VM and run: `sudo bash setup_wazuh_manager.sh`
   (installs rules 100100-100110, enables the TCP 514 syslog listener, restarts the manager).
4. `cp .env.example .env`, set `WAZUH_HOST`, `SECRET_KEY`, then `docker compose up --build`
   (or `uvicorn backend.main:app` locally).
5. Log in -> **SIEM Integration** -> **Send Test Event**. In Wazuh Dashboard -> Threat Hunting, search `rule.id:100101`.

## Optional read-back (live alerts inside SecureScan)
Set `WAZUH_API_URL`/`WAZUH_API_PASSWORD` (port 55000) and `WAZUH_INDEXER_URL`/`WAZUH_INDEXER_PASSWORD` (port 9200).

## Troubleshooting
| Symptom | Fix |
|---|---|
| Unreachable | VM off, wrong IP, `ss -tlnp \| grep 514` empty on VM, or firewall blocks 514/tcp |
| Reachable but no alerts | `allowed-ips` must include the IP the VM sees for your PC (often 192.168.56.1); test with `/var/ossec/bin/wazuh-logtest` |
| Docker container can't reach VM | Use the host-only IP, not localhost; check host firewall |


## Native Wazuh Vulnerability Detection (4.8+)

SecureScan AI now consumes Wazuh's native endpoint vulnerability inventory. Wazuh Agent Syscollector collects installed software/package inventory; the Wazuh Vulnerability Detection module correlates that inventory with Wazuh CTI vulnerability content and indexes the results in `wazuh-states-vulnerabilities-*`. SecureScan imports those records through the Wazuh Indexer and stores a local normalized copy for correlation and dashboard filtering.

On the Wazuh manager, ensure `ossec.conf` contains:

```xml
<vulnerability-detection>
  <enabled>yes</enabled>
  <index-status>yes</index-status>
  <feed-update-interval>60m</feed-update-interval>
</vulnerability-detection>
```

For agents, ensure Syscollector package inventory is enabled. Wazuh 4.8+ uses the Indexer vulnerability state rather than the removed legacy `/vulnerability/{agent_id}` API.

### SecureScan API

- `GET /api/v1/integrations/wazuh/status?deep=true` — Manager/API/Indexer health and durable outbox metrics.
- `GET /api/v1/integrations/wazuh/alerts` — SecureScan alerts read back from Wazuh.
- `GET /api/v1/integrations/wazuh/vulnerabilities?refresh=true` — synchronizes native Wazuh endpoint vulnerabilities.
- `POST /api/v1/integrations/wazuh/test` — sends a harmless integration-test event; it does not fabricate a CVE.

### Data flow

```text
Wazuh Agent
   -> Syscollector
   -> Wazuh Vulnerability Detection
   -> wazuh-states-vulnerabilities-*
   -> Wazuh Indexer
   -> SecureScan

SecureScan scanner
   -> SQLite durable outbox
   -> Wazuh Manager TCP/514
   -> Wazuh rules/alerts
   -> Wazuh Indexer
   -> SecureScan
```

If Wazuh is offline, SecureScan retains outbound events in the SQLite outbox and retries them after the manager returns.
