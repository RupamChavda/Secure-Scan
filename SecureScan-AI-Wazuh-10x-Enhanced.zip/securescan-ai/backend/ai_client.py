"""
Thin client for calling the Anthropic API to power the platform's AI
features (chat assistant, vulnerability explanations, and scan narrative
summaries). Every caller in this codebase is written to gracefully fall back
to deterministic, rule-based text when no API key is configured or the API
call fails for any reason — the platform must always return a useful answer,
AI-powered or not.
"""
import requests
from typing import Optional, List, Dict

from backend.config import settings

ANTHROPIC_API_URL = "https://api.anthropic.com/v1/messages"
ANTHROPIC_VERSION = "2023-06-01"


class AIUnavailableError(Exception):
    """Raised whenever a real LLM call cannot be made or fails — callers
    should catch this and fall back to their deterministic logic."""
    pass


def is_ai_configured() -> bool:
    return bool(settings.ANTHROPIC_API_KEY)


def call_claude(
    system_prompt: str,
    user_prompt: str,
    max_tokens: int = 900,
    conversation_history: Optional[List[Dict[str, str]]] = None,
    timeout: int = 25,
) -> str:
    """
    Sends a single request to the Anthropic Messages API and returns the
    assistant's text reply. Raises AIUnavailableError on any failure
    (missing key, network error, non-2xx response, malformed reply) so
    callers can fall back cleanly instead of crashing the request.
    """
    if not settings.ANTHROPIC_API_KEY:
        raise AIUnavailableError("No ANTHROPIC_API_KEY is configured on this server.")

    messages = list(conversation_history or [])
    messages.append({"role": "user", "content": user_prompt})

    try:
        resp = requests.post(
            ANTHROPIC_API_URL,
            headers={
                "x-api-key": settings.ANTHROPIC_API_KEY,
                "anthropic-version": ANTHROPIC_VERSION,
                "content-type": "application/json",
            },
            json={
                "model": settings.DEFAULT_AI_MODEL,
                "max_tokens": max_tokens,
                "system": system_prompt,
                "messages": messages,
            },
            timeout=timeout,
        )
    except requests.RequestException as e:
        raise AIUnavailableError(f"Network error calling Anthropic API: {e}")

    if resp.status_code != 200:
        raise AIUnavailableError(f"Anthropic API returned HTTP {resp.status_code}: {resp.text[:300]}")

    try:
        data = resp.json()
        text_blocks = [b["text"] for b in data.get("content", []) if b.get("type") == "text"]
        reply = "\n".join(text_blocks).strip()
        if not reply:
            raise ValueError("Empty response content")
        return reply
    except Exception as e:
        raise AIUnavailableError(f"Could not parse Anthropic API response: {e}")
