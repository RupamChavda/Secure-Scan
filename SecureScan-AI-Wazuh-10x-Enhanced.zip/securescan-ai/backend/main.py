from fastapi import FastAPI, Depends
from fastapi.middleware.cors import CORSMiddleware
from fastapi.staticfiles import StaticFiles
import os

from backend.config import settings
from backend.routers.auth import get_current_user, require_admin
from backend.routers import auth, assets, scans, ai_analysis, vulnerabilities, reports, schedules
from backend.scheduler import start_scheduler, stop_scheduler

app = FastAPI(
    title=settings.PROJECT_NAME,
    version=settings.VERSION,
    description="Enterprise AI-Powered Vulnerability Assessment & Security Scanner API",
    docs_url="/docs",
    redoc_url="/redoc"
)

@app.on_event("startup")
def _on_startup():
    # Starts the background thread that checks for and runs due recurring scans.
    start_scheduler()

@app.on_event("shutdown")
def _on_shutdown():
    stop_scheduler()

# Configure CORS
app.add_middleware(
    CORSMiddleware,
    allow_origins=settings.CORS_ORIGINS,
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

@app.middleware("http")
async def add_no_cache_header(request, call_next):
    response = await call_next(request)
    response.headers["Cache-Control"] = "no-cache, no-store, must-revalidate"
    response.headers["Pragma"] = "no-cache"
    response.headers["Expires"] = "0"
    return response



# Register Routers
app.include_router(auth.router, prefix=settings.API_PREFIX)
app.include_router(assets.router, prefix=settings.API_PREFIX)
app.include_router(scans.router, prefix=settings.API_PREFIX)
app.include_router(ai_analysis.router, prefix=settings.API_PREFIX)
app.include_router(vulnerabilities.router, prefix=settings.API_PREFIX)
app.include_router(reports.router, prefix=settings.API_PREFIX)
app.include_router(schedules.router, prefix=settings.API_PREFIX)

from backend.check_tools import check_all_tools
from backend.wazuh import get_wazuh_status, get_recent_alerts, get_wazuh_vulnerabilities, test_delivery

@app.get("/api/v1/health")
def health_check():
    return {
        "status": "online",
        "service": settings.PROJECT_NAME,
        "version": settings.VERSION,
        "engine": "Active Security Scanner & Risk Synthesizer"
    }

@app.get("/api/v1/health/tools")
def scanner_tools_check(_u: dict = Depends(get_current_user)):
    return check_all_tools()

@app.get("/api/v1/integrations/wazuh/status")
def wazuh_integration_status(deep: bool = False, _u: dict = Depends(get_current_user)):
    """Wazuh connectivity + delivery metrics. ?deep=true also queries the Wazuh API."""
    return get_wazuh_status(deep=deep)

@app.get("/api/v1/integrations/wazuh/alerts")
def wazuh_integration_alerts(limit: int = 20, _u: dict = Depends(get_current_user)):
    """Recent SecureScan alerts read back from the Wazuh Indexer (if configured)."""
    return get_recent_alerts(min(max(limit, 1), 100))

@app.get("/api/v1/integrations/wazuh/vulnerabilities")
def wazuh_vulnerabilities(
    limit: int = 100, offset: int = 0, severity: str | None = None,
    cve: str | None = None, agent_id: str | None = None, refresh: bool = False,
    _u: dict = Depends(get_current_user),
):
    """Return native Wazuh endpoint vulnerability inventory.

    Wazuh 4.8+ stores vulnerability state in wazuh-states-vulnerabilities-*;
    this endpoint synchronizes that state into SecureScan's local history and
    never invents CVEs when the Wazuh Indexer is unavailable.
    """
    return get_wazuh_vulnerabilities(limit=limit, offset=offset, severity=severity,
                                     cve=cve, agent_id=agent_id, refresh=refresh)


@app.post("/api/v1/integrations/wazuh/test")
def wazuh_integration_test(_a: dict = Depends(require_admin)):
    """Send a harmless integration-test event. It contains no fake CVE."""
    return test_delivery()


# Mount static frontend directory if present
frontend_path = os.path.abspath(os.path.join(os.path.dirname(__file__), "..", "frontend"))
if os.path.exists(frontend_path):
    app.mount("/", StaticFiles(directory=frontend_path, html=True), name="frontend")
