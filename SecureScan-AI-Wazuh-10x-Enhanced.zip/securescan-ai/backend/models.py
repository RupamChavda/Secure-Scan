from pydantic import BaseModel, EmailStr, Field
from typing import Optional, List, Dict, Any
from enum import Enum
from datetime import datetime

class RoleEnum(str, Enum):
    ADMIN = "Admin"
    ANALYST = "Security Analyst"
    MANAGER = "Manager"
    VIEWER = "Viewer"

class ScanTypeEnum(str, Enum):
    QUICK = "Quick Scan"
    FULL = "Full Vulnerability Scan"
    WEB = "Web Security Scan"
    NETWORK = "Network Scan"
    PORT = "Port Scan"
    SSL = "SSL Scan"
    API = "API Security Scan"
    OWASP = "OWASP Top 10 Scan"
    SAST = "Source Code Security Scan"
    DEPENDENCY = "Dependency Scan"
    CONFIG = "Configuration Audit"

class TargetTypeEnum(str, Enum):
    URL = "Website URL"
    IP = "IP Address"
    DOMAIN = "Domain"
    SERVER = "Server"
    CIDR = "Network (CIDR)"
    REPO = "GitHub Repository"
    FOLDER = "Local Folder"
    CONTAINER = "Docker Container"
    CLOUD = "Cloud Instance"
    ZIP = "Uploaded ZIP"

class SeverityEnum(str, Enum):
    CRITICAL = "Critical"
    HIGH = "High"
    MEDIUM = "Medium"
    LOW = "Low"
    INFO = "Info"

# --- Authentication Models ---
class UserLogin(BaseModel):
    username: str
    password: str

class UserCreate(BaseModel):
    username: str
    email: str
    password: str
    role: RoleEnum = RoleEnum.ANALYST
    full_name: str

class UserResponse(BaseModel):
    id: str
    username: str
    email: str
    role: RoleEnum
    full_name: str
    created_at: str

class TokenResponse(BaseModel):
    access_token: str
    token_type: str = "bearer"
    user: UserResponse

# --- Asset Models ---
class AssetCreate(BaseModel):
    name: str
    target: str
    asset_type: TargetTypeEnum
    tags: List[str] = []
    owner: str = "Security Team"
    department: str = "DevOps / InfoSec"

class AssetResponse(BaseModel):
    id: str
    name: str
    target: str
    asset_type: TargetTypeEnum
    tags: List[str]
    owner: str
    department: str
    status: str = "Active"
    last_scanned: Optional[str] = None

# --- Scan Models ---
class ScanCreate(BaseModel):
    target: str
    target_type: TargetTypeEnum
    scan_types: List[ScanTypeEnum]
    asset_id: Optional[str] = None
    custom_notes: Optional[str] = ""
    # Authenticated scanning: lets the live HTTP scanner reach pages behind a
    # login wall by attaching the caller's own auth headers/cookies (e.g.
    # {"Authorization": "Bearer ...", "Cookie": "session=..."}).
    custom_headers: Optional[Dict[str, str]] = None
    # Optional webhook to POST a JSON alert to when this scan finds Critical/High issues.
    webhook_url: Optional[str] = None

class VulnerabilityItem(BaseModel):
    id: str
    title: str
    severity: SeverityEnum
    cvss_score: float
    cve_id: Optional[str] = "N/A"
    owasp_category: Optional[str] = "N/A"
    mitre_attack: Optional[str] = "N/A"
    affected_asset: str
    description: str
    evidence: str
    remediation: str

class AIRiskSummary(BaseModel):
    overall_risk_score: float
    business_impact: str
    technical_impact: str
    likelihood: str
    recommendations: List[str]
    patch_priority: List[str]
    executive_summary: str
    ai_powered: bool = False

class ScanResultResponse(BaseModel):
    id: str
    target: str
    target_type: TargetTypeEnum
    scan_types: List[ScanTypeEnum]
    status: str # Queued, Running, Completed, Failed
    progress: int # 0 to 100
    start_time: str
    end_time: Optional[str] = None
    duration_seconds: Optional[int] = 0
    total_vulnerabilities: int = 0
    critical_count: int = 0
    high_count: int = 0
    medium_count: int = 0
    low_count: int = 0
    vulnerabilities: List[VulnerabilityItem] = []
    ai_analysis: Optional[AIRiskSummary] = None
    logs: List[str] = []
    requested_by: Optional[str] = None

# --- CVE Knowledgebase Models ---
class CveItem(BaseModel):
    cve_id: str
    title: str
    severity: SeverityEnum
    cvss_score: float
    cisa_kev: bool
    exploit_available: bool
    summary: str
    affected_products: List[str]
    published_date: str

# --- Scheduled / Recurring Scan Models ---
class ScheduleIntervalEnum(str, Enum):
    HOURLY = "Hourly"
    DAILY = "Daily"
    WEEKLY = "Weekly"

class ScheduleCreate(BaseModel):
    target: str
    target_type: TargetTypeEnum
    scan_types: List[ScanTypeEnum]
    interval: ScheduleIntervalEnum
    webhook_url: Optional[str] = None
    custom_headers: Optional[Dict[str, str]] = None

class ScheduleResponse(BaseModel):
    id: str
    target: str
    target_type: TargetTypeEnum
    scan_types: List[ScanTypeEnum]
    interval: ScheduleIntervalEnum
    webhook_url: Optional[str] = None
    created_by: str
    created_at: str
    next_run_at: str
    last_run_at: Optional[str] = None
    last_scan_id: Optional[str] = None
    enabled: bool = True
