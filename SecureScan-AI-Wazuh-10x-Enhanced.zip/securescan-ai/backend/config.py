import os
import secrets
import warnings
from pydantic import BaseModel
from typing import Optional, List, Dict, Any


def _resolve_secret_key() -> str:
    """
    Reads the JWT signing key from the environment. If none is set, a random
    key is generated for this process — this is safe for local/dev use but
    means tokens won't survive a restart across a multi-process deployment,
    so production deployments MUST set SECRET_KEY explicitly.
    """
    env_key = os.getenv("SECRET_KEY")
    if env_key:
        return env_key
    warnings.warn(
        "SECURITY WARNING: SECRET_KEY is not set in the environment. "
        "Generating a random key for this process. Set the SECRET_KEY "
        "environment variable before deploying to production, or all "
        "issued login sessions will be invalidated on every restart.",
        stacklevel=2
    )
    return secrets.token_hex(32)


class Settings:
    PROJECT_NAME: str = "SecureScan AI"
    CORS_ORIGINS: List[str] = [x.strip() for x in os.getenv("CORS_ORIGINS", "http://localhost:8000,http://127.0.0.1:8000").split(",") if x.strip()]
    VERSION: str = "1.0.0"
    API_PREFIX: str = "/api/v1"

    SECRET_KEY: str = _resolve_secret_key()
    ALGORITHM: str = "HS256"
    ACCESS_TOKEN_EXPIRE_MINUTES: int = int(os.getenv("ACCESS_TOKEN_EXPIRE_MINUTES", 60 * 24))  # 24 hours

    # Login brute-force protection
    LOGIN_MAX_ATTEMPTS: int = int(os.getenv("LOGIN_MAX_ATTEMPTS", 5))
    LOGIN_LOCKOUT_SECONDS: int = int(os.getenv("LOGIN_LOCKOUT_SECONDS", 300))  # 5 minutes

    # AI Risk Integration Config
    ANTHROPIC_API_KEY: Optional[str] = os.getenv("ANTHROPIC_API_KEY", "")
    DEFAULT_AI_MODEL: str = os.getenv("DEFAULT_AI_MODEL", "claude-sonnet-4-6")

    # Storage & Upload Config
    UPLOAD_DIR: str = os.path.join(os.path.dirname(__file__), "uploads")
    REPORTS_DIR: str = os.path.join(os.path.dirname(__file__), "reports")

    MAX_UPLOAD_SIZE_BYTES: int = int(os.getenv("MAX_UPLOAD_SIZE_MB", 100)) * 1024 * 1024  # 100 MB default
    ALLOWED_UPLOAD_EXTENSIONS: List[str] = [".zip", ".tar", ".tar.gz", ".tgz", ".gz"]

    # Extracted archives may not exceed this total uncompressed size (zip-bomb guard)
    MAX_EXTRACTED_SIZE_BYTES: int = int(os.getenv("MAX_EXTRACTED_SIZE_MB", 500)) * 1024 * 1024
    MAX_ARCHIVE_FILE_COUNT: int = int(os.getenv("MAX_ARCHIVE_FILE_COUNT", 20000))

    # Scan target safety — private/internal ranges and cloud metadata endpoints are
    # blocked by default so this platform cannot be used to probe the host's own
    # internal network or cloud metadata service (SSRF-style abuse prevention).
    ALLOW_INTERNAL_SCAN_TARGETS: bool = os.getenv("ALLOW_INTERNAL_SCAN_TARGETS", "false").lower() == "true"

    # Wazuh SIEM / SOC Integration Config
    WAZUH_HOST: str = os.getenv("WAZUH_HOST", "192.168.56.10")
    WAZUH_SYSLOG_PORT: int = int(os.getenv("WAZUH_SYSLOG_PORT", 514))
    WAZUH_ENABLED: bool = os.getenv("WAZUH_ENABLED", "true").lower() == "true"
    WAZUH_PROTOCOL: str = os.getenv("WAZUH_PROTOCOL", "tcp").lower()  # tcp | udp
    # Optional read-back (dashboard shows real Wazuh alerts / manager info)
    WAZUH_API_URL: str = os.getenv("WAZUH_API_URL", "")            # e.g. https://192.168.56.10:55000
    WAZUH_API_USER: str = os.getenv("WAZUH_API_USER", "wazuh")
    WAZUH_API_PASSWORD: str = os.getenv("WAZUH_API_PASSWORD", "")
    WAZUH_INDEXER_URL: str = os.getenv("WAZUH_INDEXER_URL", "")    # e.g. https://192.168.56.10:9200
    WAZUH_INDEXER_USER: str = os.getenv("WAZUH_INDEXER_USER", "admin")
    WAZUH_INDEXER_PASSWORD: str = os.getenv("WAZUH_INDEXER_PASSWORD", "")
    WAZUH_VERIFY_TLS: bool = os.getenv("WAZUH_VERIFY_TLS", "false").lower() == "true"
    WAZUH_VERSION: str = os.getenv("WAZUH_VERSION", "4.14")
    WAZUH_VULN_INDEX: str = os.getenv("WAZUH_VULN_INDEX", "wazuh-states-vulnerabilities-*")
    WAZUH_OUTBOX_MAX_RETRIES: int = int(os.getenv("WAZUH_OUTBOX_MAX_RETRIES", "12"))
    WAZUH_OUTBOX_BATCH_SIZE: int = int(os.getenv("WAZUH_OUTBOX_BATCH_SIZE", "100"))
    WAZUH_OUTBOX_POLL_SECONDS: float = float(os.getenv("WAZUH_OUTBOX_POLL_SECONDS", "2"))

settings = Settings()

os.makedirs(settings.UPLOAD_DIR, exist_ok=True)
os.makedirs(settings.REPORTS_DIR, exist_ok=True)
