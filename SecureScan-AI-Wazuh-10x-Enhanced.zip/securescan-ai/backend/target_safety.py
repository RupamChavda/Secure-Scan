"""
Scan-target safety checks.

Because this platform performs LIVE outbound network requests (HTTP, raw TCP
connects, TLS handshakes) against whatever target a user supplies, an
uncontrolled deployment could be abused as an SSRF proxy — e.g. pointed at
169.254.169.254 (cloud instance metadata) or an internal-only IP to probe a
network it shouldn't have access to. These checks block that by default.
"""
import ipaddress
import socket
from urllib.parse import urlparse

from backend.config import settings

# Cloud metadata endpoints across major providers — always blocked regardless
# of the ALLOW_INTERNAL_SCAN_TARGETS setting, since there is essentially never
# a legitimate reason for this platform to scan them.
BLOCKED_METADATA_HOSTS = {
    "169.254.169.254",   # AWS / Azure / GCP / DigitalOcean metadata service
    "metadata.google.internal",
    "metadata.azure.com",
}


class UnsafeScanTargetError(Exception):
    pass


def _extract_host(target: str) -> str:
    target = target.strip()
    if "://" in target:
        parsed = urlparse(target)
        return parsed.hostname or target
    host = target.split("/")[0]
    host = host.split(":")[0]
    return host


def _is_private_or_reserved(ip_str: str) -> bool:
    try:
        ip = ipaddress.ip_address(ip_str)
    except ValueError:
        return False
    return (
        ip.is_private
        or ip.is_loopback
        or ip.is_link_local
        or ip.is_reserved
        or ip.is_multicast
        or ip.is_unspecified
    )


def assess_scan_target(target: str):
    """
    Raises UnsafeScanTargetError if the target resolves to a blocked address.
    Cloud metadata endpoints are always blocked. Private/internal/loopback
    ranges are blocked unless ALLOW_INTERNAL_SCAN_TARGETS=true is set in the
    environment (useful for scanning your own internal infrastructure in a
    trusted deployment).
    """
    host = _extract_host(target)
    if not host:
        return  # nothing resolvable (e.g. an uploaded archive scan) — not a network target

    if host.lower() in BLOCKED_METADATA_HOSTS:
        raise UnsafeScanTargetError(
            f"'{host}' is a cloud instance metadata endpoint and cannot be scanned. "
            "Scanning this address could expose sensitive credentials belonging to the host running this platform."
        )

    # Resolve to an IP for range checks (also blocks hostnames that resolve to metadata/private IPs).
    try:
        resolved_ip = socket.gethostbyname(host)
    except Exception:
        return  # unresolvable host — let the scan engine report that naturally

    if resolved_ip in BLOCKED_METADATA_HOSTS:
        raise UnsafeScanTargetError(
            f"'{host}' resolves to a cloud instance metadata address ({resolved_ip}) and cannot be scanned."
        )

    if not settings.ALLOW_INTERNAL_SCAN_TARGETS and _is_private_or_reserved(resolved_ip):
        raise UnsafeScanTargetError(
            f"'{host}' resolves to a private/internal address ({resolved_ip}). Scanning internal network ranges is "
            "disabled by default to prevent this platform from being used to probe its own host network. "
            "An administrator can enable this by setting ALLOW_INTERNAL_SCAN_TARGETS=true in the environment."
        )
