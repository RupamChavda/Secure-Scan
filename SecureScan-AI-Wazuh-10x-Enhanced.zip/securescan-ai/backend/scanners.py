import subprocess
import json
import time
import xml.etree.ElementTree as ET
import os
import re
import ssl
import socket
import shutil
import zipfile
import tarfile
import requests
from datetime import datetime
from urllib.parse import urlparse
from typing import List, Dict, Any, Optional
from concurrent.futures import ThreadPoolExecutor, as_completed

from backend.models import SeverityEnum
from backend.config import settings

# ============================================================================
# These scanners perform REAL, LIVE checks against the target wherever
# possible (live sockets, live HTTP requests, live TLS handshakes, static
# analysis of uploaded source code) instead of only returning canned data.
# When an optional external tool (nmap / trivy / OWASP ZAP / OpenVAS) is
# available on the host, it is used as well for deeper coverage.
# ============================================================================


def _severity_from_cvss(score: float) -> SeverityEnum:
    if score >= 9.0:
        return SeverityEnum.CRITICAL
    if score >= 7.0:
        return SeverityEnum.HIGH
    if score >= 4.0:
        return SeverityEnum.MEDIUM
    if score > 0:
        return SeverityEnum.LOW
    return SeverityEnum.INFO


def _extract_host(target: str) -> str:
    """Normalizes a URL / bare host / IP into a plain hostname."""
    target = target.strip()
    if "://" in target:
        parsed = urlparse(target)
        return parsed.hostname or target
    # strip path / port if present, e.g. "example.com/foo" or "1.2.3.4:8080"
    host = target.split("/")[0]
    host = host.split(":")[0]
    return host


# --- 1. LIVE PORT SCANNER (pure-python TCP connect scan, no external tool required) ---
COMMON_PORTS = {
    21: ("FTP", "Unencrypted file transfer protocol"),
    22: ("SSH", "Remote administration shell"),
    23: ("Telnet", "Unencrypted remote administration"),
    25: ("SMTP", "Mail transfer service"),
    53: ("DNS", "Domain name resolution service"),
    80: ("HTTP", "Unencrypted web service"),
    110: ("POP3", "Unencrypted mail retrieval"),
    135: ("MSRPC", "Windows RPC endpoint mapper"),
    139: ("NetBIOS", "Windows file sharing (legacy)"),
    143: ("IMAP", "Unencrypted mail retrieval"),
    443: ("HTTPS", "Encrypted web service"),
    445: ("SMB", "Windows file sharing"),
    1433: ("MSSQL", "Microsoft SQL Server database"),
    3306: ("MySQL", "MySQL / MariaDB database"),
    3389: ("RDP", "Windows Remote Desktop Protocol"),
    5432: ("PostgreSQL", "PostgreSQL database"),
    5900: ("VNC", "Remote desktop / screen sharing"),
    6379: ("Redis", "In-memory data store"),
    8080: ("HTTP-Alt", "Alternate / proxy web service"),
    9200: ("Elasticsearch", "Search / document database"),
    27017: ("MongoDB", "MongoDB database"),
}

RISKY_EXPOSED_PORTS = {21, 23, 135, 139, 445, 1433, 3306, 3389, 5432, 5900, 6379, 9200, 27017}

# Extra ports scanned in addition to COMMON_PORTS now that scanning is
# parallelized and can afford broader coverage without a large time cost.
EXTENDED_PORTS = {
    111: ("RPCbind", "Legacy Unix RPC portmapper"),
    161: ("SNMP", "Simple Network Management Protocol"),
    389: ("LDAP", "Directory service"),
    636: ("LDAPS", "Encrypted directory service"),
    993: ("IMAPS", "Encrypted mail retrieval"),
    995: ("POP3S", "Encrypted mail retrieval"),
    1521: ("Oracle DB", "Oracle database listener"),
    2049: ("NFS", "Network File System"),
    2375: ("Docker API", "Unencrypted Docker daemon API"),
    2376: ("Docker API (TLS)", "Docker daemon API over TLS"),
    5000: ("HTTP-Alt", "Common dev/app server port"),
    5601: ("Kibana", "Elasticsearch dashboard"),
    5984: ("CouchDB", "CouchDB database"),
    8000: ("HTTP-Alt", "Common dev/app server port"),
    8443: ("HTTPS-Alt", "Alternate encrypted web service"),
    9000: ("HTTP-Alt / SonarQube", "Common dev tool or app port"),
    9090: ("Prometheus", "Metrics/monitoring endpoint"),
    9092: ("Kafka", "Kafka message broker"),
    11211: ("Memcached", "In-memory caching service"),
    50000: ("SAP / DB2", "Enterprise database service"),
}
RISKY_EXTENDED_PORTS = {161, 2375, 5984, 9200, 11211, 1521, 2049}


def _scan_single_port(resolved_ip: str, port: int, timeout: float) -> bool:
    try:
        with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as sock:
            sock.settimeout(timeout)
            return sock.connect_ex((resolved_ip, port)) == 0
    except Exception:
        return False


def run_live_port_scan(target: str, timeout: float = 0.8, include_extended: bool = True, max_workers: int = 25) -> List[Dict[str, Any]]:
    """
    Performs a real live TCP connect scan of common (and, by default,
    extended) service ports against the target host, scanning ports
    concurrently via a thread pool so broader coverage doesn't come at the
    cost of a slow sequential scan. Runs dynamically for whatever target is
    supplied and does not depend on any external binary being installed.
    """
    findings: List[Dict[str, Any]] = []
    host = _extract_host(target)

    try:
        resolved_ip = socket.gethostbyname(host)
    except Exception as e:
        findings.append({
            "title": f"Target Host '{host}' Could Not Be Resolved",
            "severity": SeverityEnum.INFO,
            "cvss_score": 0.0,
            "cve_id": "N/A",
            "owasp_category": "N/A",
            "mitre_attack": "N/A",
            "description": f"DNS resolution failed for '{host}': {e}. Live network probing was skipped for this target.",
            "evidence": f"socket.gethostbyname('{host}') raised: {e}",
            "remediation": "Verify the target hostname/IP is correct and reachable from the scanner."
        })
        return findings

    port_catalog = dict(COMMON_PORTS)
    if include_extended:
        port_catalog.update(EXTENDED_PORTS)
    risky_ports = RISKY_EXPOSED_PORTS | (RISKY_EXTENDED_PORTS if include_extended else set())

    open_ports = []
    with ThreadPoolExecutor(max_workers=max_workers) as executor:
        future_to_port = {
            executor.submit(_scan_single_port, resolved_ip, port, timeout): (port, service, desc)
            for port, (service, desc) in port_catalog.items()
        }
        for future in as_completed(future_to_port):
            port, service, desc = future_to_port[future]
            try:
                if future.result():
                    open_ports.append((port, service, desc))
            except Exception:
                continue

    if not open_ports:
        findings.append({
            "title": "Live Port Scan Completed — No Common Ports Open",
            "severity": SeverityEnum.INFO,
            "cvss_score": 0.0,
            "cve_id": "N/A",
            "owasp_category": "A05:2021-Security Misconfiguration",
            "mitre_attack": "T1046 - Network Service Discovery",
            "description": f"A live, parallelized TCP scan of {len(port_catalog)} common and extended service ports against {host} ({resolved_ip}) found none open. This is a good sign — it reduces the target's exposed attack surface.",
            "evidence": f"Scanned ports: {', '.join(str(p) for p in sorted(port_catalog))} — all closed/filtered.",
            "remediation": "No action required. Continue to periodically re-scan as infrastructure changes."
        })
        return findings

    for port, service, desc in open_ports:
        is_risky = port in risky_ports
        severity = SeverityEnum.HIGH if is_risky else SeverityEnum.LOW
        cvss = 8.2 if is_risky else 3.1
        findings.append({
            "title": f"Open Network Port Discovered: {port}/tcp ({service})",
            "severity": severity,
            "cvss_score": cvss,
            "cve_id": "N/A",
            "owasp_category": "A05:2021-Security Misconfiguration",
            "mitre_attack": "T1046 - Network Service Discovery",
            "description": f"Live TCP scan confirms port {port} ({service} — {desc}) is open and accepting connections on {host} ({resolved_ip}). "
                            + ("This service is commonly targeted by attackers when exposed to the internet without strong authentication."
                               if is_risky else "This is a lower-risk service but should still be reviewed if unexpected."),
            "evidence": f"TCP connect() to {resolved_ip}:{port} succeeded (RESULT=0/OPEN).",
            "remediation": f"If {service} on port {port} does not need to be publicly reachable, restrict it with a firewall/security group to trusted IP ranges only, and ensure strong authentication is enforced."
        })

    return findings


# --- 2. LIVE HTTP SECURITY HEADER & CONFIGURATION SCANNER ---
SECURITY_HEADERS = {
    "Strict-Transport-Security": ("A02:2021-Cryptographic Failures", "Forces browsers to only use HTTPS, preventing downgrade/SSL-stripping attacks."),
    "Content-Security-Policy": ("A03:2021-Injection", "Restricts which scripts/resources a page can load, mitigating Cross-Site Scripting (XSS)."),
    "X-Frame-Options": ("A05:2021-Security Misconfiguration", "Prevents the site from being embedded in a hidden iframe (clickjacking)."),
    "X-Content-Type-Options": ("A05:2021-Security Misconfiguration", "Stops browsers from guessing (\"sniffing\") file types, which can be abused to run malicious scripts."),
    "Referrer-Policy": ("A05:2021-Security Misconfiguration", "Controls how much URL/referrer information leaks to other sites."),
}


def run_http_security_scan(target: str, custom_headers: Optional[Dict[str, str]] = None) -> List[Dict[str, Any]]:
    """
    Performs a real live HTTP(S) request against the target and inspects the
    actual response headers, cookies, and status codes for common
    misconfigurations. Dynamic — output depends entirely on the live response.

    If custom_headers is supplied (e.g. an Authorization bearer token or a
    session Cookie), it is attached to every request so the scanner can
    reach pages that sit behind a login wall — authenticated scanning.
    """
    findings: List[Dict[str, Any]] = []
    url = target if target.startswith("http") else f"https://{target}"
    req_headers = custom_headers or {}
    authenticated = bool(req_headers)

    try:
        resp = requests.get(url, timeout=6, allow_redirects=True, verify=True, headers=req_headers)
    except requests.exceptions.SSLError:
        # Retry over plain HTTP if TLS handshake fails, but flag it.
        try:
            fallback_url = target if target.startswith("http") else f"http://{target}"
            resp = requests.get(fallback_url, timeout=6, allow_redirects=True, headers=req_headers)
            findings.append({
                "title": "HTTPS Connection Failed — Site May Not Enforce Encryption",
                "severity": SeverityEnum.HIGH,
                "cvss_score": 7.4,
                "cve_id": "N/A",
                "owasp_category": "A02:2021-Cryptographic Failures",
                "mitre_attack": "T1557 - Adversary-in-the-Middle",
                "description": "An HTTPS connection to this target failed (invalid/self-signed certificate or no TLS listener), so traffic may be transmitted without encryption.",
                "evidence": f"HTTPS request to {url} raised an SSL error; fell back to plain HTTP for further checks.",
                "remediation": "Install a valid TLS certificate (e.g. via Let's Encrypt) and redirect all HTTP traffic to HTTPS."
            })
        except Exception as e:
            findings.append({
                "title": "Target Web Service Unreachable",
                "severity": SeverityEnum.INFO,
                "cvss_score": 0.0,
                "cve_id": "N/A",
                "owasp_category": "N/A",
                "mitre_attack": "N/A",
                "description": f"Could not establish an HTTP or HTTPS connection to '{target}'.",
                "evidence": str(e),
                "remediation": "Verify the target URL is correct, publicly reachable, and not blocked by a firewall."
            })
            return findings
    except Exception as e:
        findings.append({
            "title": "Target Web Service Unreachable",
            "severity": SeverityEnum.INFO,
            "cvss_score": 0.0,
            "cve_id": "N/A",
            "owasp_category": "N/A",
            "mitre_attack": "N/A",
            "description": f"Could not establish a connection to '{target}' to run web security checks.",
            "evidence": str(e),
            "remediation": "Verify the target URL is correct, publicly reachable, and not blocked by a firewall."
        })
        return findings

    headers = resp.headers

    if authenticated:
        findings.append({
            "title": "Authenticated Scan Mode Active",
            "severity": SeverityEnum.INFO,
            "cvss_score": 0.0,
            "cve_id": "N/A",
            "owasp_category": "N/A",
            "mitre_attack": "N/A",
            "description": f"This scan used supplied authentication credentials (headers/cookies) to check {url}, so results reflect the page as seen by a logged-in user rather than the public/anonymous view.",
            "evidence": f"Request included {len(req_headers)} custom header(s). HTTP {resp.status_code} received.",
            "remediation": "No action required — this is informational confirmation that authenticated scanning was used."
        })

    # Missing security headers — real, based on the live response
    missing = [h for h in SECURITY_HEADERS if h not in headers]
    if missing:
        missing_desc = "\n".join([f"- {h}: {SECURITY_HEADERS[h][1]}" for h in missing])
        findings.append({
            "title": f"Missing HTTP Security Headers ({len(missing)} of {len(SECURITY_HEADERS)} recommended headers absent)",
            "severity": SeverityEnum.MEDIUM if len(missing) < 4 else SeverityEnum.HIGH,
            "cvss_score": 5.3 if len(missing) < 4 else 6.8,
            "cve_id": "N/A",
            "owasp_category": "A05:2021-Security Misconfiguration",
            "mitre_attack": "T1189 - Drive-by Compromise",
            "description": f"The live response from {url} is missing {len(missing)} recommended security headers:\n{missing_desc}",
            "evidence": f"HTTP {resp.status_code} response headers observed: {dict(headers)}",
            "remediation": "Configure the web server / application framework to emit the missing headers listed above."
        })

    # Server / technology banner disclosure
    server_banner = headers.get("Server") or headers.get("X-Powered-By")
    if server_banner:
        findings.append({
            "title": "Server Technology Banner Disclosed in Response Headers",
            "severity": SeverityEnum.LOW,
            "cvss_score": 3.1,
            "cve_id": "N/A",
            "owasp_category": "A05:2021-Security Misconfiguration",
            "mitre_attack": "T1592 - Gather Victim Host Information",
            "description": f"The server discloses its underlying software/version ('{server_banner}'), which helps attackers select known exploits for that exact version.",
            "evidence": f"Response header: Server/X-Powered-By = {server_banner}",
            "remediation": "Suppress or genericize the Server/X-Powered-By response header in the web server configuration."
        })

    # Cookies without Secure / HttpOnly flags
    insecure_cookies = []
    for cookie in resp.cookies:
        flags_missing = []
        raw = str(cookie).lower()
        if not cookie.secure:
            flags_missing.append("Secure")
        if not (hasattr(cookie, "_rest") and "httponly" in {k.lower() for k in getattr(cookie, "_rest", {})}):
            flags_missing.append("HttpOnly")
        if flags_missing:
            insecure_cookies.append((cookie.name, flags_missing))

    if insecure_cookies:
        cookie_desc = "; ".join([f"{name} (missing {', '.join(flags)})" for name, flags in insecure_cookies])
        findings.append({
            "title": "Session Cookies Missing Secure/HttpOnly Flags",
            "severity": SeverityEnum.MEDIUM,
            "cvss_score": 5.4,
            "cve_id": "N/A",
            "owasp_category": "A05:2021-Security Misconfiguration",
            "mitre_attack": "T1539 - Steal Web Session Cookie",
            "description": "Cookies issued by this site can be read by JavaScript and/or transmitted over unencrypted connections, increasing the risk of session hijacking.",
            "evidence": f"Cookies observed: {cookie_desc}",
            "remediation": "Set the 'Secure' and 'HttpOnly' (and ideally 'SameSite=Strict') flags on all session cookies."
        })

    # Reflected input probe (safe, non-destructive XSS canary on query string)
    try:
        probe_marker = "sscanxss123"
        probe_url = url + ("&" if "?" in url else "?") + f"q={probe_marker}"
        probe_resp = requests.get(probe_url, timeout=5, headers=req_headers)
        if probe_marker in probe_resp.text:
            findings.append({
                "title": "Unsanitized Input Reflection Detected (Potential XSS Vector)",
                "severity": SeverityEnum.HIGH,
                "cvss_score": 7.2,
                "cve_id": "N/A",
                "owasp_category": "A03:2021-Injection",
                "mitre_attack": "T1189 - Drive-by Compromise",
                "description": "A harmless test string sent in a query parameter was reflected back unmodified in the page response. If this value is later rendered without encoding, it can be an entry point for Cross-Site Scripting.",
                "evidence": f"GET {probe_url} -> response body contains the literal marker '{probe_marker}'.",
                "remediation": "Ensure all user-supplied input is contextually encoded/escaped before being rendered back into HTML."
            })
    except Exception:
        pass

    if resp.status_code >= 500:
        findings.append({
            "title": f"Server Error Response Observed (HTTP {resp.status_code})",
            "severity": SeverityEnum.LOW,
            "cvss_score": 3.7,
            "cve_id": "N/A",
            "owasp_category": "A05:2021-Security Misconfiguration",
            "mitre_attack": "N/A",
            "description": "The server returned an internal error during the scan, which can sometimes leak stack traces or internal details.",
            "evidence": f"GET {url} -> HTTP {resp.status_code}",
            "remediation": "Review application logs for the corresponding error and ensure verbose error/debug pages are disabled in production."
        })

    return findings


# --- 3. LIVE TLS/SSL CERTIFICATE & PROTOCOL SCANNER ---
def run_ssl_scan(target: str, port: int = 443) -> List[Dict[str, Any]]:
    """
    Opens a real TLS handshake against the target and inspects the negotiated
    protocol version and certificate expiry.
    """
    findings: List[Dict[str, Any]] = []
    host = _extract_host(target)

    try:
        ctx = ssl.create_default_context()
        with socket.create_connection((host, port), timeout=6) as sock:
            with ctx.wrap_socket(sock, server_hostname=host) as ssock:
                cert = ssock.getpeercert()
                protocol = ssock.version()

        # Protocol version check
        weak_protocols = {"TLSv1", "TLSv1.1", "SSLv3", "SSLv2"}
        if protocol in weak_protocols:
            findings.append({
                "title": f"Outdated TLS Protocol Negotiated ({protocol})",
                "severity": SeverityEnum.HIGH,
                "cvss_score": 7.5,
                "cve_id": "CVE-2014-3566" if protocol == "SSLv3" else "N/A",
                "owasp_category": "A02:2021-Cryptographic Failures",
                "mitre_attack": "T1040 - Network Sniffing",
                "description": f"The server negotiated {protocol}, an outdated and deprecated TLS/SSL protocol version with known cryptographic weaknesses.",
                "evidence": f"Live TLS handshake to {host}:{port} negotiated protocol version: {protocol}",
                "remediation": "Disable TLS 1.0/1.1 and SSLv3 on the server; require TLS 1.2 or TLS 1.3 only."
            })

        # Certificate expiry check
        not_after = cert.get("notAfter") if cert else None
        if not_after:
            try:
                expire_dt = datetime.strptime(not_after, "%b %d %H:%M:%S %Y %Z")
                days_left = (expire_dt - datetime.utcnow()).days
                if days_left < 0:
                    findings.append({
                        "title": "TLS Certificate Has Expired",
                        "severity": SeverityEnum.CRITICAL,
                        "cvss_score": 9.1,
                        "cve_id": "N/A",
                        "owasp_category": "A02:2021-Cryptographic Failures",
                        "mitre_attack": "T1557 - Adversary-in-the-Middle",
                        "description": f"The TLS certificate presented by {host} expired on {not_after}. Browsers will show security warnings, and encrypted trust cannot be verified.",
                        "evidence": f"Certificate notAfter = {not_after}",
                        "remediation": "Renew the TLS certificate immediately and enable auto-renewal (e.g. Let's Encrypt/Certbot)."
                    })
                elif days_left < 30:
                    findings.append({
                        "title": f"TLS Certificate Expiring Soon ({days_left} days remaining)",
                        "severity": SeverityEnum.MEDIUM,
                        "cvss_score": 5.0,
                        "cve_id": "N/A",
                        "owasp_category": "A02:2021-Cryptographic Failures",
                        "mitre_attack": "N/A",
                        "description": f"The TLS certificate for {host} expires on {not_after}, which is within the next 30 days.",
                        "evidence": f"Certificate notAfter = {not_after}",
                        "remediation": "Renew the certificate before expiry to avoid a service outage or browser warning."
                    })
            except Exception:
                pass

        if not findings:
            findings.append({
                "title": "TLS Configuration Check Passed",
                "severity": SeverityEnum.INFO,
                "cvss_score": 0.0,
                "cve_id": "N/A",
                "owasp_category": "A02:2021-Cryptographic Failures",
                "mitre_attack": "N/A",
                "description": f"Live handshake to {host}:{port} negotiated {protocol} with a currently valid certificate — no issues found.",
                "evidence": f"Protocol: {protocol}, Certificate notAfter: {not_after}",
                "remediation": "No action required. Continue periodic re-scanning."
            })

    except Exception as e:
        findings.append({
            "title": "TLS/SSL Handshake Could Not Be Completed",
            "severity": SeverityEnum.INFO,
            "cvss_score": 0.0,
            "cve_id": "N/A",
            "owasp_category": "N/A",
            "mitre_attack": "N/A",
            "description": f"A TLS connection to {host}:{port} could not be established, so certificate/protocol checks were skipped.",
            "evidence": str(e),
            "remediation": "If this host should serve HTTPS, verify port 443 is open and a valid certificate is installed."
        })

    return findings


# --- 4. STATIC CODE / SECRET / DEPENDENCY SCANNER (real file analysis of uploaded archives) ---
SECRET_PATTERNS = [
    ("AWS Access Key", re.compile(r"AKIA[0-9A-Z]{16}")),
    ("AWS Secret Key", re.compile(r"(?i)aws_secret_access_key\s*=\s*['\"][A-Za-z0-9/+=]{30,}['\"]")),
    ("Generic API Key", re.compile(r"(?i)(api[_-]?key|secret[_-]?key)\s*[:=]\s*['\"][A-Za-z0-9_\-]{16,}['\"]")),
    ("Private Key Block", re.compile(r"-----BEGIN (RSA |EC |OPENSSH |DSA )?PRIVATE KEY-----")),
    ("Hardcoded Password", re.compile(r"(?i)password\s*[:=]\s*['\"][^'\"]{4,}['\"]")),
    ("Slack Token", re.compile(r"xox[baprs]-[0-9A-Za-z-]{10,}")),
    ("Generic Bearer/JWT Token", re.compile(r"eyJ[A-Za-z0-9_-]{10,}\.[A-Za-z0-9_-]{10,}\.[A-Za-z0-9_-]{10,}")),
]

# Small local knowledgebase of known-vulnerable package versions for quick dependency triage.
KNOWN_VULNERABLE_PACKAGES = {
    "log4j-core": {"vulnerable_below": None, "vulnerable_versions": ["2.0", "2.14.1"], "cve": "CVE-2021-44228", "title": "Log4Shell RCE", "cvss": 10.0},
    "flask": {"vulnerable_versions": ["0.12", "0.12.1", "0.12.2"], "cve": "CVE-2018-1000656", "title": "Flask Denial of Service", "cvss": 7.5},
    "django": {"vulnerable_versions": ["2.2", "3.0", "3.1"], "cve": "CVE-2021-33203", "title": "Django Path Traversal", "cvss": 6.5},
    "requests": {"vulnerable_versions": ["2.19.1", "2.20.0"], "cve": "CVE-2018-18074", "title": "Requests Credential Leak on Redirect", "cvss": 6.1},
    "pyyaml": {"vulnerable_versions": ["5.1", "5.2", "5.3"], "cve": "CVE-2020-1747", "title": "PyYAML Arbitrary Code Execution", "cvss": 9.8},
    "urllib3": {"vulnerable_versions": ["1.24.1", "1.24.2"], "cve": "CVE-2019-11324", "title": "urllib3 CA Bypass", "cvss": 6.5},
    "jinja2": {"vulnerable_versions": ["2.10"], "cve": "CVE-2019-10906", "title": "Jinja2 Sandbox Escape", "cvss": 8.1},
    "lodash": {"vulnerable_versions": ["4.17.15", "4.17.14"], "cve": "CVE-2020-8203", "title": "Lodash Prototype Pollution", "cvss": 7.4},
    "log4net": {"vulnerable_versions": None, "cve": "CVE-2018-1149", "title": "log4net XXE", "cvss": 7.5},
}

TEXT_EXTENSIONS = {".py", ".js", ".ts", ".java", ".env", ".yml", ".yaml", ".json", ".txt", ".xml", ".properties", ".cfg", ".ini", ".go", ".rb", ".php"}


def _is_within_directory(base_dir: str, target_path: str) -> bool:
    """Zip-slip guard: ensures an extracted entry cannot escape the target directory
    via '../' path traversal tricks embedded in a malicious archive entry name."""
    base_dir = os.path.realpath(base_dir)
    target_path = os.path.realpath(target_path)
    return os.path.commonpath([base_dir]) == os.path.commonpath([base_dir, target_path])


def _safe_extract_zip(zf: zipfile.ZipFile, dest_dir: str, max_files: int = None, max_total_bytes: int = None):
    max_files = max_files or settings.MAX_ARCHIVE_FILE_COUNT
    max_total_bytes = max_total_bytes or settings.MAX_EXTRACTED_SIZE_BYTES
    infos = zf.infolist()
    if len(infos) > max_files:
        raise ValueError(f"Archive contains {len(infos)} entries, exceeding the {max_files} file safety limit (possible zip bomb).")

    total_size = 0
    for info in infos:
        total_size += info.file_size
        if total_size > max_total_bytes:
            raise ValueError(f"Archive's uncompressed size exceeds the {max_total_bytes // (1024*1024)}MB safety limit (possible zip bomb).")

        member_path = os.path.join(dest_dir, info.filename)
        if not _is_within_directory(dest_dir, member_path):
            raise ValueError(f"Blocked unsafe archive entry attempting path traversal: {info.filename}")

    zf.extractall(dest_dir)


def _safe_extract_tar(tf: tarfile.TarFile, dest_dir: str, max_files: int = None, max_total_bytes: int = None):
    max_files = max_files or settings.MAX_ARCHIVE_FILE_COUNT
    max_total_bytes = max_total_bytes or settings.MAX_EXTRACTED_SIZE_BYTES
    members = tf.getmembers()
    if len(members) > max_files:
        raise ValueError(f"Archive contains {len(members)} entries, exceeding the {max_files} file safety limit (possible zip/tar bomb).")

    total_size = 0
    for member in members:
        total_size += member.size
        if total_size > max_total_bytes:
            raise ValueError(f"Archive's uncompressed size exceeds the {max_total_bytes // (1024*1024)}MB safety limit (possible zip/tar bomb).")

        member_path = os.path.join(dest_dir, member.name)
        if not _is_within_directory(dest_dir, member_path):
            raise ValueError(f"Blocked unsafe archive entry attempting path traversal: {member.name}")
        if member.issym() or member.islnk():
            raise ValueError(f"Blocked symlink entry in archive (not permitted): {member.name}")

    tf.extractall(dest_dir)


def _extract_archive(archive_path: str, dest_dir: str):
    """Returns (success: bool, error_message: Optional[str])."""
    try:
        if archive_path.lower().endswith(".zip"):
            with zipfile.ZipFile(archive_path, "r") as zf:
                _safe_extract_zip(zf, dest_dir)
            return True, None
        if archive_path.lower().endswith((".tar", ".tar.gz", ".tgz", ".gz")):
            with tarfile.open(archive_path, "r:*") as tf:
                _safe_extract_tar(tf, dest_dir)
            return True, None
    except Exception as e:
        return False, str(e)
    return False, "Unsupported archive format."


def run_static_code_scan(archive_path: str) -> List[Dict[str, Any]]:
    """
    Real static analysis: extracts the uploaded project archive and scans
    every text file for hardcoded secrets, then checks dependency manifest
    files (requirements.txt / package.json) against a known-vulnerable
    package table. Findings are generated dynamically from actual file
    contents rather than pre-written text.
    """
    findings: List[Dict[str, Any]] = []

    if not archive_path or not os.path.exists(archive_path):
        return findings

    extract_dir = archive_path + "_extracted"
    os.makedirs(extract_dir, exist_ok=True)
    extracted, extract_error = _extract_archive(archive_path, extract_dir)

    if not extracted:
        findings.append({
            "title": "Archive Could Not Be Safely Extracted for Static Analysis",
            "severity": SeverityEnum.INFO,
            "cvss_score": 0.0,
            "cve_id": "N/A",
            "owasp_category": "N/A",
            "mitre_attack": "N/A",
            "description": f"The uploaded file '{os.path.basename(archive_path)}' could not be extracted: {extract_error or 'invalid or corrupted archive'}. "
                            "If this was blocked by a safety check (path traversal or size limit), the archive may not be safe to process.",
            "evidence": f"Attempted extraction of {archive_path} failed: {extract_error}",
            "remediation": "Re-upload the project as a valid, reasonably-sized .zip or .tar.gz archive without unusual internal paths."
        })
        shutil.rmtree(extract_dir, ignore_errors=True)
        return findings

    secret_hits: Dict[str, List[str]] = {}
    files_scanned = 0

    for root, _dirs, files in os.walk(extract_dir):
        for fname in files:
            ext = os.path.splitext(fname)[1].lower()
            fpath = os.path.join(root, fname)

            # Secret scanning on plausible text files (skip huge/binary files)
            if ext in TEXT_EXTENSIONS or fname in (".env", "config.py", "settings.py"):
                try:
                    if os.path.getsize(fpath) > 2_000_000:
                        continue
                    with open(fpath, "r", encoding="utf-8", errors="ignore") as f:
                        content = f.read()
                    files_scanned += 1
                    rel_path = os.path.relpath(fpath, extract_dir)
                    for label, pattern in SECRET_PATTERNS:
                        if pattern.search(content):
                            secret_hits.setdefault(label, []).append(rel_path)
                except Exception:
                    continue

            # Dependency manifest checks
            if fname == "requirements.txt":
                findings.extend(_scan_requirements_file(fpath, extract_dir))
            elif fname == "package.json":
                findings.extend(_scan_package_json(fpath, extract_dir))

    for label, files_list in secret_hits.items():
        files_preview = ", ".join(files_list[:5]) + (f" (+{len(files_list) - 5} more)" if len(files_list) > 5 else "")
        findings.append({
            "title": f"Hardcoded Secret Detected in Source Code: {label}",
            "severity": SeverityEnum.CRITICAL,
            "cvss_score": 9.1,
            "cve_id": "N/A",
            "owasp_category": "A07:2021-Identification and Authentication Failures",
            "mitre_attack": "T1552 - Unsecured Credentials",
            "description": f"Static analysis found what appears to be a {label} committed directly inside the source code. Anyone with access to this code (including via a leaked repository) could steal and misuse it.",
            "evidence": f"Pattern match for '{label}' found in: {files_preview}",
            "remediation": f"Revoke/rotate the exposed {label} immediately, remove it from the codebase and git history, and load secrets from environment variables or a secret manager instead."
        })

    if files_scanned and not secret_hits:
        findings.append({
            "title": "Static Secret Scan Completed — No Hardcoded Credentials Found",
            "severity": SeverityEnum.INFO,
            "cvss_score": 0.0,
            "cve_id": "N/A",
            "owasp_category": "A07:2021-Identification and Authentication Failures",
            "mitre_attack": "N/A",
            "description": f"Scanned {files_scanned} source files for hardcoded API keys, passwords, and private keys — none were found.",
            "evidence": f"{files_scanned} text/config files analyzed.",
            "remediation": "No action required. Continue to avoid committing secrets to source control."
        })

    shutil.rmtree(extract_dir, ignore_errors=True)
    return findings


OSV_BATCH_API_URL = "https://api.osv.dev/v1/querybatch"
OSV_VULN_DETAIL_URL = "https://api.osv.dev/v1/vulns/{}"


def _osv_severity_to_cvss(vuln: dict) -> float:
    """Best-effort extraction of a CVSS-like score from an OSV vulnerability record."""
    for sev in vuln.get("severity", []) or []:
        if sev.get("type", "").startswith("CVSS"):
            # OSV stores the CVSS vector string, not a bare score; a full parse isn't
            # worth the complexity here, so fall back to a sensible default band
            # based on presence of a CVSS entry at all (treated as at least High).
            return 7.5
    database_specific = vuln.get("database_specific", {}) or {}
    sev_str = str(database_specific.get("severity", "")).upper()
    return {"CRITICAL": 9.5, "HIGH": 7.8, "MODERATE": 5.5, "MEDIUM": 5.5, "LOW": 3.0}.get(sev_str, 6.5)


def _query_osv_batch(queries: List[Dict[str, Any]], timeout: int = 8) -> Optional[List[Dict[str, Any]]]:
    """
    Queries the live OSV.dev vulnerability database for a batch of
    package/version/ecosystem combinations. Returns None (not an empty list)
    on any failure so callers can distinguish "checked, found nothing" from
    "couldn't reach the live database, fall back to the local table".
    """
    if not queries:
        return []
    try:
        resp = requests.post(OSV_BATCH_API_URL, json={"queries": queries}, timeout=timeout)
        if resp.status_code != 200:
            return None
        results = resp.json().get("results", [])
        return results
    except requests.RequestException:
        return None
    except Exception:
        return None


def _scan_requirements_file(fpath: str, extract_dir: str) -> List[Dict[str, Any]]:
    findings = []
    rel_path = os.path.relpath(fpath, extract_dir)
    try:
        with open(fpath, "r", encoding="utf-8", errors="ignore") as f:
            lines = f.readlines()
    except Exception:
        return findings

    pinned_packages = []  # (pkg, version)
    for line in lines:
        line = line.strip()
        if not line or line.startswith("#"):
            continue
        match = re.match(r"^([A-Za-z0-9_\-\.]+)\s*==\s*([0-9A-Za-z\.\-]+)", line)
        if match:
            pinned_packages.append((match.group(1).lower(), match.group(2)))

    if not pinned_packages:
        return findings

    osv_queries = [{"version": ver, "package": {"name": pkg, "ecosystem": "PyPI"}} for pkg, ver in pinned_packages]
    osv_results = _query_osv_batch(osv_queries)

    if osv_results is not None:
        # Live database reachable — use its real, up-to-date results.
        for (pkg, version), result in zip(pinned_packages, osv_results):
            for vuln in result.get("vulns", []) or []:
                cve_id = vuln.get("id", "N/A")
                aliases = vuln.get("aliases", [])
                cve_display = next((a for a in aliases if a.startswith("CVE-")), cve_id)
                summary = vuln.get("summary") or vuln.get("details", "")[:200] or "Known vulnerability in this package version."
                cvss = _osv_severity_to_cvss(vuln)
                findings.append({
                    "title": f"Vulnerable Dependency: {pkg}=={version} ({cve_display})",
                    "severity": _severity_from_cvss(cvss),
                    "cvss_score": cvss,
                    "cve_id": cve_display,
                    "owasp_category": "A06:2021-Vulnerable and Outdated Components",
                    "mitre_attack": "T1190 - Exploit Public-Facing Application",
                    "description": f"'{pkg}' version {version} pinned in {rel_path} matches a known vulnerability in the OSV database: {summary}",
                    "evidence": f"{rel_path}: {pkg}=={version} | Source: OSV.dev live database ({vuln.get('id')})",
                    "remediation": f"Upgrade '{pkg}' to a patched release in requirements.txt and re-deploy. See https://osv.dev/vulnerability/{vuln.get('id')} for fix details."
                })
        return findings

    # Live database unreachable (offline/sandboxed environment, network policy, etc.) —
    # fall back to the built-in known-vulnerable-package table so a result is still returned.
    for pkg, version in pinned_packages:
        info = KNOWN_VULNERABLE_PACKAGES.get(pkg)
        if info and info.get("vulnerable_versions") and version in info["vulnerable_versions"]:
            findings.append({
                "title": f"Vulnerable Dependency: {pkg}=={version} ({info['title']})",
                "severity": _severity_from_cvss(info["cvss"]),
                "cvss_score": info["cvss"],
                "cve_id": info["cve"],
                "owasp_category": "A06:2021-Vulnerable and Outdated Components",
                "mitre_attack": "T1190 - Exploit Public-Facing Application",
                "description": f"'{pkg}' version {version} pinned in {rel_path} is a known-vulnerable release affected by {info['cve']} ({info['title']}). (Offline fallback table — live OSV database was unreachable.)",
                "evidence": f"{rel_path}: {pkg}=={version}",
                "remediation": f"Upgrade '{pkg}' to the latest patched release in requirements.txt and re-deploy."
            })
    return findings


def _scan_package_json(fpath: str, extract_dir: str) -> List[Dict[str, Any]]:
    findings = []
    rel_path = os.path.relpath(fpath, extract_dir)
    try:
        with open(fpath, "r", encoding="utf-8", errors="ignore") as f:
            data = json.load(f)
    except Exception:
        return findings

    deps = {}
    deps.update(data.get("dependencies", {}) or {})
    deps.update(data.get("devDependencies", {}) or {})

    cleaned_deps = []  # (pkg, cleaned_version, raw_spec)
    for pkg, version_spec in deps.items():
        cleaned_version = re.sub(r"[^0-9\.]", "", str(version_spec))
        if cleaned_version:
            cleaned_deps.append((pkg.lower(), cleaned_version, version_spec))

    if not cleaned_deps:
        return findings

    osv_queries = [{"version": ver, "package": {"name": pkg, "ecosystem": "npm"}} for pkg, ver, _ in cleaned_deps]
    osv_results = _query_osv_batch(osv_queries)

    if osv_results is not None:
        for (pkg, cleaned_version, raw_spec), result in zip(cleaned_deps, osv_results):
            for vuln in result.get("vulns", []) or []:
                cve_id = vuln.get("id", "N/A")
                aliases = vuln.get("aliases", [])
                cve_display = next((a for a in aliases if a.startswith("CVE-")), cve_id)
                summary = vuln.get("summary") or vuln.get("details", "")[:200] or "Known vulnerability in this package version."
                cvss = _osv_severity_to_cvss(vuln)
                findings.append({
                    "title": f"Vulnerable Dependency: {pkg}@{cleaned_version} ({cve_display})",
                    "severity": _severity_from_cvss(cvss),
                    "cvss_score": cvss,
                    "cve_id": cve_display,
                    "owasp_category": "A06:2021-Vulnerable and Outdated Components",
                    "mitre_attack": "T1190 - Exploit Public-Facing Application",
                    "description": f"'{pkg}' version {cleaned_version} declared in {rel_path} matches a known vulnerability in the OSV database: {summary}",
                    "evidence": f"{rel_path}: \"{pkg}\": \"{raw_spec}\" | Source: OSV.dev live database ({vuln.get('id')})",
                    "remediation": f"Upgrade '{pkg}' to a patched release in package.json and run npm install / npm audit fix. See https://osv.dev/vulnerability/{vuln.get('id')} for fix details."
                })
        return findings

    for pkg, cleaned_version, raw_spec in cleaned_deps:
        info = KNOWN_VULNERABLE_PACKAGES.get(pkg)
        if not info or not info.get("vulnerable_versions"):
            continue
        if cleaned_version in info["vulnerable_versions"]:
            findings.append({
                "title": f"Vulnerable Dependency: {pkg}@{cleaned_version} ({info['title']})",
                "severity": _severity_from_cvss(info["cvss"]),
                "cvss_score": info["cvss"],
                "cve_id": info["cve"],
                "owasp_category": "A06:2021-Vulnerable and Outdated Components",
                "mitre_attack": "T1190 - Exploit Public-Facing Application",
                "description": f"'{pkg}' version {cleaned_version} declared in {rel_path} is a known-vulnerable release affected by {info['cve']} ({info['title']}). (Offline fallback table — live OSV database was unreachable.)",
                "evidence": f"{rel_path}: \"{pkg}\": \"{raw_spec}\"",
                "remediation": f"Upgrade '{pkg}' to the latest patched release in package.json and run npm install / npm audit fix."
            })
    return findings


# --- 5. NMAP Network Scanner Wrapper (used when the binary is available for deeper scans) ---
def run_nmap_scan(target: str) -> List[Dict[str, Any]]:
    """Run Nmap service detection and create findings only from parsed evidence.

    A successful scan itself is telemetry, not a vulnerability.
    """
    nmap_path = shutil.which("nmap")
    if not nmap_path:
        return []
    findings = []
    try:
        cmd = [nmap_path, "-sV", "-F", "--no-stylesheet", "-oX", "-", target]
        result = subprocess.run(cmd, capture_output=True, text=True, timeout=60)
        if result.returncode != 0 or not result.stdout:
            return []
        root = ET.fromstring(result.stdout)
        for port in root.findall(".//port"):
            state = port.find("state")
            if state is None or state.attrib.get("state") != "open":
                continue
            try: port_id = int(port.attrib.get("portid", "0"))
            except ValueError: continue
            svc = port.find("service")
            name = svc.attrib.get("name", "unknown") if svc is not None else "unknown"
            product = svc.attrib.get("product", "") if svc is not None else ""
            version = svc.attrib.get("version", "") if svc is not None else ""
            if port_id in RISKY_EXPOSED_PORTS or port_id in RISKY_EXTENDED_PORTS:
                title = f"Potentially risky exposed service: {name} on TCP/{port_id}"
                findings.append({
                    "title": title, "severity": SeverityEnum.MEDIUM, "cvss_score": 5.3, "cve_id": "N/A",
                    "owasp_category": "A05:2021-Security Misconfiguration",
                    "mitre_attack": "T1046 - Network Service Discovery",
                    "description": f"Nmap confirmed an exposed {name} service on TCP/{port_id}. Exposure alone is not proof of a CVE; review whether this service must be internet/network reachable.",
                    "evidence": f"port={port_id}, service={name}, product={product or 'unknown'}, version={version or 'unknown'}, state=open",
                    "remediation": "Restrict unnecessary exposure with firewall/ACL rules, disable unused services, and patch the identified service."
                })
    except (ET.ParseError, OSError, subprocess.SubprocessError):
        return []
    except Exception:
        return []
    return findings


# --- 6. TRIVY Container & Dependency Scanner Wrapper (used when installed for deeper CVE coverage) ---
def run_trivy_scan(target_path: str) -> List[Dict[str, Any]]:
    trivy_path = shutil.which("trivy")
    vulnerabilities = []

    if not trivy_path:
        return vulnerabilities  # static scanner above already covers dependency/secret checks

    try:
        cmd = [trivy_path, "fs", "--format", "json", "--severity", "CRITICAL,HIGH,MEDIUM", target_path]
        result = subprocess.run(cmd, capture_output=True, text=True, timeout=120)

        if result.returncode == 0 and result.stdout:
            data = json.loads(result.stdout)
            results = data.get("Results", [])

            for res in results:
                for vuln in res.get("Vulnerabilities", []):
                    cve_id = vuln.get("VulnerabilityID", "N/A")
                    title = vuln.get("Title") or f"Vulnerability in {vuln.get('PkgName')}"
                    sev_str = vuln.get("Severity", "MEDIUM").capitalize()

                    severity = SeverityEnum.MEDIUM
                    if sev_str == "Critical": severity = SeverityEnum.CRITICAL
                    elif sev_str == "High": severity = SeverityEnum.HIGH
                    elif sev_str == "Low": severity = SeverityEnum.LOW

                    vulnerabilities.append({
                        "title": f"Trivy Finding: {title}",
                        "severity": severity,
                        "cvss_score": float(vuln.get("CVSS", {}).get("nvd", {}).get("V3Score")) if vuln.get("CVSS", {}).get("nvd", {}).get("V3Score") is not None else 0.0,
                        "cve_id": cve_id,
                        "owasp_category": "A06:2021-Vulnerable Components",
                        "mitre_attack": "T1190 - Exploit Public-Facing Application",
                        "description": vuln.get("Description", "Known vulnerable dependency package detected by Trivy."),
                        "evidence": f"Package: {vuln.get('PkgName')} (Installed: {vuln.get('InstalledVersion')}, Fixed: {vuln.get('FixedVersion', 'N/A')})",
                        "remediation": f"Upgrade {vuln.get('PkgName')} package to version {vuln.get('FixedVersion', 'latest')}."
                    })
    except Exception as e:
        vulnerabilities.append({
            "title": "Trivy Scan Execution Error",
            "severity": SeverityEnum.INFO,
            "cvss_score": 0.0,
            "cve_id": "N/A",
            "owasp_category": "N/A",
            "mitre_attack": "N/A",
            "description": f"Error running Trivy audit: {str(e)}",
            "evidence": str(e),
            "remediation": "Verify filesystem permissions and target archive format."
        })

    return vulnerabilities


# --- 7. OWASP ZAP API Web Security Scanner Wrapper (used when a ZAP daemon is available) ---
def run_owasp_zap_scan(target_url: str, zap_api_url: str = "http://localhost:8080", api_key: str = "") -> List[Dict[str, Any]]:
    """Run a real ZAP spider/passive scan and import alerts when ZAP is available.

    Active scan is intentionally not forced because it can be intrusive; callers can
    enable it separately after explicit authorization.
    """
    findings = []
    try:
        base = zap_api_url.rstrip("/")
        params = {"apikey": api_key} if api_key else {}
        version = requests.get(f"{base}/JSON/core/view/version/", params=params, timeout=5)
        version.raise_for_status()
        # Spider the authorized target.
        spider = requests.get(f"{base}/JSON/spider/action/scan/", params={**params, "url": target_url, "recurse": "true"}, timeout=10)
        spider.raise_for_status()
        scan_id = spider.json().get("scan")
        if scan_id is not None:
            for _ in range(30):
                time.sleep(1)
                st = requests.get(f"{base}/JSON/spider/view/status/", params={**params, "scanId": scan_id}, timeout=5)
                if st.ok and str(st.json().get("status")) == "100":
                    break
        alerts = requests.get(f"{base}/JSON/core/view/alerts/", params={**params, "baseurl": target_url, "start": 0, "count": 5000}, timeout=10)
        alerts.raise_for_status()
        for a in alerts.json().get("alerts", []):
            risk = str(a.get("risk", "Informational")).lower()
            severity = SeverityEnum.INFO
            cvss = 0.0
            if risk == "high": severity, cvss = SeverityEnum.HIGH, 8.0
            elif risk == "medium": severity, cvss = SeverityEnum.MEDIUM, 5.5
            elif risk == "low": severity, cvss = SeverityEnum.LOW, 2.6
            if severity == SeverityEnum.INFO:
                continue
            findings.append({
                "title": f"ZAP: {a.get('alert') or a.get('name') or 'Web security alert'}",
                "severity": severity, "cvss_score": cvss, "cve_id": a.get("cve") or "N/A",
                "owasp_category": a.get("wascid") or "N/A", "mitre_attack": "T1190 - Exploit Public-Facing Application",
                "description": a.get("description") or "OWASP ZAP reported a web security issue.",
                "evidence": f"URI: {a.get('uri')}; parameter: {a.get('param')}; solution: {a.get('solution', '')}",
                "remediation": a.get("solution") or "Review and remediate the ZAP alert according to its evidence and risk."
            })
    except Exception:
        # Optional tool: absence/failure must not be represented as a successful scan.
        return []
    return findings


def run_openvas_scan(target: str, gmp_host: str = "127.0.0.1", gmp_port: int = 9390) -> List[Dict[str, Any]]:
    """Greenbone connector placeholder that never fabricates a vulnerability.

    A full GMP workflow requires credentials, TLS and target/task lifecycle management.
    Until configured, no finding is emitted merely because port 9390 is reachable.
    """
    return []

