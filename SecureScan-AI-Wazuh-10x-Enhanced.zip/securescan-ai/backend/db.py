"""
Lightweight SQLite-backed persistence layer.

Replaces the earlier flat-JSON-file storage with a real, ACID-compliant,
concurrency-safe database (SQLite in WAL mode). A single generic key-value
table is used across all entity types (scans, assets, cves, users) — this
keeps the schema simple while still giving real benefits over flat files:
atomic writes, safe concurrent access from FastAPI's background tasks and
request handlers, indexed sorting, and real SQL-backed pagination.
"""
import sqlite3
import threading
import os
import json
from typing import Any, Dict, List, Optional

DATA_DIR = os.path.join(os.path.dirname(__file__), "data")
os.makedirs(DATA_DIR, exist_ok=True)
DB_PATH = os.path.join(DATA_DIR, "securescan.db")

_lock = threading.Lock()
_conn = sqlite3.connect(DB_PATH, check_same_thread=False)
_conn.execute("PRAGMA journal_mode=WAL")
_conn.execute("PRAGMA synchronous=NORMAL")
_conn.execute("PRAGMA foreign_keys=ON")


def init_db():
    with _lock:
        _conn.execute("""
            CREATE TABLE IF NOT EXISTS kv_store (
                namespace TEXT NOT NULL,
                key TEXT NOT NULL,
                sort_key TEXT,
                data TEXT NOT NULL,
                updated_at TEXT NOT NULL DEFAULT (datetime('now')),
                PRIMARY KEY (namespace, key)
            )
        """)
        _conn.execute("CREATE INDEX IF NOT EXISTS idx_kv_namespace_sort ON kv_store(namespace, sort_key)")
        _conn.execute("""
            CREATE TABLE IF NOT EXISTS wazuh_outbox (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                event_hash TEXT NOT NULL UNIQUE,
                payload TEXT NOT NULL,
                status TEXT NOT NULL DEFAULT 'pending',
                attempts INTEGER NOT NULL DEFAULT 0,
                next_attempt_at TEXT NOT NULL DEFAULT (datetime('now')),
                last_error TEXT,
                created_at TEXT NOT NULL DEFAULT (datetime('now')),
                delivered_at TEXT
            )
        """)
        _conn.execute("CREATE INDEX IF NOT EXISTS idx_wazuh_outbox_status_next ON wazuh_outbox(status, next_attempt_at)")
        _conn.execute("""
            CREATE TABLE IF NOT EXISTS wazuh_vulnerabilities (
                fingerprint TEXT PRIMARY KEY,
                agent_id TEXT, agent_name TEXT, hostname TEXT, os_name TEXT,
                package_name TEXT, package_version TEXT, fixed_version TEXT,
                cve_id TEXT, severity TEXT, cvss_score REAL, status TEXT,
                reference TEXT, description TEXT, raw_json TEXT NOT NULL,
                first_seen TEXT NOT NULL, last_seen TEXT NOT NULL
            )
        """)
        _conn.execute("CREATE INDEX IF NOT EXISTS idx_wazuh_vuln_cve ON wazuh_vulnerabilities(cve_id)")
        _conn.execute("CREATE INDEX IF NOT EXISTS idx_wazuh_vuln_agent ON wazuh_vulnerabilities(agent_id)")
        _conn.execute("CREATE INDEX IF NOT EXISTS idx_wazuh_vuln_severity ON wazuh_vulnerabilities(severity)")
        _conn.execute("""
            CREATE TABLE IF NOT EXISTS vulnerability_correlations (
                fingerprint TEXT PRIMARY KEY,
                cve_id TEXT, asset_key TEXT, secure_scan_ids TEXT,
                wazuh_agent_ids TEXT, confidence TEXT, updated_at TEXT NOT NULL
            )
        """)
        _conn.commit()


def kv_set(namespace: str, key: str, value: Dict[str, Any], sort_key: Optional[str] = None):
    with _lock:
        _conn.execute(
            """
            INSERT INTO kv_store (namespace, key, sort_key, data, updated_at)
            VALUES (?, ?, ?, ?, datetime('now'))
            ON CONFLICT(namespace, key) DO UPDATE SET
                sort_key = excluded.sort_key,
                data = excluded.data,
                updated_at = excluded.updated_at
            """,
            (namespace, key, sort_key or key, json.dumps(value, default=str)),
        )
        _conn.commit()


def kv_get(namespace: str, key: str) -> Optional[Dict[str, Any]]:
    with _lock:
        row = _conn.execute(
            "SELECT data FROM kv_store WHERE namespace=? AND key=?", (namespace, key)
        ).fetchone()
    return json.loads(row[0]) if row else None


def kv_delete(namespace: str, key: str) -> bool:
    with _lock:
        cur = _conn.execute("DELETE FROM kv_store WHERE namespace=? AND key=?", (namespace, key))
        _conn.commit()
    return cur.rowcount > 0


def kv_list(namespace: str, order_desc: bool = True, limit: Optional[int] = None, offset: int = 0) -> List[Dict[str, Any]]:
    direction = "DESC" if order_desc else "ASC"
    query = f"SELECT data FROM kv_store WHERE namespace=? ORDER BY sort_key {direction}"
    params: List[Any] = [namespace]
    if limit is not None:
        query += " LIMIT ? OFFSET ?"
        params += [limit, offset]
    with _lock:
        rows = _conn.execute(query, params).fetchall()
    return [json.loads(r[0]) for r in rows]


def kv_get_all_dict(namespace: str) -> Dict[str, Dict[str, Any]]:
    """Returns the full namespace as a {key: value} dict — used where callers
    need to look records up by their own key (e.g. users by username)."""
    with _lock:
        rows = _conn.execute("SELECT key, data FROM kv_store WHERE namespace=?", (namespace,)).fetchall()
    return {k: json.loads(v) for k, v in rows}


def kv_count(namespace: str) -> int:
    with _lock:
        row = _conn.execute("SELECT COUNT(*) FROM kv_store WHERE namespace=?", (namespace,)).fetchone()
    return row[0] if row else 0


def kv_clear_missing(namespace: str, keep_keys: set):
    """Deletes any record in the namespace whose key is not in keep_keys —
    used to emulate a 'replace whole collection' write while keeping
    per-record storage under the hood."""
    with _lock:
        existing = {r[0] for r in _conn.execute("SELECT key FROM kv_store WHERE namespace=?", (namespace,)).fetchall()}
        to_delete = existing - keep_keys
        if to_delete:
            _conn.executemany(
                "DELETE FROM kv_store WHERE namespace=? AND key=?",
                [(namespace, k) for k in to_delete]
            )
            _conn.commit()



# ---------------------------------------------------------------------------
# Wazuh durable outbox / vulnerability state
def outbox_put(event_hash: str, payload: Dict[str, Any]) -> bool:
    with _lock:
        try:
            _conn.execute("INSERT INTO wazuh_outbox(event_hash,payload) VALUES(?,?)", (event_hash, json.dumps(payload, default=str)))
            _conn.commit()
            return True
        except sqlite3.IntegrityError:
            return False

def outbox_pending(limit: int = 100) -> List[Dict[str, Any]]:
    with _lock:
        rows=_conn.execute("SELECT id,event_hash,payload,attempts FROM wazuh_outbox WHERE status='pending' AND datetime(next_attempt_at) <= datetime('now') ORDER BY id LIMIT ?", (limit,)).fetchall()
    return [{"id":r[0],"event_hash":r[1],"payload":json.loads(r[2]),"attempts":r[3]} for r in rows]

def outbox_mark_delivered(ids: List[int]):
    if not ids: return
    with _lock:
        _conn.executemany("UPDATE wazuh_outbox SET status='delivered', delivered_at=datetime('now') WHERE id=?", [(i,) for i in ids])
        _conn.commit()

def outbox_mark_retry(row_id: int, attempts: int, error: str, max_retries: int):
    status='dead_letter' if attempts >= max_retries else 'pending'
    delay=min(900, 2 ** min(attempts, 9))
    with _lock:
        _conn.execute("UPDATE wazuh_outbox SET status=?, attempts=?, last_error=?, next_attempt_at=datetime('now', ? || ' seconds') WHERE id=?", (status, attempts, error[:500], str(delay), row_id))
        _conn.commit()

def outbox_stats() -> Dict[str, int]:
    with _lock:
        rows=_conn.execute("SELECT status,COUNT(*) FROM wazuh_outbox GROUP BY status").fetchall()
    d={"pending":0,"delivered":0,"dead_letter":0}
    d.update({r[0]:r[1] for r in rows})
    return d

def save_wazuh_vulnerabilities(items: List[Dict[str, Any]]) -> int:
    if not items: return 0
    with _lock:
        for x in items:
            _conn.execute("""INSERT INTO wazuh_vulnerabilities
              (fingerprint,agent_id,agent_name,hostname,os_name,package_name,package_version,fixed_version,cve_id,severity,cvss_score,status,reference,description,raw_json,first_seen,last_seen)
              VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)
              ON CONFLICT(fingerprint) DO UPDATE SET
                agent_id=excluded.agent_id,agent_name=excluded.agent_name,hostname=excluded.hostname,os_name=excluded.os_name,
                package_name=excluded.package_name,package_version=excluded.package_version,fixed_version=excluded.fixed_version,
                cve_id=excluded.cve_id,severity=excluded.severity,cvss_score=excluded.cvss_score,status=excluded.status,
                reference=excluded.reference,description=excluded.description,raw_json=excluded.raw_json,last_seen=excluded.last_seen""",
              (x.get("fingerprint"),x.get("agent_id"),x.get("agent_name"),x.get("hostname"),x.get("os_name"),x.get("package_name"),x.get("package_version"),x.get("fixed_version"),x.get("cve_id"),x.get("severity"),x.get("cvss_score"),x.get("status"),x.get("reference"),x.get("description"),json.dumps(x.get("raw",{}),default=str),x.get("first_seen"),x.get("last_seen")))
        _conn.commit()
    return len(items)

def list_wazuh_vulnerabilities(limit: int=100, offset: int=0, severity: Optional[str]=None, cve: Optional[str]=None, agent_id: Optional[str]=None) -> List[Dict[str,Any]]:
    q="SELECT fingerprint,agent_id,agent_name,hostname,os_name,package_name,package_version,fixed_version,cve_id,severity,cvss_score,status,reference,description,first_seen,last_seen FROM wazuh_vulnerabilities WHERE 1=1"
    params=[]
    if severity: q+=" AND lower(severity)=lower(?)"; params.append(severity)
    if cve: q+=" AND cve_id LIKE ?"; params.append(f"%{cve}%")
    if agent_id: q+=" AND agent_id=?"; params.append(agent_id)
    q+=" ORDER BY CASE lower(severity) WHEN 'critical' THEN 1 WHEN 'high' THEN 2 WHEN 'medium' THEN 3 WHEN 'low' THEN 4 ELSE 5 END, last_seen DESC LIMIT ? OFFSET ?"
    params += [max(1,min(limit,500)),max(0,offset)]
    with _lock: rows=_conn.execute(q,params).fetchall()
    keys=["fingerprint","agent_id","agent_name","hostname","os_name","package_name","package_version","fixed_version","cve_id","severity","cvss_score","status","reference","description","first_seen","last_seen"]
    return [dict(zip(keys,r)) for r in rows]

def count_wazuh_vulnerabilities(severity: Optional[str]=None) -> int:
    with _lock:
        if severity: return _conn.execute("SELECT COUNT(*) FROM wazuh_vulnerabilities WHERE lower(severity)=lower(?)",(severity,)).fetchone()[0]
        return _conn.execute("SELECT COUNT(*) FROM wazuh_vulnerabilities").fetchone()[0]


init_db()
