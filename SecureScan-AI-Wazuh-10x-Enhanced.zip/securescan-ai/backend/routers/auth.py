import jwt
import os
import hashlib
import time
import bcrypt
from datetime import datetime, timedelta
from fastapi import APIRouter, HTTPException, Depends, status, Request
from fastapi.security import OAuth2PasswordBearer
from backend.config import settings
from backend.models import UserLogin, UserCreate, UserResponse, TokenResponse, RoleEnum
from backend.storage import get_persisted_users, save_persisted_users

router = APIRouter(prefix="/auth", tags=["Authentication"])

oauth2_scheme = OAuth2PasswordBearer(tokenUrl="/api/v1/auth/login", auto_error=False)

# Passwords are hashed with bcrypt (salted, slow-by-design, industry standard).
# Using the `bcrypt` library directly rather than through passlib, since
# passlib's bcrypt compatibility shim is unmaintained and breaks on modern
# bcrypt (>=4.0) releases.
BCRYPT_MAX_BYTES = 72  # bcrypt silently ignores bytes beyond this


def hash_password(password: str) -> str:
    pw_bytes = password.encode("utf-8")[:BCRYPT_MAX_BYTES]
    return bcrypt.hashpw(pw_bytes, bcrypt.gensalt()).decode("utf-8")


def _looks_like_legacy_sha256(stored_hash: str) -> bool:
    """Earlier builds of this platform stored unsalted SHA-256 password hashes
    (64 lowercase hex characters). This detects that legacy format so existing
    accounts can be transparently upgraded to bcrypt on their next login."""
    return isinstance(stored_hash, str) and len(stored_hash) == 64 and all(c in "0123456789abcdef" for c in stored_hash)


def verify_password(plain_password: str, stored_hash: str) -> bool:
    if _looks_like_legacy_sha256(stored_hash):
        return hashlib.sha256(plain_password.encode()).hexdigest() == stored_hash
    try:
        pw_bytes = plain_password.encode("utf-8")[:BCRYPT_MAX_BYTES]
        return bcrypt.checkpw(pw_bytes, stored_hash.encode("utf-8"))
    except Exception:
        return False


# ----------------------------------------------------------------------------
# Login brute-force protection: tracks failed attempts per username in memory
# and temporarily locks an account out after too many failures in a row.
# ----------------------------------------------------------------------------
_FAILED_LOGIN_TRACKER: dict = {}  # username -> {"count": int, "locked_until": float}


def _check_lockout(username: str):
    entry = _FAILED_LOGIN_TRACKER.get(username)
    if entry and entry.get("locked_until", 0) > time.time():
        remaining = int(entry["locked_until"] - time.time())
        raise HTTPException(
            status_code=status.HTTP_429_TOO_MANY_REQUESTS,
            detail=f"Too many failed login attempts. Try again in {remaining} seconds."
        )


def _register_failed_login(username: str):
    entry = _FAILED_LOGIN_TRACKER.setdefault(username, {"count": 0, "locked_until": 0})
    entry["count"] += 1
    if entry["count"] >= settings.LOGIN_MAX_ATTEMPTS:
        entry["locked_until"] = time.time() + settings.LOGIN_LOCKOUT_SECONDS
        entry["count"] = 0


def _clear_failed_logins(username: str):
    _FAILED_LOGIN_TRACKER.pop(username, None)


# Default seeded accounts: one Admin account and one standard User account.
DEFAULT_USERS_DB = {
    "admin": {
        "id": "usr-001",
        "username": "admin",
        "email": "admin@securescan.ai",
        "password_hash": hash_password("admin123"),
        "role": RoleEnum.ADMIN,
        "full_name": "Chief Information Security Officer",
        "created_at": "2026-01-01T00:00:00Z"
    },
    "user": {
        "id": "usr-002",
        "username": "user",
        "email": "user@securescan.ai",
        "password_hash": hash_password("user123"),
        "role": RoleEnum.ANALYST,
        "full_name": "Security Analyst",
        "created_at": "2026-01-15T00:00:00Z"
    }
}

# Persisted (survives restarts). Falls back to DEFAULT_USERS_DB on first run.
USERS_DB = get_persisted_users(DEFAULT_USERS_DB)
# Make sure both default accounts always exist even if the persisted file predates them.
for _uname, _udata in DEFAULT_USERS_DB.items():
    USERS_DB.setdefault(_uname, _udata)
save_persisted_users(USERS_DB)


def create_access_token(data: dict, expires_delta: timedelta = None):
    to_encode = data.copy()
    expire = datetime.utcnow() + (expires_delta or timedelta(minutes=settings.ACCESS_TOKEN_EXPIRE_MINUTES))
    to_encode.update({"exp": expire})
    encoded_jwt = jwt.encode(to_encode, settings.SECRET_KEY, algorithm=settings.ALGORITHM)
    return encoded_jwt


def get_current_user(token: str = Depends(oauth2_scheme)) -> dict:
    """Validates the bearer JWT and returns the authenticated user record.
    Every protected route in the platform depends on this."""
    if not token:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Not authenticated. Please log in to continue.",
            headers={"WWW-Authenticate": "Bearer"},
        )
    try:
        payload = jwt.decode(token, settings.SECRET_KEY, algorithms=[settings.ALGORITHM])
        username: str = payload.get("sub")
        if username is None or username not in USERS_DB:
            raise HTTPException(status_code=401, detail="Invalid token credentials")
        return USERS_DB[username]
    except jwt.ExpiredSignatureError:
        raise HTTPException(status_code=401, detail="Session expired. Please log in again.")
    except Exception:
        raise HTTPException(status_code=401, detail="Could not validate authentication token")


def require_admin(current_user: dict = Depends(get_current_user)) -> dict:
    """Restricts an endpoint to Admin-role accounts only."""
    if current_user.get("role") != RoleEnum.ADMIN:
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="This action requires Administrator privileges."
        )
    return current_user


@router.post("/login", response_model=TokenResponse)
def login(form_data: UserLogin):
    uname = form_data.username.strip().lower()
    _check_lockout(uname)

    user = USERS_DB.get(uname)
    if not user or not verify_password(form_data.password, user["password_hash"]):
        _register_failed_login(uname)
        raise HTTPException(status_code=400, detail="Incorrect username or password")

    _clear_failed_logins(uname)

    # Transparently upgrade legacy SHA-256 hashes to bcrypt now that we know the plaintext.
    if _looks_like_legacy_sha256(user["password_hash"]):
        user["password_hash"] = hash_password(form_data.password)
        save_persisted_users(USERS_DB)

    access_token = create_access_token(data={"sub": user["username"], "role": user["role"]})
    user_res = UserResponse(
        id=user["id"],
        username=user["username"],
        email=user["email"],
        role=user["role"],
        full_name=user["full_name"],
        created_at=user["created_at"]
    )
    return TokenResponse(access_token=access_token, user=user_res)


@router.post("/register", response_model=UserResponse)
def register(user_in: UserCreate, current_user: dict = Depends(require_admin)):
    """Only Admins can create new accounts, keeping the user roster controlled."""
    uname = user_in.username.strip().lower()
    if uname in USERS_DB:
        raise HTTPException(status_code=400, detail="Username already registered")

    new_user = {
        "id": f"usr-{uuid_suffix()}",
        "username": uname,
        "email": user_in.email,
        "password_hash": hash_password(user_in.password),
        "role": user_in.role,
        "full_name": user_in.full_name,
        "created_at": datetime.utcnow().isoformat() + "Z"
    }
    USERS_DB[uname] = new_user
    save_persisted_users(USERS_DB)
    return UserResponse(**new_user)


def uuid_suffix():
    import uuid
    return uuid.uuid4().hex[:6]


@router.get("/me", response_model=UserResponse)
def get_me(current_user: dict = Depends(get_current_user)):
    return UserResponse(**current_user)
