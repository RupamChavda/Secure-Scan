import time
import uuid
import os
import json
from datetime import datetime
from typing import List, Optional
from fastapi import APIRouter, HTTPException, Depends, BackgroundTasks, UploadFile, File
from backend.config import settings
from backend.models import (
    ScanCreate, ScanResultResponse, TargetTypeEnum, ScanTypeEnum,
    VulnerabilityItem, SeverityEnum, AIRiskSummary
)
from backend.routers.auth import get_current_user, require_admin
from backend.scanners import (
    run_nmap_scan, run_trivy_scan, run_owasp_zap_scan, run_openvas_scan,
    run_live_port_scan, run_http_security_scan, run_ssl_scan, run_static_code_scan
)
from backend.storage import get_persisted_scans, save_persisted_scans, save_scan_record, delete_scan_record, get_scan_record, list_scans_paginated, count_scans
from backend.target_safety import assess_scan_target, UnsafeScanTargetError
from backend.ai_client import call_claude, is_ai_configured, AIUnavailableError
from backend.alerts import send_scan_alert
from backend.wazuh import emit_scan_findings

router = APIRouter(prefix="/scans", tags=["Scan Engine"])

# Initialize SCANS_DB from persistent disk storage so scan HISTORY survives restarts.
SCANS_DB = get_persisted_scans()


def _severity_weight(sev) -> float:
    sev = str(sev)
    return {"Critical": 4.0, "High": 3.0, "Medium": 2.0, "Low": 1.0, "Info": 0.0}.get(sev, 1.0)


def _sev_str(sev) -> str:
    """
    Normalizes a severity value to its plain string form ('Critical', 'High',
    etc.) regardless of whether it's a SeverityEnum member (fresh from a
    scanner function) or a plain string (after a round-trip through JSON
    storage). str() on a str-Enum member returns 'SeverityEnum.CRITICAL', not
    'Critical' — using .value where available avoids that trap.
    """
    return sev.value if hasattr(sev, "value") else str(sev)


def generate_ai_analysis(target: str, vulns: List[dict]) -> AIRiskSummary:
    """
    Produces the risk summary for a completed scan. The overall_risk_score is
    ALWAYS calculated deterministically from the actual findings (consistent,
    auditable, reproducible). When a real LLM is configured, the narrative
    text (business impact, technical impact, executive summary) is generated
    by Claude reasoning over the real findings for genuinely intelligent,
    non-templated explanations; otherwise a clear rule-based fallback is used
    so the platform always returns a complete, correct analysis.
    """
    def sev_of(v):
        return v.get("severity") if isinstance(v, dict) else getattr(v, "severity")

    crit_count = sum(1 for v in vulns if _sev_str(sev_of(v)) == "Critical")
    high_count = sum(1 for v in vulns if _sev_str(sev_of(v)) == "High")
    med_count = sum(1 for v in vulns if _sev_str(sev_of(v)) == "Medium")
    low_count = sum(1 for v in vulns if _sev_str(sev_of(v)) == "Low")

    # Weighted score capped at 10 — heavier weight on critical/high findings for accuracy.
    # This calculation is deterministic by design: risk scoring should be
    # consistent and reproducible, not subject to LLM variance.
    raw_score = crit_count * 3.2 + high_count * 1.8 + med_count * 0.6 + low_count * 0.15
    score = round(min(10.0, raw_score), 1)

    rule_based = _rule_based_narrative(target, vulns, crit_count, high_count, med_count, low_count, score)

    if not is_ai_configured():
        return rule_based

    try:
        ai_narrative = _ai_generated_narrative(target, vulns, score)
        # Keep the deterministic score/patch-priority scaffolding but use the AI's
        # richer narrative text where it successfully returned one.
        rule_based.business_impact = ai_narrative.get("business_impact", rule_based.business_impact)
        rule_based.technical_impact = ai_narrative.get("technical_impact", rule_based.technical_impact)
        rule_based.executive_summary = ai_narrative.get("executive_summary", rule_based.executive_summary)
        rule_based.likelihood = ai_narrative.get("likelihood", rule_based.likelihood)
        if ai_narrative.get("recommendations"):
            rule_based.recommendations = ai_narrative["recommendations"]
        rule_based.ai_powered = True
        return rule_based
    except (AIUnavailableError, json.JSONDecodeError, Exception):
        return rule_based


def _ai_generated_narrative(target: str, vulns: List[dict], score: float) -> dict:
    findings_summary = []
    for v in vulns[:25]:  # cap to keep the prompt reasonably sized
        findings_summary.append({
            "title": v.get("title"),
            "severity": _sev_str(v.get("severity")),
            "cvss_score": v.get("cvss_score"),
            "cve_id": v.get("cve_id"),
            "description": v.get("description"),
        })

    system_prompt = (
        "You are a senior security analyst writing the risk-analysis section of an automated vulnerability "
        "scan report. Given the scan target and its real findings, respond ONLY with a compact JSON object "
        "(no markdown, no prose outside the JSON) with exactly these keys: "
        '{"executive_summary": "2-3 sentences, for a mixed executive/technical audience", '
        '"business_impact": "2-4 sentences in plain, non-technical language about what this means for the organization", '
        '"technical_impact": "2-3 sentences of technical detail about exploitability and attack vectors", '
        '"likelihood": "one short sentence rating exploitation likelihood and why", '
        '"recommendations": ["3-5 short, concrete, prioritized action items"]}'
    )
    user_prompt = (
        f"Scan target: {target}\n"
        f"Calculated overall risk score: {score}/10\n"
        f"Findings ({len(vulns)} total):\n{json.dumps(findings_summary, indent=2)}"
    )

    reply_text = call_claude(system_prompt, user_prompt, max_tokens=700)
    cleaned = reply_text.strip()
    if cleaned.startswith("```"):
        cleaned = cleaned.strip("`")
        if cleaned.lower().startswith("json"):
            cleaned = cleaned[4:]
    return json.loads(cleaned)


def _rule_based_narrative(target: str, vulns: List[dict], crit_count: int, high_count: int, med_count: int, low_count: int, score: float) -> AIRiskSummary:

    if crit_count > 0:
        business_impact = (
            f"This scan found {crit_count} CRITICAL issue(s) on '{target}'. In plain terms, these are the kind of "
            f"weaknesses that let an outside attacker break in, steal data, or take over the system with relatively "
            f"little effort. This should be treated as an emergency and fixed as soon as possible."
        )
        likelihood = "Very High — critical findings are typically easy for automated attack tools to discover and exploit."
    elif high_count > 0:
        business_impact = (
            f"This scan found {high_count} HIGH severity issue(s) on '{target}'. These significantly increase the "
            f"chance of a security incident (data exposure, service disruption, or unauthorized access) and should "
            f"be scheduled for prompt remediation."
        )
        likelihood = "High — these issues are commonly targeted once discovered, though they may need more effort to exploit than critical findings."
    elif med_count > 0:
        business_impact = (
            f"This scan found {med_count} MEDIUM severity issue(s) on '{target}'. On their own these are less "
            f"urgent, but they weaken the overall security posture and can be combined with other issues by a "
            f"determined attacker."
        )
        likelihood = "Moderate — exploitation typically requires specific conditions or additional weaknesses to be present."
    elif low_count > 0:
        business_impact = (
            f"This scan found only lower-risk, informational issues on '{target}'. There is no urgent threat, but "
            f"addressing these will further strengthen your security posture."
        )
        likelihood = "Low — these findings are unlikely to be exploited on their own."
    else:
        business_impact = f"No security issues were identified on '{target}' during this scan. Keep up regular scanning to catch new risks early."
        likelihood = "Minimal — no exploitable weaknesses were found in this scan."

    technical_impact = (
        f"Findings breakdown for this scan: {crit_count} Critical, {high_count} High, {med_count} Medium, {low_count} Low. "
        + ("Exploitable vectors include network exposure, injection flaws, missing security headers/encryption, or leaked credentials, depending on the specific findings below." if vulns else "No exploitable technical vectors were identified.")
    )

    recommendations = []
    if crit_count > 0:
        recommendations.append("Fix all Critical findings first — these pose the greatest and most immediate risk.")
    if high_count > 0:
        recommendations.append("Schedule High severity findings for remediation within the next few days.")
    recommendations.append("Re-run this scan after applying fixes to confirm the issues are resolved.")
    recommendations.append("Review the detailed findings below with your technical/IT team for step-by-step fixes.")

    patch_priority = []
    if crit_count > 0:
        patch_priority.append(f"P0: Remediate {crit_count} Critical finding(s) — Within 24 Hours")
    if high_count > 0:
        patch_priority.append(f"P1: Remediate {high_count} High finding(s) — Within 3-5 Days")
    if med_count > 0:
        patch_priority.append(f"P2: Remediate {med_count} Medium finding(s) — Within 30 Days")
    if not patch_priority:
        patch_priority.append("No urgent patches required based on current findings.")

    executive_summary = (
        f"Automated security audit for '{target}' identified {len(vulns)} total finding(s): "
        f"{crit_count} Critical, {high_count} High, {med_count} Medium, {low_count} Low. "
        + ("Immediate attention is required." if crit_count > 0 else
           "Prompt review is recommended." if high_count > 0 else
           "No urgent action is required, but continued monitoring is advised.")
    )

    return AIRiskSummary(
        overall_risk_score=score,
        business_impact=business_impact,
        technical_impact=technical_impact,
        likelihood=likelihood,
        recommendations=recommendations,
        patch_priority=patch_priority,
        executive_summary=executive_summary
    )


def execute_scan_job(scan_id: str):
    """
    Runs the actual dynamic scan pipeline for a queued scan job. Every scan
    is evaluated live against its specific target — nothing here is a fixed
    canned result; findings depend entirely on what is actually detected for
    THIS target at THIS point in time.
    """
    scan = SCANS_DB.get(scan_id)
    if not scan:
        return

    def log(msg: str):
        scan["logs"].append(f"[{datetime.utcnow().strftime('%H:%M:%S')}] {msg}")

    scan["status"] = "Running"
    log("Starting SecureScan AI dynamic scan engine...")
    log(f"Analyzing target fingerprint: {scan['target']}")
    scan["progress"] = 10
    save_scan_record(scan_id, scan)
    time.sleep(0.5)

    target_str = str(scan["target"])
    target_type = str(scan.get("target_type", "")).lower()

    discovered_vulns = []
    is_zip_target = "zip" in target_type or "uploaded" in target_str.lower() or target_str.lower().endswith((".zip", ".tar", ".tar.gz", ".gz"))
    is_network_target = "ip" in target_type or "server" in target_type or "cidr" in target_type
    is_web_target = "website" in target_type or "url" in target_type or "domain" in target_type or target_str.startswith("http")

    try:
        if is_zip_target:
            log("Running static source code analysis: secret detection & dependency CVE audit...")
            scan["progress"] = 30
            save_scan_record(scan_id, scan)
            archive_path = scan.get("_archive_path")
            if archive_path and os.path.exists(archive_path):
                discovered_vulns.extend(run_static_code_scan(archive_path))
            discovered_vulns.extend(run_trivy_scan(archive_path or target_str))

        elif is_network_target:
            log("Executing live network port scan against target host...")
            scan["progress"] = 30
            save_scan_record(scan_id, scan)
            discovered_vulns.extend(run_live_port_scan(target_str))
            discovered_vulns.extend(run_nmap_scan(target_str))

            log("Checking for HTTPS/TLS service exposure...")
            scan["progress"] = 55
            save_scan_record(scan_id, scan)
            discovered_vulns.extend(run_ssl_scan(target_str))

        else:
            # Web URL / domain / generic target
            log("Running live HTTP security header & configuration analysis...")
            scan["progress"] = 30
            save_scan_record(scan_id, scan)
            discovered_vulns.extend(run_http_security_scan(target_str, custom_headers=scan.get("custom_headers")))

            log("Performing live TLS/SSL certificate & protocol scan...")
            scan["progress"] = 50
            save_scan_record(scan_id, scan)
            discovered_vulns.extend(run_ssl_scan(target_str))

            log("Scanning for exposed network ports...")
            scan["progress"] = 65
            save_scan_record(scan_id, scan)
            discovered_vulns.extend(run_live_port_scan(target_str))

            discovered_vulns.extend(run_owasp_zap_scan(target_str))

        scan["progress"] = 80
        save_scan_record(scan_id, scan)

        # Optional deep-scan tool (only adds a finding if a live GVM daemon is reachable)
        discovered_vulns.extend(run_openvas_scan(target_str))

    except Exception as e:
        log(f"Scan module error: {str(e)}")

    # Assign IDs / affected asset to every finding
    for idx, v in enumerate(discovered_vulns):
        v["id"] = f"vuln-{scan_id[:6]}-{idx + 1}"
        v["affected_asset"] = scan["target"]
        v.setdefault("cve_id", "N/A")
        v.setdefault("owasp_category", "N/A")
        v.setdefault("mitre_attack", "N/A")

    scan["vulnerabilities"] = discovered_vulns
    scan["total_vulnerabilities"] = len(discovered_vulns)
    scan["critical_count"] = sum(1 for v in discovered_vulns if _sev_str(v["severity"]) == "Critical")
    scan["high_count"] = sum(1 for v in discovered_vulns if _sev_str(v["severity"]) == "High")
    scan["medium_count"] = sum(1 for v in discovered_vulns if _sev_str(v["severity"]) == "Medium")
    scan["low_count"] = sum(1 for v in discovered_vulns if _sev_str(v["severity"]) == "Low")

    log(f"Invoking AI Risk Analysis Engine for target '{scan['target']}'...")
    scan["ai_analysis"] = generate_ai_analysis(scan["target"], discovered_vulns).dict()

    scan["progress"] = 100
    scan["status"] = "Completed"
    scan["end_time"] = datetime.utcnow().isoformat() + "Z"
    start_dt = datetime.fromisoformat(scan["start_time"].replace("Z", ""))
    scan["duration_seconds"] = max(1, int((datetime.utcnow() - start_dt).total_seconds()))
    log("Scan completed. Executive report is ready to view.")

    scan.pop("_archive_path", None)
    # Persist final result to the scan HISTORY store on disk.
    save_scan_record(scan_id, scan)

    # Queue findings for Wazuh (non-blocking; delivery handled by background sender).
    try:
        queued = emit_scan_findings(scan)
        if queued:
            log(f"Queued {queued} finding(s) for delivery to Wazuh SIEM.")
    except Exception as e:
        log(f"Wazuh emission skipped: {e}")
    save_scan_record(scan_id, scan)

    # Fire a webhook alert if this scan was configured with one and found anything Critical/High.
    webhook_url = scan.get("webhook_url")
    if webhook_url and (scan["critical_count"] > 0 or scan["high_count"] > 0):
        try:
            send_scan_alert(webhook_url, scan)
            log(f"Alert webhook notified ({scan['critical_count']} Critical, {scan['high_count']} High findings).")
        except Exception as e:
            log(f"Alert webhook delivery failed: {e}")
        save_scan_record(scan_id, scan)


def _new_scan_record(scan_id: str, target: str, target_type, scan_types, requested_by: str, extra_logs=None, custom_headers=None, webhook_url=None) -> dict:
    start_time = datetime.utcnow().isoformat() + "Z"
    return {
        "id": scan_id,
        "target": target,
        "target_type": target_type,
        "scan_types": scan_types,
        "status": "Queued",
        "progress": 0,
        "start_time": start_time,
        "end_time": None,
        "duration_seconds": 0,
        "total_vulnerabilities": 0,
        "critical_count": 0,
        "high_count": 0,
        "medium_count": 0,
        "low_count": 0,
        "vulnerabilities": [],
        "ai_analysis": None,
        "requested_by": requested_by,
        "custom_headers": custom_headers,
        "webhook_url": webhook_url,
        "logs": [f"[{datetime.utcnow().strftime('%H:%M:%S')}] Scan request queued for target {target}."] + (extra_logs or [])
    }


@router.post("", response_model=ScanResultResponse)
def create_scan(scan_in: ScanCreate, background_tasks: BackgroundTasks, current_user: dict = Depends(get_current_user)):
    try:
        assess_scan_target(scan_in.target)
    except UnsafeScanTargetError as e:
        raise HTTPException(status_code=400, detail=str(e))

    scan_id = f"scan-{uuid.uuid4().hex[:8]}"
    scan_obj = _new_scan_record(
        scan_id, scan_in.target, scan_in.target_type, scan_in.scan_types, current_user["username"],
        custom_headers=scan_in.custom_headers, webhook_url=scan_in.webhook_url
    )

    SCANS_DB[scan_id] = scan_obj
    save_scan_record(scan_id, scan_obj)  # persist immediately so it shows up in scan history right away
    background_tasks.add_task(execute_scan_job, scan_id)
    return scan_obj


@router.post("/upload", response_model=ScanResultResponse)
async def upload_project_zip(
    background_tasks: BackgroundTasks,
    file: UploadFile = File(...),
    current_user: dict = Depends(get_current_user)
):
    if not any(file.filename.lower().endswith(ext) for ext in settings.ALLOWED_UPLOAD_EXTENSIONS):
        raise HTTPException(
            status_code=400,
            detail=f"Only compressed project archives ({', '.join(settings.ALLOWED_UPLOAD_EXTENSIONS)}) are supported."
        )

    # Enforce a max upload size while streaming to disk, instead of reading
    # the whole file into memory first (avoids a memory-exhaustion vector too).
    file_location = os.path.join(settings.UPLOAD_DIR, os.path.basename(file.filename))
    total_written = 0
    chunk_size = 1024 * 1024  # 1MB
    try:
        with open(file_location, "wb") as file_object:
            while True:
                chunk = await file.read(chunk_size)
                if not chunk:
                    break
                total_written += len(chunk)
                if total_written > settings.MAX_UPLOAD_SIZE_BYTES:
                    file_object.close()
                    os.remove(file_location)
                    raise HTTPException(
                        status_code=413,
                        detail=f"Uploaded file exceeds the {settings.MAX_UPLOAD_SIZE_BYTES // (1024*1024)}MB size limit."
                    )
                file_object.write(chunk)
    except HTTPException:
        raise
    except Exception:
        if os.path.exists(file_location):
            os.remove(file_location)
        raise HTTPException(status_code=500, detail="Failed to save the uploaded file.")

    scan_id = f"scan-{uuid.uuid4().hex[:8]}"
    scan_obj = _new_scan_record(
        scan_id,
        f"Uploaded Project: {file.filename}",
        TargetTypeEnum.ZIP,
        [ScanTypeEnum.SAST, ScanTypeEnum.DEPENDENCY, ScanTypeEnum.OWASP],
        current_user["username"],
        extra_logs=[f"[{datetime.utcnow().strftime('%H:%M:%S')}] Extraction and static analysis queued."]
    )
    scan_obj["_archive_path"] = file_location

    SCANS_DB[scan_id] = scan_obj
    save_scan_record(scan_id, scan_obj)
    background_tasks.add_task(execute_scan_job, scan_id)
    return scan_obj


@router.get("", response_model=List[ScanResultResponse])
def list_scans(
    current_user: dict = Depends(get_current_user),
    limit: Optional[int] = None,
    offset: int = 0,
):
    """
    Returns scan HISTORY, most recent first. Supports real pagination via
    `limit`/`offset` query parameters (backed directly by indexed SQL queries
    rather than loading the entire history into memory) — omit them to get
    the full history as before, for backward compatibility.
    """
    if limit is not None:
        return list_scans_paginated(limit=limit, offset=offset)
    return sorted(SCANS_DB.values(), key=lambda s: s.get("start_time", ""), reverse=True)


@router.get("/count")
def get_scan_count(current_user: dict = Depends(get_current_user)):
    """Total number of scans in history — used by the frontend to build pagination controls."""
    return {"total": count_scans()}


@router.get("/{scan_id}", response_model=ScanResultResponse)
def get_scan(scan_id: str, current_user: dict = Depends(get_current_user)):
    record = get_scan_record(scan_id) or SCANS_DB.get(scan_id)
    if not record:
        raise HTTPException(status_code=404, detail="Scan record not found")
    return record


@router.delete("/{scan_id}")
def delete_scan(scan_id: str, current_user: dict = Depends(require_admin)):
    existed_in_memory = SCANS_DB.pop(scan_id, None) is not None
    deleted_in_db = delete_scan_record(scan_id)
    if not existed_in_memory and not deleted_in_db:
        raise HTTPException(status_code=404, detail="Scan record not found")
    return {"message": f"Scan record {scan_id} deleted successfully."}
