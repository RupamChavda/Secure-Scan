import json
from fastapi import APIRouter, HTTPException, Depends
from pydantic import BaseModel
from typing import List, Optional
from backend.models import AIRiskSummary, SeverityEnum
from backend.routers.auth import get_current_user
from backend.ai_client import call_claude, is_ai_configured, AIUnavailableError

router = APIRouter(prefix="/ai", tags=["AI Risk Analysis"])

class AIExplainRequest(BaseModel):
    vulnerability_title: str
    cve_id: Optional[str] = "N/A"
    description: str

class AIExplainResponse(BaseModel):
    explanation: str
    remediation_steps: List[str]
    cwe_code: str
    ai_powered: bool = False

class AIChatRequest(BaseModel):
    message: str
    # Optional grounding context so the assistant can reason about a specific
    # scan's real findings instead of answering generically.
    scan_context: Optional[str] = None

class AIChatResponse(BaseModel):
    response: str
    suggested_actions: List[str]
    ai_powered: bool = False


CHAT_SYSTEM_PROMPT = (
    "You are the SecureScan AI Assistant, embedded in an enterprise vulnerability scanning platform. "
    "You help security analysts and non-technical stakeholders understand vulnerability findings, CVEs, "
    "attack techniques, and remediation steps. Be accurate, concise, and practical. When relevant, include "
    "a short code example. Keep replies under ~200 words unless the question needs more detail. "
    "After your explanation, on a new line write 'ACTIONS:' followed by 2-4 short, concrete next-step "
    "suggestions separated by ' | ' (e.g. 'ACTIONS: Upgrade log4j-core to 2.17.1 | Enable WAF rule for JNDI | Re-scan after patching')."
)

EXPLAIN_SYSTEM_PROMPT = (
    "You are a security analyst explaining a vulnerability finding for a report. Given a finding title, "
    "optional CVE ID, and technical description, respond ONLY with a compact JSON object (no markdown, no "
    "prose outside the JSON) with exactly these keys: "
    '{"explanation": "2-4 plain-language sentences explaining the risk for a mixed technical/non-technical audience", '
    '"remediation_steps": ["step 1", "step 2", "step 3"], '
    '"cwe_code": "the most relevant CWE identifier(s), e.g. CWE-89"}'
)


def _parse_actions(reply_text: str, fallback_actions: List[str]) -> (str, List[str]):
    if "ACTIONS:" in reply_text:
        main, _, actions_part = reply_text.partition("ACTIONS:")
        actions = [a.strip("-• \n") for a in actions_part.split("|") if a.strip()]
        return main.strip(), (actions or fallback_actions)
    return reply_text.strip(), fallback_actions


def _rule_based_chat(message: str) -> AIChatResponse:
    msg = message.lower()

    if "sql" in msg:
        reply = "SQL Injection occurs when unvalidated user input is directly concatenated into database queries. **Remediation**: Use parameterized queries / prepared statements via ORMs like SQLAlchemy or Django ORM.\n```python\n# Secure Example\ncursor.execute('SELECT * FROM users WHERE id = %s', (user_id,))\n```"
        actions = ["Enforce ORM parameterization", "Enable Web Application Firewall (WAF)", "Audit raw SQL statements"]
    elif "log4j" in msg or "cve-2021-44228" in msg:
        reply = "Log4Shell (CVE-2021-44228) allows remote code execution via LDAP JNDI lookups in Apache Log4j2 versions 2.0-beta9 to 2.14.1. **Remediation**: Upgrade `log4j-core` to version **2.17.1** or higher immediately."
        actions = ["Upgrade log4j-core to >= 2.17.1", "Set system property -Dlog4j2.formatMsgNoLookups=true"]
    elif "xss" in msg:
        reply = "Cross-Site Scripting (XSS) allows attackers to inject malicious scripts into trusted web pages. **Remediation**: Contextually encode user inputs in HTML templates, and enforce a strong Content-Security-Policy (CSP) header."
        actions = ["Configure CSP HTTP Header", "Use DOM-safe textContent instead of innerHTML", "Contextually encode HTML outputs"]
    elif "secret" in msg or "aws" in msg or "token" in msg:
        reply = "Hardcoded credentials in source code pose a critical security risk if repositories are accessed or exposed. **Remediation**: Revoke the exposed keys, migrate credentials to Environment Variables or Secret Managers (e.g. AWS Secrets Manager / HashiCorp Vault)."
        actions = ["Revoke exposed API keys", "Add .env to .gitignore", "Scan repo with GitLeaks"]
    else:
        reply = f"I am your **SecureScan AI Assistant**. I analyzed your query regarding '{message}'. For target security, prioritize remediating Critical/High severity findings, enforcing strict input validation, keeping dependencies updated, and reviewing generated PDF executive reports."
        actions = ["Run SAST audit on project archive", "View Executive PDF Security Report", "Scan target IP for open ports"]

    return AIChatResponse(response=reply, suggested_actions=actions, ai_powered=False)


@router.post("/chat", response_model=AIChatResponse)
def ai_chat_copilot(req: AIChatRequest, current_user: dict = Depends(get_current_user)):
    if not is_ai_configured():
        return _rule_based_chat(req.message)

    try:
        user_prompt = req.message
        if req.scan_context:
            user_prompt = f"Context from the current scan the user is looking at:\n{req.scan_context}\n\nUser question: {req.message}"

        reply_text = call_claude(CHAT_SYSTEM_PROMPT, user_prompt, max_tokens=600)
        main_text, actions = _parse_actions(
            reply_text,
            fallback_actions=["Review the detailed findings for this scan", "Re-scan after applying fixes"]
        )
        return AIChatResponse(response=main_text, suggested_actions=actions, ai_powered=True)
    except AIUnavailableError:
        # Real AI is configured but this call failed (rate limit, network blip, etc.) — fall back gracefully.
        fallback = _rule_based_chat(req.message)
        fallback.response += "\n\n_(Note: the AI assistant is temporarily unavailable — this is a standard rule-based answer.)_"
        return fallback


def _rule_based_explain(req: AIExplainRequest) -> AIExplainResponse:
    return AIExplainResponse(
        explanation=f"The finding '{req.vulnerability_title}' ({req.cve_id}) indicates a security gap where an attacker can exploit improperly formatted input handling or missing access controls. In simple terms, user input is processed directly without sufficient validation.",
        remediation_steps=[
            "Sanitize and validate all incoming request parameters.",
            "Use parameterized database queries and modern frameworks with built-in protection.",
            "Implement strict Content Security Policy headers and rate limiting."
        ],
        cwe_code="CWE-89 / CWE-79",
        ai_powered=False
    )


@router.post("/explain", response_model=AIExplainResponse)
def explain_vulnerability(req: AIExplainRequest, current_user: dict = Depends(get_current_user)):
    if not is_ai_configured():
        return _rule_based_explain(req)

    try:
        user_prompt = (
            f"Vulnerability title: {req.vulnerability_title}\n"
            f"CVE ID: {req.cve_id}\n"
            f"Description/evidence: {req.description}"
        )
        reply_text = call_claude(EXPLAIN_SYSTEM_PROMPT, user_prompt, max_tokens=500)

        # Strip accidental markdown code fences before parsing JSON.
        cleaned = reply_text.strip()
        if cleaned.startswith("```"):
            cleaned = cleaned.strip("`")
            if cleaned.lower().startswith("json"):
                cleaned = cleaned[4:]
        parsed = json.loads(cleaned)

        return AIExplainResponse(
            explanation=parsed.get("explanation", "").strip() or _rule_based_explain(req).explanation,
            remediation_steps=parsed.get("remediation_steps") or _rule_based_explain(req).remediation_steps,
            cwe_code=parsed.get("cwe_code", "N/A"),
            ai_powered=True
        )
    except (AIUnavailableError, json.JSONDecodeError, Exception):
        return _rule_based_explain(req)
