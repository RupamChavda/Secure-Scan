from fastapi import APIRouter, HTTPException, Depends
from typing import List
from backend.models import ScheduleCreate, ScheduleResponse
from backend.routers.auth import get_current_user, require_admin
from backend.scheduler import create_schedule, list_schedules, delete_schedule
from backend.target_safety import assess_scan_target, UnsafeScanTargetError

router = APIRouter(prefix="/schedules", tags=["Recurring Scans"])


@router.post("", response_model=ScheduleResponse)
def create_recurring_scan(schedule_in: ScheduleCreate, current_user: dict = Depends(get_current_user)):
    try:
        assess_scan_target(schedule_in.target)
    except UnsafeScanTargetError as e:
        raise HTTPException(status_code=400, detail=str(e))

    record = create_schedule(
        target=schedule_in.target,
        target_type=schedule_in.target_type,
        scan_types=schedule_in.scan_types,
        interval=schedule_in.interval,
        created_by=current_user["username"],
        webhook_url=schedule_in.webhook_url,
        custom_headers=schedule_in.custom_headers,
    )
    return record


@router.get("", response_model=List[ScheduleResponse])
def get_schedules(current_user: dict = Depends(get_current_user)):
    return list_schedules()


@router.delete("/{schedule_id}")
def remove_schedule(schedule_id: str, current_user: dict = Depends(require_admin)):
    if not delete_schedule(schedule_id):
        raise HTTPException(status_code=404, detail="Schedule not found")
    return {"message": f"Schedule {schedule_id} deleted successfully."}
