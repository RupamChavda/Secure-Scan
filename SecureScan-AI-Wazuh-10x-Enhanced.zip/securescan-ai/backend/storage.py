import json
import os
from typing import Dict, List, Any, Optional

from backend.db import kv_set, kv_get, kv_delete, kv_list, kv_get_all_dict, kv_count, kv_clear_missing

DATA_DIR = os.path.join(os.path.dirname(__file__), "data")
os.makedirs(DATA_DIR, exist_ok=True)

# Legacy flat-file paths from the pre-database version of this platform.
# On first run against the new SQLite store, any existing legacy JSON data is
# migrated in automatically so nobody loses their scan history switching
# between versions, then the legacy file is renamed so migration only runs once.
_LEGACY_SCANS_FILE = os.path.join(DATA_DIR, "scans_db.json")
_LEGACY_ASSETS_FILE = os.path.join(DATA_DIR, "assets_db.json")
_LEGACY_CVE_FILE = os.path.join(DATA_DIR, "cve_db.json")
_LEGACY_USERS_FILE = os.path.join(DATA_DIR, "users_db.json")


def _migrate_legacy_json(namespace: str, legacy_path: str, key_field: str, sort_field: Optional[str] = None, is_dict_of_dicts: bool = False):
    if not os.path.exists(legacy_path) or kv_count(namespace) > 0:
        return
    try:
        with open(legacy_path, "r", encoding="utf-8") as f:
            raw = json.load(f)
    except Exception:
        return

    items = list(raw.values()) if is_dict_of_dicts else raw
    for item in items:
        key = item.get(key_field)
        if not key:
            continue
        sort_val = str(item.get(sort_field, key)) if sort_field else str(key)
        kv_set(namespace, key, item, sort_key=sort_val)

    try:
        os.rename(legacy_path, legacy_path + ".migrated")
    except Exception:
        pass


# ============================================================================
# Default seed datasets (used only when the database is empty on first boot)
# ============================================================================
DEFAULT_ASSETS = [
    {
        "id": "ast-001",
        "name": "CyberShield Production Web Portal",
        "target": "https://app.corp-securescan.internal",
        "asset_type": "Website URL",
        "tags": ["Production", "Web", "PCI-DSS"],
        "owner": "AppSec Team",
        "department": "Engineering",
        "status": "Active",
        "last_scanned": "2026-08-05T20:00:00Z"
    },
    {
        "id": "ast-002",
        "name": "Core Banking API Gateway",
        "target": "192.168.10.45",
        "asset_type": "IP Address",
        "tags": ["PCI-DSS", "Critical", "API"],
        "owner": "Infrastructure Team",
        "department": "IT Operations",
        "status": "Active",
        "last_scanned": "2026-08-06T10:15:00Z"
    },
    {
        "id": "ast-003",
        "name": "CyberShield Source Repo Archive",
        "target": "CyberShield_COMPLETE.zip",
        "asset_type": "Uploaded ZIP",
        "tags": ["SourceCode", "Python", "Secrets Audit"],
        "owner": "DevSecOps",
        "department": "Engineering",
        "status": "Active",
        "last_scanned": "2026-08-06T18:00:00Z"
    }
]

DEFAULT_CVES = [
    {
        "cve_id": "CVE-2024-3094",
        "title": "XZ Utils Backdoor Remote Code Execution",
        "severity": "Critical",
        "cvss_score": 10.0,
        "cisa_kev": True,
        "exploit_available": True,
        "summary": "Malicious code discovered in XZ Utils versions 5.6.0 and 5.6.1 allowing SSH authentication bypass.",
        "affected_products": ["XZ Utils 5.6.0", "XZ Utils 5.6.1", "Fedora 40", "Debian Testing"],
        "published_date": "2024-03-29"
    },
    {
        "cve_id": "CVE-2023-45853",
        "title": "Zlib Buffer Overflow Vulnerability",
        "severity": "High",
        "cvss_score": 8.8,
        "cisa_kev": False,
        "exploit_available": True,
        "summary": "Integer overflow in zlib zipOpenNewFileInZip4 allows remote code execution via malformed ZIP archives.",
        "affected_products": ["Zlib <= 1.3", "Minizip <= 1.3"],
        "published_date": "2023-10-14"
    },
    {
        "cve_id": "CVE-2021-44228",
        "title": "Apache Log4j2 Remote Code Execution (Log4Shell)",
        "severity": "Critical",
        "cvss_score": 10.0,
        "cisa_kev": True,
        "exploit_available": True,
        "summary": "Apache Log4j2 JNDI features do not protect against attacker controlled LDAP lookups leading to RCE.",
        "affected_products": ["Apache Log4j 2.0 - 2.14.1"],
        "published_date": "2021-12-10"
    },
    {
        "cve_id": "CVE-2023-38606",
        "title": "Apple iOS Kernel Memory Corruption Vulnerability",
        "severity": "High",
        "cvss_score": 7.8,
        "cisa_kev": True,
        "exploit_available": False,
        "summary": "An app may be able to modify sensitive kernel state leading to arbitrary code execution with kernel privileges.",
        "affected_products": ["iOS < 16.6", "iPadOS < 16.6", "macOS Ventura < 13.5"],
        "published_date": "2023-07-24"
    }
]


# ============================================================================
# SCANS — supports real pagination directly against SQLite
# ============================================================================
def get_persisted_scans() -> Dict[str, Any]:
    """Full-collection load, kept for backward compatibility with code that
    wants an in-memory {scan_id: scan} cache."""
    _migrate_legacy_json("scans", _LEGACY_SCANS_FILE, "id", "start_time")
    return kv_get_all_dict("scans")


def save_persisted_scans(scans: Dict[str, Any]):
    for scan_id, scan in scans.items():
        kv_set("scans", scan_id, scan, sort_key=str(scan.get("start_time", scan_id)))


def save_scan_record(scan_id: str, scan: Dict[str, Any]):
    """Efficient single-record write — avoids rewriting the whole scan history on every progress update."""
    kv_set("scans", scan_id, scan, sort_key=str(scan.get("start_time", scan_id)))


def delete_scan_record(scan_id: str) -> bool:
    return kv_delete("scans", scan_id)


def get_scan_record(scan_id: str) -> Optional[Dict[str, Any]]:
    return kv_get("scans", scan_id)


def list_scans_paginated(limit: Optional[int] = None, offset: int = 0) -> List[Dict[str, Any]]:
    """Real SQL-backed pagination — only the requested page is loaded from disk."""
    return kv_list("scans", order_desc=True, limit=limit, offset=offset)


def count_scans() -> int:
    return kv_count("scans")


# ============================================================================
# ASSETS
# ============================================================================
def get_persisted_assets() -> List[Dict[str, Any]]:
    _migrate_legacy_json("assets", _LEGACY_ASSETS_FILE, "id")
    if kv_count("assets") == 0:
        for a in DEFAULT_ASSETS:
            kv_set("assets", a["id"], a, sort_key=a["id"])
    return kv_list("assets", order_desc=False)


def save_persisted_assets(assets: List[Dict[str, Any]]):
    kv_clear_missing("assets", {a["id"] for a in assets})
    for a in assets:
        kv_set("assets", a["id"], a, sort_key=a["id"])


# ============================================================================
# CVE CATALOG
# ============================================================================
def get_persisted_cves() -> List[Dict[str, Any]]:
    _migrate_legacy_json("cves", _LEGACY_CVE_FILE, "cve_id")
    if kv_count("cves") == 0:
        for c in DEFAULT_CVES:
            kv_set("cves", c["cve_id"], c, sort_key=c["cve_id"])
    return kv_list("cves", order_desc=False)


def save_persisted_cves(cves: List[Dict[str, Any]]):
    kv_clear_missing("cves", {c["cve_id"] for c in cves})
    for c in cves:
        kv_set("cves", c["cve_id"], c, sort_key=c["cve_id"])


# ============================================================================
# USERS
# ============================================================================
def get_persisted_users(default_users: Dict[str, Any]) -> Dict[str, Any]:
    _migrate_legacy_json("users", _LEGACY_USERS_FILE, "username", is_dict_of_dicts=True)
    if kv_count("users") == 0:
        for uname, u in default_users.items():
            kv_set("users", uname, u, sort_key=uname)
    return kv_get_all_dict("users")


def save_persisted_users(users: Dict[str, Any]):
    for uname, u in users.items():
        kv_set("users", uname, u, sort_key=uname)
