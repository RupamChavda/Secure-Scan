"""Create the first SecureScan administrator from environment variables.
Run once: python -m backend.bootstrap_admin
"""
import os
from datetime import datetime, timezone
from backend.routers.auth import USERS_DB, hash_password
from backend.storage import save_persisted_users
from backend.models import RoleEnum

username = os.getenv("BOOTSTRAP_ADMIN_USERNAME", "").strip().lower()
password = os.getenv("BOOTSTRAP_ADMIN_PASSWORD", "")
email = os.getenv("BOOTSTRAP_ADMIN_EMAIL", "")
if not username or not password or not email:
    raise SystemExit("Set BOOTSTRAP_ADMIN_USERNAME, BOOTSTRAP_ADMIN_PASSWORD and BOOTSTRAP_ADMIN_EMAIL")
if len(password) < 12:
    raise SystemExit("BOOTSTRAP_ADMIN_PASSWORD must be at least 12 characters")
if username in USERS_DB:
    raise SystemExit(f"User already exists: {username}")
USERS_DB[username] = {
    "id": "usr-bootstrap",
    "username": username,
    "email": email,
    "password_hash": hash_password(password),
    "role": RoleEnum.ADMIN,
    "full_name": "SecureScan Administrator",
    "created_at": datetime.now(timezone.utc).isoformat().replace("+00:00", "Z"),
}
save_persisted_users(USERS_DB)
print(f"Created administrator: {username}")
