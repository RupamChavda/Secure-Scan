"""
Webhook-based alerting for scan results.

When a scan is configured with a webhook_url and finds Critical/High
severity issues, this module POSTs a structured JSON payload to that URL —
compatible with generic webhook receivers (Slack incoming webhooks accept a
similar shape via a thin adapter; most SIEM/ticketing tools accept raw JSON
directly). Email delivery is intentionally not implemented here since it
requires SMTP credentials this platform doesn't have configured by default —
see send_scan_alert's docstring for how to add it.
"""
import requests
from typing import Dict, Any


def build_alert_payload(scan: Dict[str, Any]) -> Dict[str, Any]:
    ai = scan.get("ai_analysis") or {}
    return {
        "event": "securescan.scan_completed",
        "scan_id": scan.get("id"),
        "target": scan.get("target"),
        "status": scan.get("status"),
        "requested_by": scan.get("requested_by"),
        "started_at": scan.get("start_time"),
        "completed_at": scan.get("end_time"),
        "summary": {
            "total_vulnerabilities": scan.get("total_vulnerabilities", 0),
            "critical": scan.get("critical_count", 0),
            "high": scan.get("high_count", 0),
            "medium": scan.get("medium_count", 0),
            "low": scan.get("low_count", 0),
            "overall_risk_score": ai.get("overall_risk_score"),
        },
        "executive_summary": ai.get("executive_summary"),
        "top_findings": [
            {"title": v.get("title"), "severity": str(v.get("severity")), "cve_id": v.get("cve_id")}
            for v in (scan.get("vulnerabilities") or [])
            if str(v.get("severity")) in ("Critical", "High")
        ][:10],
    }


def send_scan_alert(webhook_url: str, scan: Dict[str, Any], timeout: int = 8):
    """
    Sends a best-effort webhook notification. Raises on failure so the caller
    can log it — but a failed alert must never fail or block the scan itself,
    so callers should always wrap this in a try/except (execute_scan_job does).

    To add email alerting instead of/alongside webhooks: configure SMTP
    settings (host, port, credentials, from-address) in config.py, then add
    an smtplib.SMTP call here guarded the same way as the webhook POST below.
    """
    payload = build_alert_payload(scan)
    resp = requests.post(webhook_url, json=payload, timeout=timeout)
    resp.raise_for_status()
    return resp
