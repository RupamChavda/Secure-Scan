"""
Lightweight in-process scheduler for recurring scans.

Runs as a daemon background thread inside the FastAPI process: every
SCHEDULER_POLL_SECONDS it checks the 'schedules' table for any schedule whose
next_run_at has passed, kicks off a new scan for it (reusing the same
execute_scan_job pipeline as an on-demand scan), and reschedules it for its
next interval. This intentionally avoids pulling in an external task queue
(Celery/Redis) to keep the platform's deployment footprint small — for very
large fleets of scheduled scans, swapping this for a real task queue would be
the next step, but for a single-instance deployment this is a correct and
sufficient design.
"""
import threading
import time
import uuid
from datetime import datetime, timedelta
from typing import Optional

from backend.db import kv_set, kv_get, kv_delete, kv_list

SCHEDULE_NAMESPACE = "schedules"
SCHEDULER_POLL_SECONDS = 30

INTERVAL_TO_TIMEDELTA = {
    "Hourly": timedelta(hours=1),
    "Daily": timedelta(days=1),
    "Weekly": timedelta(weeks=1),
}

_scheduler_thread: Optional[threading.Thread] = None
_stop_event = threading.Event()


def create_schedule(target: str, target_type, scan_types, interval: str, created_by: str, webhook_url=None, custom_headers=None) -> dict:
    schedule_id = f"sched-{uuid.uuid4().hex[:8]}"
    now = datetime.utcnow()
    next_run = now + INTERVAL_TO_TIMEDELTA.get(interval, timedelta(days=1))
    record = {
        "id": schedule_id,
        "target": target,
        "target_type": target_type,
        "scan_types": scan_types,
        "interval": interval,
        "webhook_url": webhook_url,
        "custom_headers": custom_headers,
        "created_by": created_by,
        "created_at": now.isoformat() + "Z",
        "next_run_at": next_run.isoformat() + "Z",
        "last_run_at": None,
        "last_scan_id": None,
        "enabled": True,
    }
    kv_set(SCHEDULE_NAMESPACE, schedule_id, record, sort_key=record["next_run_at"])
    return record


def list_schedules() -> list:
    return kv_list(SCHEDULE_NAMESPACE, order_desc=False)


def delete_schedule(schedule_id: str) -> bool:
    return kv_delete(SCHEDULE_NAMESPACE, schedule_id)


def _run_due_schedules():
    """Checks all schedules and triggers any that are due. Imports scan
    execution lazily to avoid a circular import between scheduler <-> scans router."""
    from backend.routers.scans import _new_scan_record, execute_scan_job, SCANS_DB
    from backend.storage import save_scan_record

    now = datetime.utcnow()
    for schedule in list_schedules():
        if not schedule.get("enabled", True):
            continue
        try:
            next_run_at = datetime.fromisoformat(schedule["next_run_at"].replace("Z", ""))
        except Exception:
            continue
        if next_run_at > now:
            continue

        scan_id = f"scan-{uuid.uuid4().hex[:8]}"
        scan_obj = _new_scan_record(
            scan_id,
            schedule["target"],
            schedule["target_type"],
            schedule["scan_types"],
            requested_by=f"scheduler ({schedule['created_by']})",
            custom_headers=schedule.get("custom_headers"),
            webhook_url=schedule.get("webhook_url"),
        )
        SCANS_DB[scan_id] = scan_obj
        save_scan_record(scan_id, scan_obj)

        try:
            execute_scan_job(scan_id)
        except Exception:
            pass  # a failed scheduled run shouldn't crash the scheduler loop

        interval_delta = INTERVAL_TO_TIMEDELTA.get(schedule["interval"], timedelta(days=1))
        schedule["last_run_at"] = now.isoformat() + "Z"
        schedule["last_scan_id"] = scan_id
        schedule["next_run_at"] = (now + interval_delta).isoformat() + "Z"
        kv_set(SCHEDULE_NAMESPACE, schedule["id"], schedule, sort_key=schedule["next_run_at"])


def _scheduler_loop():
    while not _stop_event.is_set():
        try:
            _run_due_schedules()
        except Exception:
            pass  # scheduler must never crash the whole process
        _stop_event.wait(SCHEDULER_POLL_SECONDS)


def start_scheduler():
    global _scheduler_thread
    if _scheduler_thread and _scheduler_thread.is_alive():
        return
    _stop_event.clear()
    _scheduler_thread = threading.Thread(target=_scheduler_loop, daemon=True, name="securescan-scheduler")
    _scheduler_thread.start()


def stop_scheduler():
    _stop_event.set()
