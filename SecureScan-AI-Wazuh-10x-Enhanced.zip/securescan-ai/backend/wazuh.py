"""Production-oriented Wazuh integration for SecureScan AI.

Outbound: SecureScan findings -> durable SQLite outbox -> Wazuh Manager.
Inbound: Wazuh API/Indexer -> endpoint vulnerability inventory + alerts.
Wazuh 4.8+ vulnerability data is read from wazuh-states-vulnerabilities-*.
"""
import hashlib
import json
import logging
import socket
import threading
import time
from datetime import datetime, timezone
from typing import Any, Dict, List, Optional

import requests
import urllib3

from backend.config import settings
from backend.db import (
    outbox_put, outbox_pending, outbox_mark_delivered, outbox_mark_retry,
    outbox_stats, save_wazuh_vulnerabilities, list_wazuh_vulnerabilities,
    count_wazuh_vulnerabilities,
)

logger = logging.getLogger("securescan.wazuh")
if not settings.WAZUH_VERIFY_TLS:
    urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)

_lock = threading.Lock()
_worker: Optional[threading.Thread] = None
_stop = threading.Event()
_stats = {"sent": 0, "failed": 0, "last_success": None, "last_error": None}
_DEDUP_TTL = 3600
_seen: Dict[str, float] = {}


def _now() -> str:
    return datetime.now(timezone.utc).isoformat().replace("+00:00", "Z")


def normalize_severity(sev: Any) -> str:
    v = str(getattr(sev, "value", sev)).lower().strip()
    for key, out in (("crit", "critical"), ("high", "high"), ("med", "medium"), ("low", "low")):
        if key in v:
            return out
    return "info"


def _get(obj: Any, key: str, default: Any = None) -> Any:
    return obj.get(key, default) if isinstance(obj, dict) else getattr(obj, key, default)


def _clean(*vals):
    for v in vals:
        if v not in (None, "", "N/A"):
            return v
    return None


def format_wazuh_event(scan_id: str, target: str, vuln: Any, scanner_name: str = "SecureScan-Engine") -> Dict[str, Any]:
    if hasattr(vuln, "model_dump"):
        vuln = vuln.model_dump()
    elif hasattr(vuln, "dict") and callable(vuln.dict):
        vuln = vuln.dict()
    event = {
        "integration": "securescan-ai",
        "event_type": "vulnerability",
        "scan_id": scan_id,
        "target": target,
        "severity": normalize_severity(_get(vuln, "severity", "info")),
        "title": str(_clean(_get(vuln, "title"), _get(vuln, "name")) or "Vulnerability Detected"),
        "scanner": str(_get(vuln, "scanner") or scanner_name),
        "timestamp": _now(),
    }
    cvss = _clean(_get(vuln, "cvss_score"), _get(vuln, "cvss"))
    try:
        if cvss is not None:
            event["cvss"] = float(cvss)
    except (TypeError, ValueError):
        pass
    for out, keys in (("description", ("description",)), ("cve", ("cve_id", "cve")),
                      ("cwe", ("cwe_id", "cwe")), ("owasp", ("owasp_category", "owasp")),
                      ("mitre", ("mitre_attack", "mitre")), ("evidence", ("evidence",)),
                      ("affected_asset", ("affected_asset",))):
        val = _clean(*[_get(vuln, k) for k in keys])
        if val:
            event[out] = str(val)[:2000]
    return event


def _hash(e: Dict[str, Any]) -> str:
    stable = {k: e.get(k) for k in ("event_type", "target", "title", "cve", "evidence", "scan_id")}
    return hashlib.sha256(json.dumps(stable, sort_keys=True, default=str).encode()).hexdigest()


def _is_duplicate(e: Dict[str, Any]) -> bool:
    h, now = _hash(e), time.time()
    with _lock:
        expired = [k for k, ts in _seen.items() if now - ts > _DEDUP_TTL]
        for k in expired:
            _seen.pop(k, None)
        if h in _seen:
            return True
        _seen[h] = now
    return False


def _transmit(events: List[Dict[str, Any]], timeout: float = 5.0) -> None:
    host, port = settings.WAZUH_HOST, int(settings.WAZUH_SYSLOG_PORT)
    lines = [(json.dumps(e, separators=(",", ":"), ensure_ascii=False) + "\n").encode() for e in events]
    if settings.WAZUH_PROTOCOL == "udp":
        with socket.socket(socket.AF_INET, socket.SOCK_DGRAM) as s:
            for line in lines:
                s.sendto(line, (host, port))
        return
    with socket.create_connection((host, port), timeout=timeout) as s:
        s.settimeout(timeout)
        s.sendall(b"".join(lines))


def _run_worker() -> None:
    while not _stop.is_set():
        rows = outbox_pending(settings.WAZUH_OUTBOX_BATCH_SIZE)
        if not rows:
            _stop.wait(settings.WAZUH_OUTBOX_POLL_SECONDS)
            continue
        # Keep retry granularity at event level so one malformed event cannot poison a whole batch forever.
        for row in rows:
            if _stop.is_set():
                break
            try:
                _transmit([row["payload"]])
                outbox_mark_delivered([row["id"]])
                with _lock:
                    _stats["sent"] += 1
                    _stats["last_success"] = _now()
                    _stats["last_error"] = None
            except Exception as exc:  # noqa: BLE001
                attempts = int(row.get("attempts", 0)) + 1
                outbox_mark_retry(row["id"], attempts, str(exc), settings.WAZUH_OUTBOX_MAX_RETRIES)
                with _lock:
                    _stats["failed"] += 1
                    _stats["last_error"] = f"{_now()} {settings.WAZUH_HOST}:{settings.WAZUH_SYSLOG_PORT} - {exc}"
                logger.warning("Wazuh delivery failed (attempt %s): %s", attempts, exc)


def _ensure_worker() -> None:
    global _worker
    with _lock:
        if _worker is None or not _worker.is_alive():
            _stop.clear()
            _worker = threading.Thread(target=_run_worker, name="wazuh-durable-sender", daemon=True)
            _worker.start()


def enqueue_event(event: Dict[str, Any]) -> bool:
    if not settings.WAZUH_ENABLED or _is_duplicate(event):
        return False
    inserted = outbox_put(_hash(event), event)
    if inserted:
        _ensure_worker()
    return inserted


def flush(timeout: float = 30.0) -> bool:
    end = time.time() + timeout
    while time.time() < end:
        stats = outbox_stats()
        if stats["pending"] == 0:
            return True
        time.sleep(0.2)
    return outbox_stats()["pending"] == 0


def emit_scan_findings(scan: Dict[str, Any]) -> int:
    if not settings.WAZUH_ENABLED:
        return 0
    scan_id, target = scan.get("id", "unknown"), scan.get("target", "unknown")
    queued = 0
    for v in scan.get("vulnerabilities") or []:
        try:
            if enqueue_event(format_wazuh_event(scan_id, target, v)):
                queued += 1
        except Exception as exc:  # noqa: BLE001
            logger.warning("Wazuh finding queue failed: %s", exc)
    # Scan completion is telemetry, not a vulnerability.
    summary = {
        "integration": "securescan-ai", "event_type": "scan_summary", "scan_id": scan_id,
        "target": target, "severity": "info", "title": "SecureScan scan completed",
        "scanner": "SecureScan-Engine", "total": scan.get("total_vulnerabilities", 0),
        "critical_count": scan.get("critical_count", 0), "high_count": scan.get("high_count", 0),
        "medium_count": scan.get("medium_count", 0), "low_count": scan.get("low_count", 0),
        "timestamp": _now(),
    }
    enqueue_event(summary)
    return queued


def _tcp_reachable(host: str, port: int, timeout: float = 2.0) -> bool:
    try:
        with socket.create_connection((host, port), timeout=timeout):
            return True
    except OSError:
        return False


def _api_token() -> Optional[str]:
    if not settings.WAZUH_API_URL or not settings.WAZUH_API_USER or not settings.WAZUH_API_PASSWORD:
        return None
    r = requests.post(f"{settings.WAZUH_API_URL.rstrip('/')}/security/user/authenticate?raw=true",
                      auth=(settings.WAZUH_API_USER, settings.WAZUH_API_PASSWORD),
                      verify=settings.WAZUH_VERIFY_TLS, timeout=8)
    r.raise_for_status()
    return r.text.strip()


def _api_info() -> Dict[str, Any]:
    if not settings.WAZUH_API_URL:
        return {"configured": False, "ok": False, "reason": "WAZUH_API_URL is not configured"}
    try:
        token = _api_token()
        if not token:
            return {"configured": True, "ok": False, "reason": "Wazuh API credentials are not configured"}
        h = {"Authorization": f"Bearer {token}"}
        base = settings.WAZUH_API_URL.rstrip("/")
        info = requests.get(f"{base}/", headers=h, verify=settings.WAZUH_VERIFY_TLS, timeout=8).json().get("data", {})
        agents = requests.get(f"{base}/agents/summary/status", headers=h, verify=settings.WAZUH_VERIFY_TLS, timeout=8).json().get("data", {}).get("connection", {})
        return {"configured": True, "ok": True, "version": info.get("api_version"), "agents": agents}
    except Exception as exc:  # noqa: BLE001
        return {"configured": True, "ok": False, "error": str(exc)[:300]}


def _indexer_request(path: str, payload: Dict[str, Any], timeout: int = 12):
    if not settings.WAZUH_INDEXER_URL or not settings.WAZUH_INDEXER_USER or not settings.WAZUH_INDEXER_PASSWORD:
        raise RuntimeError("Wazuh Indexer URL/credentials are not fully configured")
    return requests.post(f"{settings.WAZUH_INDEXER_URL.rstrip('/')}/{path.lstrip('/')}", json=payload,
                         auth=(settings.WAZUH_INDEXER_USER, settings.WAZUH_INDEXER_PASSWORD),
                         verify=settings.WAZUH_VERIFY_TLS, timeout=timeout)


def _dig(d: Dict[str, Any], *path, default=None):
    cur = d
    for key in path:
        if not isinstance(cur, dict):
            return default
        cur = cur.get(key)
    return default if cur is None else cur


def _normalize_wazuh_vuln(source: Dict[str, Any]) -> Dict[str, Any]:
    agent = source.get("agent") or {}
    package = source.get("package") or {}
    vuln = source.get("vulnerability") or {}
    score = _clean(vuln.get("score"), vuln.get("cvss"), source.get("cvss"))
    if isinstance(score, dict):
        score = score.get("base") or score.get("score")
    try: score = float(score) if score is not None else None
    except (TypeError, ValueError): score = None
    severity = normalize_severity(vuln.get("severity") or source.get("severity") or ("critical" if score and score >= 9 else "high" if score and score >= 7 else "medium" if score and score >= 4 else "low"))
    cve = _clean(vuln.get("id"), vuln.get("cve"), source.get("cve"))
    agent_id = _clean(agent.get("id"), source.get("agent_id"))
    agent_name = _clean(agent.get("name"), source.get("agent_name"))
    hostname = _clean(source.get("host"), source.get("hostname"), _dig(source, "agent", "host"))
    package_name = _clean(package.get("name"), source.get("package_name"))
    package_version = _clean(package.get("version"), source.get("package_version"))
    fixed_version = _clean(package.get("fixed_version"), vuln.get("fixed_version"), source.get("fixed_version"))
    status = _clean(vuln.get("status"), source.get("status"), "Active")
    raw_identity = "|".join(str(x or "") for x in (agent_id, hostname, package_name, package_version, cve))
    fp = hashlib.sha256(raw_identity.encode()).hexdigest()
    now = _now()
    return {
        "fingerprint": fp, "agent_id": agent_id, "agent_name": agent_name, "hostname": hostname,
        "os_name": _clean(_dig(source, "host", "os", "name"), _dig(source, "os", "name"), source.get("os_name")),
        "package_name": package_name, "package_version": package_version, "fixed_version": fixed_version,
        "cve_id": cve, "severity": severity, "cvss_score": score, "status": status,
        "reference": _clean(vuln.get("reference"), source.get("reference")),
        "description": _clean(vuln.get("description"), source.get("description")),
        "raw": source, "first_seen": now, "last_seen": now,
    }


def sync_wazuh_vulnerabilities(limit: int = 500) -> Dict[str, Any]:
    """Read native Wazuh 4.8+ vulnerability state documents from the Indexer."""
    query = {"size": max(1, min(limit, 1000)), "sort": [{"@timestamp": "desc"}], "query": {"match_all": {}}}
    r = _indexer_request(f"{settings.WAZUH_VULN_INDEX}/_search", query)
    r.raise_for_status()
    hits = r.json().get("hits", {}).get("hits", [])
    items = [_normalize_wazuh_vuln(h.get("_source", {})) for h in hits]
    saved = save_wazuh_vulnerabilities(items)
    return {"ok": True, "source": settings.WAZUH_VULN_INDEX, "received": len(items), "saved": saved,
            "total": r.json().get("hits", {}).get("total", {}).get("value", len(items))}


def get_wazuh_vulnerabilities(limit: int = 100, offset: int = 0, severity: Optional[str] = None,
                              cve: Optional[str] = None, agent_id: Optional[str] = None, refresh: bool = False) -> Dict[str, Any]:
    sync_error = None
    if refresh:
        try:
            sync_wazuh_vulnerabilities(limit=min(max(limit + offset, 100), 1000))
        except Exception as exc:  # noqa: BLE001
            sync_error = str(exc)[:300]
    rows = list_wazuh_vulnerabilities(limit, offset, severity, cve, agent_id)
    return {"configured": bool(settings.WAZUH_INDEXER_URL), "ok": sync_error is None,
            "vulnerabilities": rows, "count": count_wazuh_vulnerabilities(severity), "sync_error": sync_error}


def get_recent_alerts(limit: int = 20) -> Dict[str, Any]:
    if not settings.WAZUH_INDEXER_URL:
        return {"configured": False, "alerts": []}
    q = {"size": min(max(limit, 1), 100), "sort": [{"timestamp": "desc"}],
         "query": {"bool": {"should": [{"match": {"data.integration": "securescan-ai"}},
                                           {"match": {"rule.groups": "securescan"}}], "minimum_should_match": 1}}}
    try:
        r = _indexer_request("wazuh-alerts-*/_search", q)
        r.raise_for_status()
        out = []
        for hit in r.json().get("hits", {}).get("hits", []):
            s, d = hit.get("_source", {}), hit.get("_source", {}).get("data", {})
            out.append({"time": s.get("timestamp"), "rule_id": _dig(s, "rule", "id"),
                        "level": _dig(s, "rule", "level"), "description": _dig(s, "rule", "description"),
                        "title": d.get("title"), "target": d.get("target"), "severity": d.get("severity"),
                        "scan_id": d.get("scan_id")})
        return {"configured": True, "ok": True, "alerts": out, "total": r.json().get("hits", {}).get("total", {}).get("value", len(out))}
    except Exception as exc:  # noqa: BLE001
        return {"configured": True, "ok": False, "error": str(exc)[:300], "alerts": []}


def get_wazuh_status(deep: bool = False) -> Dict[str, Any]:
    host, port = settings.WAZUH_HOST, int(settings.WAZUH_SYSLOG_PORT)
    reachable = settings.WAZUH_ENABLED and (settings.WAZUH_PROTOCOL == "udp" or _tcp_reachable(host, port))
    with _lock: stats = dict(_stats)
    ob = outbox_stats()
    status = {
        "enabled": settings.WAZUH_ENABLED, "host": host, "port": port, "protocol": settings.WAZUH_PROTOCOL,
        "reachable": bool(reachable), "wazuh_version_target": settings.WAZUH_VERSION,
        "queue_depth": ob["pending"], "outbox": ob, "events_sent": stats["sent"],
        "events_failed": stats["failed"], "last_successful_event": stats["last_success"],
        "last_error": stats["last_error"], "vulnerability_index": settings.WAZUH_VULN_INDEX,
        "vulnerability_count": count_wazuh_vulnerabilities(),
    }
    if deep:
        status["api"] = _api_info()
        if settings.WAZUH_INDEXER_URL:
            try:
                r = requests.get(f"{settings.WAZUH_INDEXER_URL.rstrip('/')}/_cluster/health",
                                 auth=(settings.WAZUH_INDEXER_USER, settings.WAZUH_INDEXER_PASSWORD),
                                 verify=settings.WAZUH_VERIFY_TLS, timeout=8)
                r.raise_for_status()
                status["indexer"] = {"configured": True, "ok": True, "health": r.json()}
            except Exception as exc:
                status["indexer"] = {"configured": True, "ok": False, "error": str(exc)[:300]}
        else:
            status["indexer"] = {"configured": False, "ok": False}
    return status


def test_delivery() -> Dict[str, Any]:
    """Send a non-CVE integration test event; success means local delivery, not a fabricated CVE."""
    event = {"integration": "securescan-ai", "event_type": "integration_test", "severity": "info",
             "title": "SecureScan AI Wazuh integration test", "target": "securescan-ai.test", "timestamp": _now()}
    queued = enqueue_event(event)
    delivered = queued and flush(timeout=15)
    return {"success": bool(delivered), "queued": queued, "event_sent": event,
            "integration_status": get_wazuh_status(deep=True)}
