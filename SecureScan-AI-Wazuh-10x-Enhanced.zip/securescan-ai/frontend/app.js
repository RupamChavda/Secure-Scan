const API_BASE = `${window.location.origin}/api/v1`;
let AUTH_TOKEN = localStorage.getItem("securescan_token") || null;
let CURRENT_USER = JSON.parse(localStorage.getItem("securescan_user") || "null");
let trendChartInstance = null;
let severityChartInstance = null;

// ============================================================================
// AUTHENTICATION
// ============================================================================

// Wrapper around fetch() that automatically attaches the JWT Authorization
// header to every API call, and redirects back to the login screen if the
// session is invalid/expired (HTTP 401).
async function authFetch(url, options = {}) {
    const opts = { ...options };
    opts.headers = { ...(options.headers || {}) };
    if (AUTH_TOKEN) {
        opts.headers["Authorization"] = `Bearer ${AUTH_TOKEN}`;
    }
    const response = await fetch(url, opts);
    if (response.status === 401) {
        logout("Your session has expired. Please log in again.");
        throw new Error("Not authenticated");
    }
    return response;
}

function showLoginScreen(message) {
    const loginScreen = document.getElementById("login-screen");
    const appLayout = document.getElementById("app-layout");
    if (loginScreen) loginScreen.style.display = "flex";
    if (appLayout) appLayout.style.display = "none";
    const errEl = document.getElementById("login-error");
    if (message && errEl) {
        errEl.textContent = message;
        errEl.style.display = "block";
    } else if (errEl) {
        errEl.style.display = "none";
    }
}

function showApp() {
    const loginScreen = document.getElementById("login-screen");
    const appLayout = document.getElementById("app-layout");
    if (loginScreen) loginScreen.style.display = "none";
    if (appLayout) appLayout.style.display = "flex";
    applyRolePermissions();
    initializeAppData();
}

function logout(message) {
    AUTH_TOKEN = null;
    CURRENT_USER = null;
    localStorage.removeItem("securescan_token");
    localStorage.removeItem("securescan_user");
    if (pollInterval) { clearInterval(pollInterval); pollInterval = null; }
    showLoginScreen(message);
}

async function handleLoginSubmit(e) {
    e.preventDefault();
    const username = document.getElementById("login-username").value.trim();
    const password = document.getElementById("login-password").value;
    const submitBtn = document.getElementById("login-submit-btn");
    const errEl = document.getElementById("login-error");

    if (errEl) errEl.style.display = "none";
    if (submitBtn) { submitBtn.disabled = true; submitBtn.innerHTML = '<i class="fa-solid fa-spinner fa-spin"></i> Signing in...'; }

    try {
        const res = await fetch(`${API_BASE}/auth/login`, {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({ username, password })
        });
        if (!res.ok) {
            const err = await res.json().catch(() => ({ detail: "Invalid username or password." }));
            throw new Error(err.detail || "Login failed.");
        }
        const data = await res.json();
        AUTH_TOKEN = data.access_token;
        CURRENT_USER = data.user;
        localStorage.setItem("securescan_token", AUTH_TOKEN);
        localStorage.setItem("securescan_user", JSON.stringify(CURRENT_USER));
        showApp();
    } catch (err) {
        if (errEl) { errEl.textContent = err.message; errEl.style.display = "block"; }
    } finally {
        if (submitBtn) { submitBtn.disabled = false; submitBtn.innerHTML = '<i class="fa-solid fa-right-to-bracket"></i> Sign In'; }
    }
}

function applyRolePermissions() {
    const nameEl = document.getElementById("display-user-name");
    const roleEl = document.getElementById("display-user-role");
    if (nameEl && CURRENT_USER) nameEl.textContent = CURRENT_USER.full_name || CURRENT_USER.username;
    if (roleEl && CURRENT_USER) roleEl.textContent = CURRENT_USER.role || "User";

    const isAdmin = CURRENT_USER && CURRENT_USER.role === "Admin";
    document.querySelectorAll("[data-admin-only]").forEach(el => {
        el.style.display = isAdmin ? "" : "none";
    });
}

// Verifies a stored token is still valid on page load by calling /auth/me.
async function verifySession() {
    if (!AUTH_TOKEN) {
        showLoginScreen();
        return;
    }
    try {
        const res = await fetch(`${API_BASE}/auth/me`, {
            headers: { "Authorization": `Bearer ${AUTH_TOKEN}` }
        });
        if (!res.ok) throw new Error("Session invalid");
        const user = await res.json();
        CURRENT_USER = user;
        localStorage.setItem("securescan_user", JSON.stringify(CURRENT_USER));
        showApp();
    } catch (e) {
        logout();
    }
}

// Initialize Application
document.addEventListener("DOMContentLoaded", () => {
    const loginForm = document.getElementById("login-form");
    if (loginForm) loginForm.addEventListener("submit", handleLoginSubmit);

    document.querySelectorAll(".role-chip").forEach(chip => {
        chip.addEventListener("click", () => {
            document.getElementById("login-username").value = chip.getAttribute("data-user");
            document.getElementById("login-password").value = chip.getAttribute("data-pass");
        });
    });

    const btnLogout = document.getElementById("btn-logout");
    if (btnLogout) {
        btnLogout.addEventListener("click", () => {
            if (confirm("Log out of SecureScan AI?")) logout();
        });
    }

    verifySession();
});

function initializeAppData() {
    initNavigation();
    try { initCharts(); } catch(e) { console.log("Chart init skipped:", e); }
    loadDashboardData();
    loadAssetsData();
    loadCveCatalog();

    checkEngineStatus();
    checkWazuhStatus();
    document.getElementById("btn-wazuh-refresh")?.addEventListener("click", loadWazuhView);
    document.getElementById("btn-wazuh-test")?.addEventListener("click", sendWazuhTest);
    setInterval(checkEngineStatus, 30000);
    setInterval(checkWazuhStatus, 15000);

    // Event Listeners with Null Checks
    const scanForm = document.getElementById("scan-launcher-form");
    if (scanForm) scanForm.addEventListener("submit", handleScanSubmit);

    const btnAiChat = document.getElementById("btn-send-ai-chat");
    if (btnAiChat) btnAiChat.addEventListener("click", handleAIChatSend);

    const btnRefreshScans = document.getElementById("btn-refresh-scans");
    if (btnRefreshScans) btnRefreshScans.addEventListener("click", loadDashboardData);

    const btnQuickLaunch = document.getElementById("btn-quick-launch");
    if (btnQuickLaunch) btnQuickLaunch.addEventListener("click", () => switchTab("new-scan"));

    const btnHeaderNewScan = document.getElementById("btn-header-new-scan");
    if (btnHeaderNewScan) btnHeaderNewScan.addEventListener("click", () => switchTab("new-scan"));

    // SAST File Upload Form Listener
    const sastForm = document.getElementById("sast-upload-form");
    if (sastForm) {
        sastForm.addEventListener("submit", (e) => {
            e.preventDefault();
            const fileInput = document.getElementById("sast-file-input");
            if (fileInput && fileInput.files.length > 0) {
                handleFileUpload(fileInput.files[0]);
            } else {
                alert("Please select a project archive file first!");
            }
        });
    }

    const fileInput = document.getElementById("sast-file-input");
    if (fileInput) {
        fileInput.addEventListener("change", (e) => {
            const statusEl = document.getElementById("upload-status-message");
            if (e.target.files.length > 0) {
                if (statusEl) statusEl.innerHTML = `<span style="color: #00f2fe;"><i class="fa-solid fa-file-zipper"></i> Selected File: <strong>${e.target.files[0].name}</strong>. Click 'Start Project Scan' to upload.</span>`;
            }
        });
    }

    // Advanced scan options: authenticated headers + webhook (Phase 3/4 features)
    const btnToggleAdvanced = document.getElementById("btn-toggle-advanced");
    if (btnToggleAdvanced) {
        btnToggleAdvanced.addEventListener("click", () => {
            const panel = document.getElementById("advanced-scan-options");
            if (panel) panel.style.display = panel.style.display === "none" ? "block" : "none";
        });
    }

    const btnAddHeaderRow = document.getElementById("btn-add-header-row");
    if (btnAddHeaderRow) {
        btnAddHeaderRow.addEventListener("click", () => addCustomHeaderRow());
    }

    // Reports pagination controls
    const btnReportsPrev = document.getElementById("btn-reports-prev-page");
    if (btnReportsPrev) {
        btnReportsPrev.addEventListener("click", () => {
            reportsPageOffset = Math.max(0, reportsPageOffset - REPORTS_PAGE_SIZE);
            loadReportsData(false);
        });
    }
    const btnReportsNext = document.getElementById("btn-reports-next-page");
    if (btnReportsNext) {
        btnReportsNext.addEventListener("click", () => {
            if (reportsPageOffset + REPORTS_PAGE_SIZE < reportsTotalCount) {
                reportsPageOffset += REPORTS_PAGE_SIZE;
                loadReportsData(false);
            }
        });
    }

    // Recurring scan schedule form
    const scheduleForm = document.getElementById("schedule-form");
    if (scheduleForm) scheduleForm.addEventListener("submit", handleScheduleSubmit);
}

// Dynamically adds a key/value row for a custom authentication header (e.g. Authorization, Cookie).
function addCustomHeaderRow(key = "", value = "") {
    const container = document.getElementById("custom-headers-rows");
    if (!container) return;
    const row = document.createElement("div");
    row.className = "header-row";
    row.innerHTML = `
        <input type="text" class="form-control header-key-input" placeholder="Header name (e.g. Authorization)" value="${key}">
        <input type="text" class="form-control header-value-input" placeholder="Header value (e.g. Bearer eyJ...)" value="${value}">
        <button type="button" class="btn-remove-row" title="Remove"><i class="fa-solid fa-xmark"></i></button>
    `;
    row.querySelector(".btn-remove-row").addEventListener("click", () => row.remove());
    container.appendChild(row);
}

function collectCustomHeaders() {
    const rows = document.querySelectorAll("#custom-headers-rows .header-row");
    const headers = {};
    rows.forEach(row => {
        const key = row.querySelector(".header-key-input").value.trim();
        const value = row.querySelector(".header-value-input").value.trim();
        if (key && value) headers[key] = value;
    });
    return Object.keys(headers).length > 0 ? headers : null;
}

// ============================================================================
// RECURRING SCANS (SCHEDULES) — fully live, backed by /api/v1/schedules
// ============================================================================
async function handleScheduleSubmit(e) {
    e.preventDefault();
    const target = document.getElementById("schedule-target-input").value.trim();
    const targetType = document.querySelector('input[name="schedule_target_type"]:checked').value;
    const interval = document.getElementById("schedule-interval-select").value;
    const webhookUrl = document.getElementById("schedule-webhook-input").value.trim();

    const payload = {
        target,
        target_type: targetType,
        scan_types: ["Full Vulnerability Scan"],
        interval,
        webhook_url: webhookUrl || null
    };

    try {
        const res = await authFetch(`${API_BASE}/schedules`, {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify(payload)
        });
        const data = await res.json();
        if (!res.ok) throw new Error(data.detail || "Could not create the recurring scan.");
        alert(`Recurring scan created! It will run ${interval.toLowerCase()}, next at ${new Date(data.next_run_at).toLocaleString()}.`);
        e.target.reset();
        await loadSchedulesData();
    } catch (err) {
        alert(`Could not create this schedule: ${err.message}`);
    }
}

async function loadSchedulesData() {
    const tableBody = document.getElementById("schedules-table-body");
    if (!tableBody) return;
    tableBody.innerHTML = `<tr><td colspan="6" style="text-align:center; color:#9ca3af;"><i class="fa-solid fa-spinner fa-spin"></i> Loading schedules...</td></tr>`;

    try {
        const res = await authFetch(`${API_BASE}/schedules`);
        const schedules = await res.json();
        tableBody.innerHTML = "";

        if (!schedules || schedules.length === 0) {
            tableBody.innerHTML = `<tr><td colspan="6" style="text-align:center; color:#9ca3af;">No recurring scans configured yet. Create one above.</td></tr>`;
            return;
        }

        schedules.forEach(sch => {
            const tr = document.createElement("tr");
            const nextRun = sch.next_run_at ? new Date(sch.next_run_at).toLocaleString() : "N/A";
            const lastRun = sch.last_run_at ? new Date(sch.last_run_at).toLocaleString() : "Never run yet";
            const tokenParam = encodeURIComponent(AUTH_TOKEN || "");
            const lastRunLink = sch.last_scan_id
                ? `<a href="${API_BASE}/reports/${sch.last_scan_id}/html?token=${tokenParam}" target="_blank">${lastRun}</a>`
                : lastRun;
            tr.innerHTML = `
                <td><strong>${sch.target}</strong></td>
                <td><span class="badge-ai" style="background:#1e293b; color:#38bdf8;">${sch.interval}</span></td>
                <td>${nextRun}</td>
                <td>${lastRunLink}</td>
                <td>${sch.created_by}</td>
                <td>
                    <button class="btn btn-sm btn-danger" data-admin-only="true" style="background:#ef4444; color:white; border:none; padding:4px 8px; border-radius:4px; cursor:pointer;" onclick="deleteSchedule('${sch.id}')"><i class="fa-solid fa-trash"></i> Delete</button>
                </td>
            `;
            tableBody.appendChild(tr);
        });
        applyRolePermissions();
    } catch (e) {
        tableBody.innerHTML = `<tr><td colspan="6" style="text-align:center; color:#ef4444;">Could not load schedules: ${e.message}</td></tr>`;
    }
}

async function deleteSchedule(scheduleId) {
    if (!confirm(`Delete this recurring scan schedule?`)) return;
    try {
        const res = await authFetch(`${API_BASE}/schedules/${scheduleId}`, { method: "DELETE" });
        if (!res.ok) {
            const data = await res.json().catch(() => ({}));
            throw new Error(data.detail || "Could not delete this schedule.");
        }
        await loadSchedulesData();
    } catch (e) {
        alert(`Error deleting schedule: ${e.message}`);
    }
}

// Auto-polling interval for scan pipeline status
let pollInterval = null;

async function handleFileUpload(file) {
    const fileInput = document.getElementById("sast-file-input");
    const statusEl = document.getElementById("upload-status-message");
    const validExts = [".zip", ".tar", ".gz", ".tgz"];
    const isArchive = validExts.some(ext => file && file.name.toLowerCase().endsWith(ext));

    if (!file || !isArchive) {
        alert("Please select a valid compressed archive file (.zip, .tar, .tar.gz, .tgz).");
        if (statusEl) statusEl.innerHTML = `<span style="color: #ef4444;">Invalid file type. Please select a compressed archive file.</span>`;
        if (fileInput) fileInput.value = "";
        return;
    }

    if (statusEl) statusEl.innerHTML = `<span style="color: #f59e0b;"><i class="fa-solid fa-spinner fa-spin"></i> Uploading ${file.name} to SAST Scan Engine...</span>`;

    const formData = new FormData();
    formData.append("file", file);

    try {
        const response = await authFetch(`${API_BASE}/scans/upload`, {
            method: "POST",
            body: formData
        });
        const data = await response.json();
        if (!response.ok) {
            throw new Error(data.detail || "Upload failed.");
        }
        if (statusEl) statusEl.innerHTML = `<span style="color: #10b981;"><i class="fa-solid fa-circle-check"></i> Upload Successful! ID: ${data.id}. Redirecting to Dashboard...</span>`;
        
        setTimeout(async () => {
            switchTab("dashboard");
            await loadDashboardData();
            startAutoPolling();
        }, 1200);
    } catch (err) {
        if (statusEl) statusEl.innerHTML = `<span style="color: #ef4444;">Upload error: ${err.message}</span>`;
        alert(`Error uploading project archive: ${err.message}`);
    } finally {
        if (fileInput) fileInput.value = "";
    }
}

// Navigation Handling
function initNavigation() {
    const navItems = document.querySelectorAll(".nav-item");
    navItems.forEach(item => {
        item.addEventListener("click", () => {
            const targetTab = item.getAttribute("data-tab");
            switchTab(targetTab);
        });
    });
}

function switchTab(tabId) {
    document.querySelectorAll(".nav-item").forEach(el => el.classList.remove("active"));
    document.querySelectorAll(".tab-view").forEach(el => el.classList.remove("active"));

    const activeNav = document.querySelector(`.nav-item[data-tab="${tabId}"]`);
    const activeView = document.getElementById(`view-${tabId}`);

    if (activeNav) activeNav.classList.add("active");
    if (activeView) activeView.classList.add("active");

    if (tabId === "schedules") loadSchedulesData();
    if (tabId === "wazuh") loadWazuhView();
}

// Chart Renderers — initialized empty, then populated with real data via updateCharts(scans)
function initCharts() {
    const ctxTrend = document.getElementById("trendChart").getContext("2d");
    trendChartInstance = new Chart(ctxTrend, {
        type: 'line',
        data: {
            labels: [],
            datasets: [
                {
                    label: 'Critical Vulnerabilities',
                    data: [],
                    borderColor: '#ff0844',
                    backgroundColor: 'rgba(255, 8, 68, 0.1)',
                    fill: true,
                    tension: 0.4
                },
                {
                    label: 'High Severity',
                    data: [],
                    borderColor: '#f59e0b',
                    backgroundColor: 'rgba(245, 158, 11, 0.1)',
                    fill: true,
                    tension: 0.4
                }
            ]
        },
        options: {
            responsive: true,
            plugins: { legend: { labels: { color: '#9ca3af' } } },
            scales: {
                x: { ticks: { color: '#9ca3af' }, grid: { color: 'rgba(255,255,255,0.05)' } },
                y: { ticks: { color: '#9ca3af' }, grid: { color: 'rgba(255,255,255,0.05)' }, beginAtZero: true }
            }
        }
    });

    const ctxSev = document.getElementById("severityChart").getContext("2d");
    severityChartInstance = new Chart(ctxSev, {
        type: 'doughnut',
        data: {
            labels: ['Critical', 'High', 'Medium', 'Low'],
            datasets: [{
                data: [0, 0, 0, 0],
                backgroundColor: ['#ff0844', '#f59e0b', '#00f2fe', '#8b5cf6'],
                borderWidth: 0
            }]
        },
        options: {
            responsive: true,
            plugins: { legend: { position: 'bottom', labels: { color: '#9ca3af' } } }
        }
    });
}

// Aggregates the real scan history into chart-ready series — no mock data.
function updateCharts(scans) {
    if (!severityChartInstance || !trendChartInstance) return;

    // Severity distribution: real sum across every scan in history.
    let critical = 0, high = 0, medium = 0, low = 0;
    scans.forEach(s => {
        critical += (s.critical_count || 0);
        high += (s.high_count || 0);
        medium += (s.medium_count || 0);
        low += (s.low_count || 0);
    });
    severityChartInstance.data.datasets[0].data = [critical, high, medium, low];
    severityChartInstance.update();

    // Trend: bucket completed scans by calendar day over the last 7 days, real counts only.
    const dayBuckets = [];
    for (let i = 6; i >= 0; i--) {
        const d = new Date();
        d.setDate(d.getDate() - i);
        dayBuckets.push({
            key: d.toISOString().slice(0, 10),
            label: d.toLocaleDateString(undefined, { month: 'short', day: 'numeric' }),
            critical: 0,
            high: 0
        });
    }
    const bucketMap = Object.fromEntries(dayBuckets.map(b => [b.key, b]));

    scans.forEach(s => {
        if (!s.start_time) return;
        const dayKey = s.start_time.slice(0, 10);
        if (bucketMap[dayKey]) {
            bucketMap[dayKey].critical += (s.critical_count || 0);
            bucketMap[dayKey].high += (s.high_count || 0);
        }
    });

    trendChartInstance.data.labels = dayBuckets.map(b => b.label);
    trendChartInstance.data.datasets[0].data = dayBuckets.map(b => b.critical);
    trendChartInstance.data.datasets[1].data = dayBuckets.map(b => b.high);
    trendChartInstance.update();
}

// Live engine health indicator — actually calls the backend instead of a hardcoded "ACTIVE" label.
async function checkEngineStatus() {
    const dot = document.getElementById("engine-status-dot");
    const text = document.getElementById("engine-status-text");
    if (!dot || !text) return;
    try {
        const res = await fetch(`${API_BASE}/health`);
        if (res.ok) {
            dot.classList.remove("offline");
            text.textContent = "ACTIVE";
            text.style.color = "#10b981";
        } else {
            throw new Error("non-200");
        }
    } catch (e) {
        dot.classList.add("offline");
        text.textContent = "UNREACHABLE";
        text.style.color = "#ff0844";
    }
}

// Wazuh SIEM status (top bar badge)
function wazuhState(d) {
    if (!d.enabled) return ["#6b7280", "Disabled"];
    if (!d.reachable) return ["#ef4444", "Unreachable"];
    if (d.last_error) return ["#f59e0b", "Degraded"];
    return ["#10b981", `Connected · ${d.events_sent} sent`];
}
async function checkWazuhStatus() {
    const dot = document.getElementById("wazuh-status-dot");
    const text = document.getElementById("wazuh-status-text");
    if (!dot || !text) return;
    try {
        const res = await authFetch(`${API_BASE}/integrations/wazuh/status`);
        if (!res.ok) throw new Error(res.status);
        const [color, label] = wazuhState(await res.json());
        dot.style.backgroundColor = color; text.textContent = label; text.style.color = color;
    } catch (e) {
        dot.style.backgroundColor = "#6b7280"; text.textContent = "Unavailable"; text.style.color = "#9ca3af";
    }
}

// Wazuh SIEM Integration page
const esc = v => String(v ?? "—").replace(/[&<>"']/g, c => ({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]));
async function loadWazuhView() {
    const [sRes, aRes] = await Promise.all([
        authFetch(`${API_BASE}/integrations/wazuh/status?deep=true`),
        authFetch(`${API_BASE}/integrations/wazuh/alerts?limit=20`),
        authFetch(`${API_BASE}/integrations/wazuh/vulnerabilities?limit=50&refresh=true`)
    ]);
    const d = sRes.ok ? await sRes.json() : null;
    if (d) {
        const [color, label] = wazuhState(d);
        const card = (l, v, c) => `<div class="stat-card"><div class="stat-label">${l}</div><div class="stat-value" style="${c ? "color:" + c : ""}">${v}</div></div>`;
        document.getElementById("wazuh-stats").innerHTML =
            card("Status", label.split(" ·")[0], color) + card("Events Delivered", d.events_sent) +
            card("Pending Outbox", d.queue_depth) + card("Dead Letter", d.outbox ? d.outbox.dead_letter : 0) +
            card("Wazuh CVEs Cached", d.vulnerability_count || 0);
        const api = d.api || {};
        const rows = [
            ["Manager endpoint", `${d.host}:${d.port} (${d.protocol.toUpperCase()})`],
            ["Syslog listener", d.reachable ? "Reachable" : "Not reachable — is the Wazuh VM running?"],
            ["Wazuh target version", d.wazuh_version_target],
            ["Vulnerability index", d.vulnerability_index],
            ["Last delivery", d.last_successful_event || "None yet"],
            ["Last error", d.last_error || "None"],
            ["Wazuh API", !api.configured ? "Not configured" : api.ok ? `OK · v${api.version} · agents: ${JSON.stringify(api.agents)}` : `Error: ${api.error}`],
            ["Wazuh Indexer", d.indexer && d.indexer.configured ? (d.indexer.ok ? "Connected" : `Error: ${d.indexer.error}`) : "Not configured"]
        ];
        document.getElementById("wazuh-conn-body").innerHTML = rows.map(r => `<tr><td style="width:220px;color:var(--text-muted)">${r[0]}</td><td>${esc(r[1])}</td></tr>`).join("");
    }
    const a = aRes.ok ? await aRes.json() : { configured: false, alerts: [] };
    const vulnRes = await authFetch(`${API_BASE}/integrations/wazuh/vulnerabilities?limit=50&refresh=false`);
    const wv = vulnRes.ok ? await vulnRes.json() : { configured: false, vulnerabilities: [], count: 0 };
    document.getElementById("wazuh-vulns-note").textContent = !wv.configured ? "Configure the Wazuh Indexer to import native endpoint vulnerability inventory" : (wv.sync_error || `${wv.count || 0} vulnerability records cached`);
    document.getElementById("wazuh-vulns-body").innerHTML = (wv.vulnerabilities || []).map(x =>
        `<tr><td>${esc(x.agent_name || x.agent_id)}</td><td>${esc(x.package_name)}</td><td>${esc(x.package_version)}</td><td>${esc(x.cve_id)}</td><td>${esc(x.severity)}</td><td>${esc(x.cvss_score)}</td><td>${esc(x.status)}</td></tr>`
    ).join("") || `<tr><td colspan="7" style="text-align:center;color:var(--text-muted)">No Wazuh endpoint vulnerabilities imported</td></tr>`;
    document.getElementById("wazuh-alerts-note").textContent = !a.configured ? "Set WAZUH_INDEXER_URL to show live alerts" : a.ok === false ? a.error : "";
    document.getElementById("wazuh-alerts-body").innerHTML = (a.alerts || []).map(x =>
        `<tr><td>${esc(x.time)}</td><td>${esc(x.rule_id)}</td><td>${esc(x.level)}</td><td>${esc(x.severity)}</td><td>${esc(x.target)}</td><td>${esc(x.title || x.description)}</td></tr>`
    ).join("") || `<tr><td colspan="6" style="text-align:center;color:var(--text-muted)">No alerts to display</td></tr>`;
}
async function sendWazuhTest() {
    const btn = document.getElementById("btn-wazuh-test");
    btn.disabled = true; btn.textContent = "Sending…";
    try {
        const res = await authFetch(`${API_BASE}/integrations/wazuh/test`, { method: "POST" });
        const d = await res.json();
        alert(res.ok && d.success ? "Wazuh integration test queued/delivered. Verify the event in Wazuh." : `Delivery failed: ${d.detail || (d.integration_status && d.integration_status.last_error) || "see backend logs"}`);
    } catch (e) { alert("Request failed: " + e.message); }
    btn.disabled = false; btn.innerHTML = '<i class="fa-solid fa-paper-plane"></i> Send Test Event';
    loadWazuhView(); checkWazuhStatus();
}

// Data Loaders
async function loadDashboardData() {
    try {
        const response = await authFetch(`${API_BASE}/scans`);
        const scans = await response.json();
        renderScanPipeline(scans);
        updateDashboardStats(scans);
        updateCharts(scans);
        loadReportsData();
        return scans;
    } catch (err) {
        console.log("Error loading scans from API:", err);
        return [];
    }
}

function updateDashboardStats(scans) {
    const totalScans = scans.length;
    let criticalCount = 0;
    let highMediumCount = 0;
    let totalScore = 0;
    let scoreCount = 0;

    scans.forEach(s => {
        criticalCount += (s.critical_count || 0);
        highMediumCount += ((s.high_count || 0) + (s.medium_count || 0));
        if (s.ai_analysis && s.ai_analysis.overall_risk_score) {
            totalScore += parseFloat(s.ai_analysis.overall_risk_score);
            scoreCount++;
        }
    });

    const avgScore = scoreCount > 0 ? (totalScore / scoreCount).toFixed(1) : "8.5";

    const elTotal = document.getElementById("stat-total-scans");
    if (elTotal) elTotal.innerText = totalScans;

    const elCrit = document.getElementById("stat-critical-vulns");
    if (elCrit) elCrit.innerText = criticalCount;

    const elHigh = document.getElementById("stat-high-vulns");
    if (elHigh) elHigh.innerText = highMediumCount;

    const elScore = document.getElementById("stat-avg-score");
    if (elScore) elScore.innerText = `${avgScore} / 10`;
}


function renderScanPipeline(scans) {
    const tableBody = document.getElementById("scan-pipeline-table");
    if (!tableBody) return;
    tableBody.innerHTML = "";

    if (scans.length === 0) {
        tableBody.innerHTML = `<tr><td colspan="6" style="text-align:center; color:#9ca3af;">No scans executed yet. Launch a scan above.</td></tr>`;
        return;
    }

    scans.forEach(scan => {
        const tr = document.createElement("tr");
        const statusColor = scan.status === 'Completed' ? '#10b981' : (scan.status === 'Running' ? '#00f2fe' : '#f59e0b');
        tr.innerHTML = `
            <td><strong>${scan.target}</strong></td>
            <td><span class="badge-ai" style="background:#1e293b; color:#38bdf8;">${(scan.scan_types || []).join(", ")}</span></td>
            <td><span style="color:${statusColor}; font-weight:600;"><i class="fa-solid ${scan.status === 'Running' ? 'fa-spinner fa-spin' : 'fa-check'}"></i> ${scan.status}</span></td>
            <td style="width: 150px;">
                <div class="progress-bar-wrap">
                    <div class="progress-bar-fill" style="width: ${scan.progress}%;"></div>
                </div>
            </td>
            <td>
                <span style="color:#ef4444; font-weight:600;">${scan.critical_count || 0} Critical</span> | 
                <span style="color:#f97316;">${scan.high_count || 0} High</span>
            </td>
            <td>
                <button class="btn btn-sm btn-outline" onclick="viewScanReport('${scan.id}')"><i class="fa-solid fa-eye"></i> Report</button>
                <button class="btn btn-sm btn-danger" data-admin-only="true" style="background:#ef4444; color:white; border:none; padding:4px 8px; border-radius:4px; margin-left:5px; cursor:pointer;" onclick="deleteScan('${scan.id}')"><i class="fa-solid fa-trash"></i> Delete</button>
            </td>
        `;
        tableBody.appendChild(tr);
    });
    applyRolePermissions();
}

// Real server-side pagination state for the scan history / reports table.
const REPORTS_PAGE_SIZE = 10;
let reportsPageOffset = 0;
let reportsTotalCount = 0;

async function loadReportsData(resetToFirstPage = true) {
    const tableBody = document.getElementById("reports-table-body");
    if (!tableBody) return;

    if (resetToFirstPage) reportsPageOffset = 0;

    tableBody.innerHTML = `<tr><td colspan="5" style="text-align:center; color:#9ca3af;"><i class="fa-solid fa-spinner fa-spin"></i> Loading scan history...</td></tr>`;

    let scans = [];
    try {
        const [scansRes, countRes] = await Promise.all([
            authFetch(`${API_BASE}/scans?limit=${REPORTS_PAGE_SIZE}&offset=${reportsPageOffset}`),
            authFetch(`${API_BASE}/scans/count`)
        ]);
        scans = await scansRes.json();
        const countData = await countRes.json();
        reportsTotalCount = countData.total || 0;
    } catch (e) {
        tableBody.innerHTML = `<tr><td colspan="5" style="text-align:center; color:#ef4444;">Could not load scan history: ${e.message}</td></tr>`;
        return;
    }

    tableBody.innerHTML = "";
    const completedScans = (scans || []).filter(s => s.status === "Completed" || s.progress > 0);

    if (completedScans.length === 0) {
        tableBody.innerHTML = `<tr><td colspan="5" style="text-align:center; color:#9ca3af;">No completed scan reports found on this page. Run a scan to view generated reports.</td></tr>`;
    } else {
        completedScans.forEach(scan => {
            const riskScore = scan.ai_analysis ? scan.ai_analysis.overall_risk_score : 'N/A';
            const tokenParam = encodeURIComponent(AUTH_TOKEN || "");
            const scanDate = (scan.start_time || "").slice(0, 10);
            const tr = document.createElement("tr");
            tr.innerHTML = `
                <td><strong>Security Audit Report - ${scan.id}</strong><div style="font-size:11px; color:#94a3b8; margin-top:2px;">Run by ${scan.requested_by || 'system'} on ${scanDate}</div></td>
                <td>${scan.target}</td>
                <td>${scan.total_vulnerabilities || 0} Findings (${scan.critical_count || 0} Critical)</td>
                <td><span style="color:#ef4444; font-weight:600;">Risk Score: ${riskScore} / 10</span></td>
                <td>
                    <a href="${API_BASE}/reports/${scan.id}/pdf?token=${tokenParam}" target="_blank" class="btn btn-sm btn-primary"><i class="fa-solid fa-file-pdf"></i> Executive Report</a>
                    <a href="${API_BASE}/reports/${scan.id}/html?token=${tokenParam}" target="_blank" class="btn btn-sm btn-outline"><i class="fa-solid fa-file-code"></i> HTML</a>
                    <button class="btn btn-sm btn-danger" data-admin-only="true" style="background:#ef4444; color:white; border:none; padding:4px 8px; border-radius:4px; margin-left:5px; cursor:pointer;" onclick="deleteScan('${scan.id}')"><i class="fa-solid fa-trash"></i> Delete</button>
                </td>
            `;
            tableBody.appendChild(tr);
        });
    }
    applyRolePermissions();
    updateReportsPaginationControls();
}

function updateReportsPaginationControls() {
    const infoEl = document.getElementById("reports-pagination-info");
    const prevBtn = document.getElementById("btn-reports-prev-page");
    const nextBtn = document.getElementById("btn-reports-next-page");
    if (!infoEl || !prevBtn || !nextBtn) return;

    const showingFrom = reportsTotalCount === 0 ? 0 : reportsPageOffset + 1;
    const showingTo = Math.min(reportsPageOffset + REPORTS_PAGE_SIZE, reportsTotalCount);
    infoEl.textContent = `Showing ${showingFrom}-${showingTo} of ${reportsTotalCount} scans`;

    prevBtn.disabled = reportsPageOffset === 0;
    nextBtn.disabled = reportsPageOffset + REPORTS_PAGE_SIZE >= reportsTotalCount;
}

async function deleteScan(scanId) {
    if (!confirm(`Are you sure you want to delete scan record '${scanId}'?`)) return;
    try {
        await authFetch(`${API_BASE}/scans/${scanId}`, { method: "DELETE" });
        await loadDashboardData();
    } catch (e) {
        alert(`Error deleting scan: ${e.message}`);
    }
}

async function handleScanSubmit(e) {
    e.preventDefault();
    const target = document.getElementById("scan-target-input").value;
    const targetType = document.querySelector('input[name="target_type"]:checked').value;

    const checkboxes = document.querySelectorAll('input[name="scan_types"]:checked');
    const scanTypes = Array.from(checkboxes).map(cb => cb.value);

    const webhookInput = document.getElementById("scan-webhook-input");
    const webhookUrl = webhookInput ? webhookInput.value.trim() : "";
    const customHeaders = collectCustomHeaders();

    const payload = { target, target_type: targetType, scan_types: scanTypes };
    if (webhookUrl) payload.webhook_url = webhookUrl;
    if (customHeaders) payload.custom_headers = customHeaders;

    try {
        const res = await authFetch(`${API_BASE}/scans`, {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify(payload)
        });
        const data = await res.json();
        if (!res.ok) {
            throw new Error(data.detail || "The scan could not be started.");
        }
        alert(`Scan Job Queued Successfully! ID: ${data.id}`);
        switchTab("dashboard");
        await loadDashboardData();
        startAutoPolling();
    } catch (err) {
        alert(`Could not start this scan: ${err.message}`);
    }
}

function startAutoPolling() {
    if (pollInterval) clearInterval(pollInterval);
    pollInterval = setInterval(async () => {
        const scans = await loadDashboardData();
        const activeScans = (scans || []).filter(s => s.status === 'Running' || s.status === 'Queued');
        if (activeScans.length === 0) {
            clearInterval(pollInterval);
            pollInterval = null;
        }
    }, 2000);
}

// 4. Asset Management Logic
async function loadAssetsData() {
    const tableBody = document.getElementById("assets-table-body");
    if (!tableBody) return;

    try {
        const res = await authFetch(`${API_BASE}/assets`);
        const assets = await res.json();

        if (!assets || assets.length === 0) {
            tableBody.innerHTML = `<tr><td colspan="7" style="text-align:center; color:#9ca3af;">No assets registered. Click 'Add New Asset' to create one.</td></tr>`;
            return;
        }

        tableBody.innerHTML = "";
        assets.forEach(ast => {
            const tr = document.createElement("tr");
            tr.innerHTML = `
                <td><code style="color:#38bdf8;">${ast.id}</code></td>
                <td><strong>${ast.name}</strong></td>
                <td>${ast.target}</td>
                <td><span style="background:#1e293b; color:#00f2fe; padding:2px 8px; border-radius:4px; font-size:12px;">${ast.asset_type}</span></td>
                <td>${ast.department || 'Engineering'}</td>
                <td><span style="color:#10b981; font-weight:600;"><i class="fa-solid fa-circle-check"></i> ${ast.status || 'Active'}</span></td>
                <td>
                    <button class="btn btn-sm btn-danger" data-admin-only="true" style="background:#ef4444; color:white; border:none; padding:4px 8px; border-radius:4px; cursor:pointer;" onclick="deleteAsset('${ast.id}')"><i class="fa-solid fa-trash"></i> Delete</button>
                </td>
            `;
            tableBody.appendChild(tr);
        });
        applyRolePermissions();
    } catch (e) {
        console.log("Error loading assets:", e);
    }
}

function toggleAddAssetForm() {
    const panel = document.getElementById("add-asset-form-panel");
    if (panel) panel.style.display = panel.style.display === "none" ? "block" : "none";
}

document.addEventListener("DOMContentLoaded", () => {
    const assetForm = document.getElementById("new-asset-form");
    if (assetForm) {
        assetForm.addEventListener("submit", async (e) => {
            e.preventDefault();
            const name = document.getElementById("asset-name-input").value;
            const target = document.getElementById("asset-target-input").value;
            const asset_type = document.getElementById("asset-type-select").value;
            const owner = document.getElementById("asset-owner-input").value;

            try {
                await authFetch(`${API_BASE}/assets`, {
                    method: "POST",
                    headers: { "Content-Type": "application/json" },
                    body: JSON.stringify({ name, target, asset_type, owner, department: "Engineering", tags: ["Infrastructure"] })
                });
                alert("Asset registered successfully!");
                toggleAddAssetForm();
                assetForm.reset();
                await loadAssetsData();
            } catch (err) {
                alert(`Error saving asset: ${err.message}`);
            }
        });
    }

    const cveForm = document.getElementById("new-cve-form");
    if (cveForm) {
        cveForm.addEventListener("submit", async (e) => {
            e.preventDefault();
            const cve_id = document.getElementById("cve-id-input").value;
            const title = document.getElementById("cve-title-input").value;
            const severity = document.getElementById("cve-severity-select").value;
            const cvss_score = parseFloat(document.getElementById("cve-cvss-input").value);
            const summary = document.getElementById("cve-summary-input").value;

            try {
                await authFetch(`${API_BASE}/vulnerabilities`, {
                    method: "POST",
                    headers: { "Content-Type": "application/json" },
                    body: JSON.stringify({
                        cve_id, title, severity, cvss_score, summary,
                        cisa_kev: true, exploit_available: true,
                        affected_products: ["Production System"], published_date: new Date().toISOString().split("T")[0]
                    })
                });
                alert("CVE record created successfully!");
                toggleAddCveForm();
                cveForm.reset();
                await loadCveCatalog();
            } catch (err) {
                alert(`Error saving CVE: ${err.message}`);
            }
        });
    }

    const cveSearchInput = document.getElementById("cve-search-input");
    if (cveSearchInput) {
        cveSearchInput.addEventListener("input", (e) => {
            loadCveCatalog(e.target.value);
        });
    }
});

async function deleteAsset(assetId) {
    if (!confirm(`Are you sure you want to delete asset '${assetId}'?`)) return;
    try {
        await authFetch(`${API_BASE}/assets/${assetId}`, { method: "DELETE" });
        await loadAssetsData();
    } catch (e) {
        alert(`Error deleting asset: ${e.message}`);
    }
}

// 5. CVE Knowledgebase Logic
async function loadCveCatalog(query = "") {
    const listContainer = document.getElementById("cve-catalog-list");
    if (!listContainer) return;

    try {
        const res = await authFetch(`${API_BASE}/vulnerabilities?query=${encodeURIComponent(query)}`);
        const cves = await res.json();

        if (!cves || cves.length === 0) {
            listContainer.innerHTML = `<div style="text-align:center; color:#9ca3af; padding:30px;">No CVE entries found matching query '${query}'.</div>`;
            return;
        }

        listContainer.innerHTML = "";
        cves.forEach(c => {
            const sevColor = c.severity === 'Critical' ? '#ef4444' : (c.severity === 'High' ? '#f97316' : '#eab308');
            const card = document.createElement("div");
            card.className = "cve-item-card glass-panel";
            card.style.cssText = "padding:20px; margin-bottom:15px; border-left:5px solid " + sevColor + "; border-radius:8px;";
            card.innerHTML = `
                <div class="cve-header" style="display:flex; justify-content:space-between; align-items:center;">
                    <div class="cve-title" style="font-size:16px; font-weight:700; color:#f8fafc;">
                        <code style="color:#38bdf8;">${c.cve_id}</code> - ${c.title}
                    </div>
                    <div>
                        <span style="background:${sevColor}; color:white; font-size:11px; font-weight:700; padding:4px 10px; border-radius:12px; text-transform:uppercase;">${c.severity} ${c.cvss_score}</span>
                        <button class="btn btn-sm btn-danger" data-admin-only="true" style="background:#ef4444; color:white; border:none; padding:4px 8px; border-radius:4px; margin-left:10px; cursor:pointer;" onclick="deleteCve('${c.cve_id}')"><i class="fa-solid fa-trash"></i></button>
                    </div>
                </div>
                <p style="font-size:13px; color:#cbd5e1; margin-top:8px; line-height:1.5;">${c.summary}</p>
                <div style="font-size:12px; color:#64748b; margin-top:8px;">
                    <strong>Affected:</strong> ${(c.affected_products || []).join(", ")} | <strong>Published:</strong> ${c.published_date || 'N/A'}
                </div>
            `;
            listContainer.appendChild(card);
        });
        applyRolePermissions();
    } catch (e) {
        console.log("Error loading CVE catalog:", e);
    }
}

function toggleAddCveForm() {
    const panel = document.getElementById("add-cve-form-panel");
    if (panel) panel.style.display = panel.style.display === "none" ? "block" : "none";
}

async function deleteCve(cveId) {
    if (!confirm(`Are you sure you want to delete CVE record '${cveId}'?`)) return;
    try {
        await authFetch(`${API_BASE}/vulnerabilities/${cveId}`, { method: "DELETE" });
        await loadCveCatalog();
    } catch (e) {
        alert(`Error deleting CVE: ${e.message}`);
    }
}

// 6. AI Vulnerability Assistant Logic
async function handleAIChatSend() {
    const input = document.getElementById("ai-chat-input");
    const text = input.value.trim();
    if (!text) return;

    sendAiMessageToUi(text);
    input.value = "";
}

function sendAiPrompt(promptText) {
    const input = document.getElementById("ai-chat-input");
    if (input) {
        input.value = promptText;
        handleAIChatSend();
    }
}

async function sendAiMessageToUi(text) {
    const messages = document.getElementById("ai-chat-messages");
    
    const userDiv = document.createElement("div");
    userDiv.className = "chat-msg user";
    userDiv.style.cssText = "background:rgba(255,255,255,0.05); padding:12px; border-radius:8px; margin-bottom:12px; border-right:3px solid #38bdf8; text-align:right;";
    userDiv.innerHTML = `<strong style="color:#38bdf8;">You:</strong> ${text}`;
    messages.appendChild(userDiv);
    messages.scrollTop = messages.scrollHeight;

    try {
        const res = await authFetch(`${API_BASE}/ai/chat`, {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({ message: text })
        });
        const data = await res.json();

        const aiDiv = document.createElement("div");
        aiDiv.className = "chat-msg ai";
        aiDiv.style.cssText = "background:rgba(2,132,199,0.12); border-left:4px solid #0284c7; padding:15px; border-radius:8px; margin-bottom:15px;";
        
        let actionPills = (data.suggested_actions || []).map(a => `<span style="background:#0f172a; color:#38bdf8; font-size:11px; padding:3px 8px; border-radius:10px; border:1px solid #0284c7; font-weight:600;">${a}</span>`).join(" ");
        const aiBadge = data.ai_powered
            ? `<span style="background:#065f46; color:#6ee7b7; font-size:10px; padding:2px 8px; border-radius:10px; margin-left:8px; font-weight:700;"><i class="fa-solid fa-sparkles"></i> AI-Powered</span>`
            : `<span style="background:#334155; color:#94a3b8; font-size:10px; padding:2px 8px; border-radius:10px; margin-left:8px; font-weight:700;">Rule-Based</span>`;

        aiDiv.innerHTML = `
            <div class="msg-author" style="color:#38bdf8; font-weight:700; margin-bottom:6px;"><i class="fa-solid fa-robot"></i> SecureScan AI Assistant ${aiBadge}</div>
            <div class="msg-text" style="color:#f8fafc; font-size:14px; line-height:1.6;">${data.response.replace(/\n/g, '<br>')}</div>
            <div style="margin-top:10px; display:flex; gap:6px; flex-wrap:wrap;">${actionPills}</div>
        `;
        messages.appendChild(aiDiv);
        messages.scrollTop = messages.scrollHeight;
    } catch (e) {
        const errDiv = document.createElement("div");
        errDiv.style.cssText = "color:#ef4444; padding:10px;";
        errDiv.innerText = `AI Assistant Error: ${e.message}`;
        messages.appendChild(errDiv);
    }
}

function viewScanReport(scanId) {
    // Report links are plain anchors opened in a new tab, so the auth token
    // travels as a query parameter (the backend also accepts it that way).
    window.open(`${API_BASE}/reports/${scanId}/html?token=${encodeURIComponent(AUTH_TOKEN || "")}`, '_blank');
}

