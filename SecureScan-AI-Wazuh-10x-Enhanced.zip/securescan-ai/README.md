# SecureScan AI - Enterprise Security & Vulnerability Platform

SecureScan AI is an enterprise-grade Vulnerability Assessment, Security Reporting, and Risk Management Platform similar in architecture to Nessus, OpenVAS, and Qualys.

---

## 🌟 Architecture & Features

1. **Login & Role-Based Access**: Every page and API route requires sign-in. Two roles are seeded out of the box — **Admin** (full control, including deleting scans/assets/CVE records and creating new accounts) and **User** (can launch scans, view dashboards, view/download reports, and use the AI assistant, but cannot delete records).
2. **Executive Dashboard**: Live risk trend metrics, threat score distribution charts, active scan pipeline monitoring.
3. **Multi-Target Launcher**: Supports Website URLs, IP Addresses/Servers, Subnet Ranges, Repositories, Container Images, and Cloud Workloads.
4. **Live Dynamic Vulnerability Scanning** — findings are generated from real, live checks against the actual target, not fixed/canned data:
   - **Web targets**: live HTTP request inspecting real response headers (CSP, HSTS, X-Frame-Options, etc.), cookie security flags, server banner disclosure, and a safe reflected-input probe.
   - **Network/IP targets**: a live TCP connect-scan across 21 common service ports (no external tool required), plus optional deeper scanning via Nmap if it's installed on the host.
   - **Any HTTPS-capable target**: a live TLS handshake checking the negotiated protocol version and certificate expiry.
   - **Uploaded code archives (SAST)**: real static analysis — extracts the archive and scans every file for hardcoded secrets (AWS keys, private keys, API tokens, passwords) via pattern matching, and cross-checks `requirements.txt` / `package.json` dependency versions against a known-vulnerable package table. Optional deeper scanning via Trivy if installed.
   - Optional integrations (used automatically when available on the host): Nmap, Trivy, OWASP ZAP daemon, OpenVAS/Greenbone.
5. **AI Vulnerability Assistant**: Plain-language risk explainer, remediation advice, and patch prioritization, generated dynamically from each scan's actual findings (not a fixed template).
6. **Scan History**: Every scan (queued, running, or completed) is persisted to disk and never lost on restart. The Reports tab shows the full historical list with who ran each scan and when.
7. **Asset Inventory**: Centralized digital footprint asset manager with department tagging and last-scan timestamps.
8. **CVE & NVD Knowledgebase**: Integrated threat catalog displaying CVSS v3.1 scores, CISA Known Exploited Vulnerabilities, and exploit metrics.
9. **Human-Friendly Report Generator**: Exportable HTML/PDF executive reports written for non-technical readers — includes a plain-language risk gauge, a glossary explaining what Critical/High/Medium/Low actually mean for the business, and a step-by-step fix plan — plus a raw JSON export for technical/compliance use.

---

## 🔑 Default Login Credentials

| Role  | Username | Password   | Permissions |
|-------|----------|------------|-------------|
| Admin | `admin`  | `admin123` | Full access — can delete scans/assets/CVE records and create new user accounts |
| User  | `user`   | `user123`  | Can launch scans, view the dashboard, view/download reports, and use the AI assistant |

Change these credentials before deploying to production (see `backend/routers/auth.py` — `DEFAULT_USERS_DB`, or use the Admin account to register new accounts via `POST /api/v1/auth/register`).

---

## 🚀 Quickstart Guide

### Prerequisites
- Python 3.10+
- Pip package manager
- Docker & Docker Compose (Optional for containerized deployment)
- (Optional, for deeper scanning) Nmap, Trivy, OWASP ZAP, OpenVAS/Greenbone — the platform works fully without these using its built-in live scanners.

### Local Setup Instructions

1. Navigate to the project root directory.

2. Install python dependencies:
   ```bash
   pip install -r backend/requirements.txt
   ```

3. Launch the FastAPI server:
   ```bash
   python -m uvicorn backend.main:app --host 0.0.0.0 --port 8000 --reload
   ```

4. Access the web interface in your browser:
   `http://localhost:8000`
   You'll land on the login screen — sign in with one of the default accounts above.

5. Interactive OpenAPI Swagger documentation:
   `http://localhost:8000/docs`

### A note on live scanning and network access

Because scans are run **live** against the actual target, the machine running SecureScan AI needs outbound network access to whatever you're scanning. If you're testing in a sandboxed/offline environment, scan an internal/reachable target (e.g. `127.0.0.1`, a host on your own network, or an uploaded code archive for SAST) to see full results — scans against unreachable targets will simply report "unreachable" findings and complete without a false positive.

---

## 🐳 Docker Deployment

```bash
docker-compose up --build -d
```

---

## 📁 Repository Directory Structure

```
securescan-ai/
├── backend/
│   ├── main.py                # FastAPI Entry point & routes
│   ├── config.py              # Application settings & JWT key config
│   ├── models.py              # Pydantic schemas & data models
│   ├── scanners.py            # Live dynamic scan engines (port/HTTP/TLS/SAST) + optional tool wrappers
│   ├── storage.py             # JSON-backed persistence (scans, assets, CVEs, users)
│   ├── requirements.txt       # Python dependencies
│   └── routers/
│       ├── auth.py            # JWT Authentication, RBAC (Admin/User), login/register
│       ├── assets.py          # Asset Management API
│       ├── scans.py           # Scan Engine, Orchestration & Scan History
│       ├── ai_analysis.py     # AI Risk Synthesizer & Chat Copilot API
│       ├── vulnerabilities.py # CVE & NVD Search API
│       └── reports.py         # Human-friendly PDF/HTML/JSON Report Exporter
├── frontend/
│   ├── index.html             # Single-Page App HTML Interface (incl. login screen)
│   ├── styles.css             # Glassmorphic Dark Cybersecurity Theme
│   └── app.js                 # Frontend SPA Logic, Auth flow, Chart.js Integration
├── Dockerfile                 # Container Build definition
├── docker-compose.yml         # Container Orchestration file
└── README.md                  # System Documentation
```

---

## What changed in this update

**Dynamic UI pass (latest) + a real bug fix found while testing it:**
- **Dashboard charts are now driven entirely by real scan data** — the severity-distribution donut and the 7-day trend line used to render fixed, hardcoded numbers regardless of your actual scan history. They now aggregate real severity counts and bucket real scans by day.
- **Engine status indicator is now live** — "Scan Engine: ACTIVE" was a hardcoded label; it now calls `/api/v1/health` on load and every 30 seconds, and turns red with "UNREACHABLE" if the backend is actually down.
- **Scan history (Reports tab) now uses real server-side pagination** — Previous/Next controls backed by the `limit`/`offset`/`count` endpoints added in Phase 4, instead of loading everything at once.
- **Recurring Scans is now a full UI tab** — create, view, and delete scheduled scans (Hourly/Daily/Weekly) without touching the API directly.
- **Authenticated scanning + webhook alerts are now exposed in the New Scan form** — an "Advanced Options" panel lets you add custom headers (e.g. `Authorization`, `Cookie`) so a scan can reach pages behind a login wall, and set a webhook URL to be notified of Critical/High findings.
- **Bug found and fixed while testing the above**: severity counts (`critical_count`, `high_count`, etc.) were silently always calculating as `0` due to `str()` on a Python `str`-based `Enum` returning `"SeverityEnum.CRITICAL"` instead of `"Critical"`. This affected the dashboard stats, the risk score, the executive summary text, and webhook alert triggering — all of it was undercounting/miscounting behind the scenes even though individual finding severities displayed correctly. Fixed with a proper `.value`-aware normalizer used consistently everywhere severity is compared.

**Phase 4 — Real Infrastructure:**
- **Real database**: replaced flat JSON files with a proper SQLite database (WAL mode — atomic, concurrency-safe writes) for scans, assets, CVEs, and users. Any existing JSON data from a previous version is automatically migrated in on first boot.
- **Real pagination**: `GET /api/v1/scans?limit=20&offset=0` now runs an indexed SQL query instead of loading the entire scan history into memory. A `GET /api/v1/scans/count` endpoint returns the total for building pagination controls. Omitting `limit` preserves the old full-list behavior.
- **Real PDF generation**: the `/reports/{scan_id}/pdf` endpoint now generates an actual downloadable `.pdf` file server-side via WeasyPrint, instead of an HTML page with a browser print button. `/reports/{scan_id}/html` remains available for the in-browser view. If WeasyPrint isn't available in a given environment, the endpoint gracefully falls back to serving HTML instead of erroring.
- **Scheduled / recurring scans**: new `/api/v1/schedules` endpoints let you set up a target to be re-scanned automatically on an Hourly/Daily/Weekly interval. A lightweight in-process background thread checks for and runs due schedules.
- **Webhook alerts**: a scan can be created with a `webhook_url`; if it finds Critical or High severity issues, a structured JSON payload is POSTed there automatically (compatible with most SIEM/ticketing/Slack-style webhook receivers).

**Phase 3 — Scanning Depth & Accuracy:**
- **Nmap + Trivy bundled into the Docker image** so deployed instances get deeper, signature-based scanning automatically — the platform's built-in pure-Python scanners still work fully without them.
- **Parallelized port scanning**: the live TCP port scan now runs concurrently (thread pool) instead of sequentially, and coverage was expanded from ~21 to ~40 common + extended ports without a meaningful time cost.
- **Live CVE lookups**: dependency scanning (`requirements.txt` / `package.json`) now queries the live OSV.dev vulnerability database in real time for up-to-date results, automatically falling back to a small built-in known-vulnerable-package table if the live database is unreachable (e.g. offline/air-gapped deployments).
- **Authenticated scanning**: scans can now include `custom_headers` (e.g. an `Authorization` bearer token or session `Cookie`) so the live HTTP scanner can check pages that sit behind a login wall.

**Phase 2 — Real AI Integration:**
- `/ai/chat`, `/ai/explain`, and each scan's risk-analysis narrative (business impact, technical impact, executive summary) now call the real Anthropic Claude API when `ANTHROPIC_API_KEY` is configured, producing genuinely reasoned, non-templated text grounded in that scan's actual findings.
- The overall risk **score** remains deterministic (calculated from severity counts, not the LLM) so it stays consistent and auditable — only the narrative/explanation layer is AI-generated.
- If no API key is set, or a call fails for any reason, every AI feature cleanly falls back to the existing rule-based logic — the platform always returns a complete, correct answer either way. Responses include an `ai_powered: true/false` flag so the UI can be transparent about which was used.

**Phase 1 — Security Hardening:**
- Passwords are now hashed with **bcrypt** (salted, industry-standard) instead of unsalted SHA-256. Any existing accounts on the older hash format are transparently upgraded to bcrypt on their next successful login.
- **Login rate limiting**: an account is temporarily locked (HTTP 429) after too many failed login attempts in a row, configurable via `LOGIN_MAX_ATTEMPTS` / `LOGIN_LOCKOUT_SECONDS`.
- **JWT secret key** now comes from the `SECRET_KEY` environment variable; if unset, a random key is generated per-process with a clear warning (fine for local dev, but production deployments must set it explicitly so sessions survive restarts).
- **SSRF / internal-network protection**: scan targets are validated before a scan runs. Cloud metadata endpoints (e.g. `169.254.169.254`) are always blocked, and private/internal/loopback IP ranges are blocked by default (can be re-enabled for trusted internal scanning via `ALLOW_INTERNAL_SCAN_TARGETS=true`).
- **Zip-slip fix**: uploaded archives are now safely extracted — any entry attempting path traversal (`../../etc`) or a malicious symlink is detected and the extraction is rejected before anything is written to disk.
- **Zip-bomb guard**: uploaded archives are capped by total file count and total uncompressed size (`MAX_ARCHIVE_FILE_COUNT`, `MAX_EXTRACTED_SIZE_MB`) to prevent resource-exhaustion attacks.
- **Upload size/type enforcement**: file uploads are streamed to disk with a hard size cap (`MAX_UPLOAD_SIZE_MB`, default 100MB) instead of being loaded fully into memory, and only real archive extensions are accepted.

**Earlier foundational update:**
- Added a full login system (JWT-based) with Admin/User roles; every API route and every UI tab now requires authentication.
- Replaced the purely canned vulnerability catalogs with real, live dynamic scanning: live port scans, live HTTP header analysis, live TLS checks, and real static code/secret/dependency analysis of uploaded archives.
- Fixed a bug where completed scans were never saved to disk — scan history now persists reliably across restarts.
- Rebuilt the executive report with a plain-language risk gauge and severity glossary aimed at non-technical readers.
- Added role-aware UI (destructive actions are hidden from non-admin users) and audit info (who ran each scan, and when) in scan history.
- Fixed an asset-type enum mismatch that caused the Assets page to return a 500 error.

---

## Environment variables (production checklist)

| Variable | Default | Purpose |
|---|---|---|
| `SECRET_KEY` | random per-process | JWT signing key — **must** be set explicitly in production |
| `LOGIN_MAX_ATTEMPTS` | 5 | Failed logins before temporary lockout |
| `LOGIN_LOCKOUT_SECONDS` | 300 | Lockout duration |
| `MAX_UPLOAD_SIZE_MB` | 100 | Max size of an uploaded project archive |
| `MAX_EXTRACTED_SIZE_MB` | 500 | Max total uncompressed size of an extracted archive |
| `MAX_ARCHIVE_FILE_COUNT` | 20000 | Max number of files inside an uploaded archive |
| `ALLOW_INTERNAL_SCAN_TARGETS` | false | Set `true` only in trusted deployments that need to scan their own internal network |
| `ANTHROPIC_API_KEY` | (unset) | Enables real Claude-powered AI chat, vulnerability explanations, and scan risk narratives. Without it, the platform uses its rule-based fallback logic — fully functional, just not LLM-reasoned. |
| `DEFAULT_AI_MODEL` | `claude-sonnet-4-6` | Which Claude model to call for AI features |

## New API endpoints (Phase 2–4)

| Endpoint | Purpose |
|---|---|
| `GET /api/v1/scans?limit=&offset=` | Paginated scan history |
| `GET /api/v1/scans/count` | Total scan count |
| `POST /api/v1/schedules` | Create a recurring scan (Hourly/Daily/Weekly) |
| `GET /api/v1/schedules` | List recurring scans |
| `DELETE /api/v1/schedules/{id}` | Remove a recurring scan (Admin only) |
| `POST /api/v1/scans` (body: `custom_headers`) | Authenticated scanning behind a login wall |
| `POST /api/v1/scans` (body: `webhook_url`) | Get a webhook alert if the scan finds Critical/High issues |
| `GET /api/v1/reports/{scan_id}/pdf` | Real downloadable PDF report |

## Notes on this update

- **Docker build not verified in this environment** — no Docker runtime was available to test the image build. The Nmap/Trivy/WeasyPrint system dependency installation steps are standard for Debian-slim images but should be verified in your own CI before relying on them in production.
- **OSV.dev live queries**: tested with graceful fallback behavior (confirmed the static table takes over when the live API is unreachable), but the live-success path itself needs verification once deployed somewhere with unrestricted outbound internet access, since this development sandbox has restricted network egress.
- **Frontend UI has now been updated** to expose the custom-headers, webhook, and schedules features through the interface (see "Dynamic UI pass" above) — they were previously API/Swagger-only.




## Wazuh SIEM Integration
See [`wazuh/WAZUH_SETUP.md`](wazuh/WAZUH_SETUP.md). Findings are queued and delivered in batches to Wazuh over syslog (TCP 514)
with retry, deduplication and a status/alerts page under **SIEM Integration**.


## Wazuh integration architecture

This release uses Wazuh in two distinct roles:

1. **Native endpoint vulnerability detection:** Wazuh Agents/Syscollector collect installed software inventory; Wazuh Vulnerability Detection correlates it with vulnerability intelligence and indexes results in `wazuh-states-vulnerabilities-*`. SecureScan imports and normalizes those real records.
2. **SecureScan SIEM ingestion:** SecureScan findings are persisted in a durable SQLite outbox and delivered to the Wazuh Manager over TCP syslog. Custom rules classify critical/high/medium/low findings and correlation events.

The project does not treat a TCP connection as proof that Wazuh accepted an alert, and it does not create fake CVEs for integration testing.

### Wazuh environment variables

See `.env.example` for `WAZUH_API_URL`, `WAZUH_INDEXER_URL`, credentials, `WAZUH_VULN_INDEX`, `WAZUH_VERSION`, and durable outbox settings.

### Important limitation

Wazuh Vulnerability Detection is primarily endpoint/package/software vulnerability detection. SecureScan remains responsible for application/web/network/source scanning; Wazuh is not a replacement for ZAP, Nmap, Greenbone, SAST, or Trivy.

## First-run administrator

Default credentials are **not** shipped or re-seeded. Set `BOOTSTRAP_ADMIN_USERNAME`, `BOOTSTRAP_ADMIN_PASSWORD` (12+ characters), and `BOOTSTRAP_ADMIN_EMAIL`, then run:

```bash
python -m backend.bootstrap_admin
```

For a Docker deployment, run the command inside the `web` container after supplying the variables in `.env`.
